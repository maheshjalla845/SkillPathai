import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import OpenAI from "https://esm.sh/openai@4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface DiagnosticResult {
  topic: string;
  subtopic: string;
  is_correct: boolean;
  difficulty: string;
}

interface RequestBody {
  career_goal: string;
  skills: { skill_name: string; level: string }[];
  diagnostic_results: DiagnosticResult[];
  study_time_per_day: string;
  learning_preference: string;
  groq_api_key?: string;
}

interface RoadmapPhaseAI {
  phase_number: number;
  title: string;
  description: string;
  topics: RoadmapTopicAI[];
}

interface RoadmapTopicAI {
  topic_name: string;
  description: string;
  priority: "high" | "medium" | "low";
  estimated_hours: number;
  target_proficiency: number;
  prerequisites: string[];
  resources: string[];
  practice: string[];
  subtopics: string[];
}

function buildPrompt(body: RequestBody): string {
  const skillsList = body.skills.length > 0
    ? body.skills.map((s) => `${s.skill_name} (${s.level})`).join(", ")
    : "No prior skills";

  const diagnosticSummary = body.diagnostic_results.length > 0
    ? body.diagnostic_results.map((d) => `${d.topic}/${d.subtopic}: ${d.is_correct ? "correct" : "incorrect"} (${d.difficulty})`).join("; ")
    : "No diagnostic data";

  return `You are an expert career mentor and technical educator creating a personalized learning roadmap.

STUDENT PROFILE:
- Career goal: ${body.career_goal}
- Self-reported skills: ${skillsList}
- Diagnostic results: ${diagnosticSummary}
- Available study time: ${body.study_time_per_day}
- Learning preference: ${body.learning_preference}

TASK: Create a comprehensive learning roadmap with 4-6 phases. Each phase builds on the previous one. The roadmap should:
1. Start with fundamentals the student is weak in (based on diagnostic results)
2. Progress to intermediate and advanced topics
3. Be specifically tailored to the career goal: "${body.career_goal}"
4. Include practical projects and DSA practice throughout
5. Account for the student's study time availability

Return a JSON object with this exact structure:
{
  "phases": [
    {
      "phase_number": 1,
      "title": "Phase title",
      "description": "What this phase covers and why",
      "topics": [
        {
          "topic_name": "Topic name",
          "description": "What this topic covers",
          "priority": "high" | "medium" | "low",
          "estimated_hours": 10,
          "target_proficiency": 80,
          "prerequisites": ["prerequisite topic names"],
          "resources": ["resource URL or description"],
          "practice": ["practice problem or exercise description"],
          "subtopics": ["subtopic 1", "subtopic 2"]
        }
      ]
    }
  ]
}

Rules:
- Include 4-6 phases
- Each phase should have 3-6 topics
- Topics within a phase should be ordered by prerequisites
- Include real, specific resource names (e.g., "GeeksforGeeks: Binary Search", "freeCodeCamp: React Tutorial")
- Include specific practice problems (e.g., "LeetCode #704 Binary Search", "Implement a hash map from scratch")
- estimated_hours should be realistic for the topic depth
- target_proficiency is the level the student should reach (usually 70-90)

IMPORTANT: Return ONLY the JSON object, no markdown, no explanation.`;
}

async function callGroq(prompt: string, apiKeyFromClient?: string): Promise<{ phases: RoadmapPhaseAI[] }> {
  const apiKey = Deno.env.get("GROQ_API_KEY") || apiKeyFromClient;
  if (!apiKey) throw new Error("GROQ_API_KEY not configured");

  const client = new OpenAI({
    apiKey,
    baseURL: "https://api.groq.com/openai/v1",
  });

  const completion = await client.chat.completions.create({
    model: "openai/gpt-oss-20b",
    messages: [{ role: "user", content: prompt }],
    temperature: 0.7,
    max_tokens: 8192,
    response_format: { type: "json_object" },
  });

  const text = completion.choices[0]?.message?.content;
  if (!text) throw new Error("Empty response from Groq");

  let parsed: { phases: RoadmapPhaseAI[] };
  try {
    parsed = JSON.parse(text);
  } catch {
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error("Could not parse JSON from Groq response");
    parsed = JSON.parse(jsonMatch[0]);
  }

  if (!parsed.phases || !Array.isArray(parsed.phases) || parsed.phases.length === 0) {
    throw new Error("Groq returned no roadmap phases");
  }

  return parsed;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing authorization" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Invalid token" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body: RequestBody = await req.json();
    if (!body.career_goal) {
      return new Response(JSON.stringify({ error: "Missing career goal" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const prompt = buildPrompt(body);
    const result = await callGroq(prompt, body.groq_api_key);

    // Save roadmap to database
    await supabase.from("roadmaps").delete().eq("user_id", user.id);

    const { data: roadmap, error: roadmapError } = await supabase
      .from("roadmaps")
      .insert({ user_id: user.id, career_goal: body.career_goal })
      .select()
      .single();

    if (roadmapError || !roadmap) {
      throw new Error("Failed to create roadmap record");
    }

    let globalOrder = 0;
    for (const phase of result.phases) {
      const { data: phaseRow, error: phaseError } = await supabase
        .from("roadmap_phases")
        .insert({
          roadmap_id: roadmap.id,
          phase_number: phase.phase_number,
          title: phase.title,
          description: phase.description,
        })
        .select()
        .single();

      if (phaseError || !phaseRow) {
        throw new Error(`Failed to create phase ${phase.phase_number}`);
      }

      const topicInserts = phase.topics.map((t) => ({
        roadmap_id: roadmap.id,
        phase_id: phaseRow.id,
        topic_name: t.topic_name,
        description: t.description,
        order_index: globalOrder++,
        priority: t.priority,
        estimated_hours: t.estimated_hours,
        target_proficiency: t.target_proficiency,
        prerequisites: t.prerequisites || [],
        resources: t.resources || [],
        practice: t.practice || [],
        subtopics: t.subtopics || [],
        status: "NOT_STARTED",
        current_proficiency: 0,
      }));

      const { error: topicError } = await supabase.from("roadmap_topics").insert(topicInserts);
      if (topicError) {
        throw new Error(`Failed to create topics for phase ${phase.phase_number}: ${topicError.message}`);
      }
    }

    await supabase
      .from("student_profiles")
      .update({ roadmap_generated: true })
      .eq("user_id", user.id);

    return new Response(JSON.stringify({ roadmap_id: roadmap.id, phases: result.phases }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
