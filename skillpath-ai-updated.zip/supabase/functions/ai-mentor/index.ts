import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import OpenAI from "https://esm.sh/openai@4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface RequestBody {
  question: string;
  context: {
    career_goal: string;
    completed_topics: string[];
    active_weaknesses: string[];
    current_topic: string | null;
  };
  groq_api_key?: string;
  /** Optional base64 data URL of an image the student attached to their question. */
  image?: string;
}

const TEXT_MODEL = "openai/gpt-oss-20b";
const VISION_MODEL = "qwen/qwen3.8-27b";
const MAX_IMAGE_DATA_URL_LENGTH = 6 * 1024 * 1024; // ~6MB, well under Groq's 20MB request cap

function buildPrompt(body: RequestBody, hasImage: boolean): string {
  return `You are SkillPath AI, a personal mentor for a student learning software engineering.

STUDENT CONTEXT:
- Career goal: ${body.context.career_goal}
- Completed topics: ${body.context.completed_topics.join(", ") || "None yet"}
- Active weaknesses: ${body.context.active_weaknesses.join(", ") || "None"}
- Currently studying: ${body.context.current_topic || "Nothing specific right now"}

STUDENT QUESTION: ${body.question || (hasImage ? "(No text was typed — the student only attached an image. Look at the image and figure out what they most likely need help with.)" : "")}
${hasImage ? "\nThe student has attached an image along with their question (this could be a code screenshot, an error message, a diagram, handwritten notes, or a whiteboard problem). Carefully look at the image and address it directly and specifically in your answer — for example, point out the exact line, symbol, or part of the image you're referring to." : ""}

Provide a helpful, specific, and encouraging response. Keep it concise (2-4 paragraphs). If the question is about what to study next, reference their actual progress. If it's a technical question, explain clearly. If it's about career advice, be practical and specific to their goal.

Do not use markdown headers. Use plain text with short paragraphs.`;
}

async function callGroq(prompt: string, image: string | undefined, apiKeyFromClient?: string): Promise<string> {
  const apiKey = Deno.env.get("GROQ_API_KEY") || apiKeyFromClient;
  if (!apiKey) throw new Error("GROQ_API_KEY not configured");

  const client = new OpenAI({
    apiKey,
    baseURL: "https://api.groq.com/openai/v1",
  });

  const content = image
    ? [
        { type: "text", text: prompt },
        { type: "image_url", image_url: { url: image } },
      ]
    : prompt;

  const completion = await client.chat.completions.create({
    model: image ? VISION_MODEL : TEXT_MODEL,
    messages: [{ role: "user", content }],
    temperature: 0.7,
    max_tokens: 2048,
  });

  const text = completion.choices[0]?.message?.content;
  if (!text) throw new Error("Empty response from Groq");
  return text.trim();
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing authorization" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Invalid token" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body: RequestBody = await req.json();
    if (!body.question && !body.image) {
      return new Response(JSON.stringify({ error: "Missing question" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (body.image) {
      if (!/^data:image\/(png|jpe?g|webp|gif);base64,/.test(body.image)) {
        return new Response(JSON.stringify({ error: "Invalid image format" }), {
          status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (body.image.length > MAX_IMAGE_DATA_URL_LENGTH) {
        return new Response(JSON.stringify({ error: "Image is too large" }), {
          status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    }

    const prompt = buildPrompt(body, Boolean(body.image));
    const answer = await callGroq(prompt, body.image, body.groq_api_key);

    return new Response(JSON.stringify({ answer }), {
      status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return new Response(JSON.stringify({ error: message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
