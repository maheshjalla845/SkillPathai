import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import OpenAI from "https://esm.sh/openai@4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface QuestionResult {
  topic: string;
  subtopic: string;
  is_correct: boolean;
  difficulty: string;
  question_text: string;
  selected_answer: string;
  correct_answer: string;
}

interface RequestBody {
  assessment_id: string;
  questions: QuestionResult[];
  groq_api_key?: string;
}

interface WeaknessAI {
  topic: string;
  subtopic: string;
  priority: "HIGH" | "MEDIUM" | "LOW";
  explanation: string;
  recommended_actions: string[];
}

function buildPrompt(questions: QuestionResult[]): string {
  const wrongAnswers = questions.filter((q) => !q.is_correct);
  const correctCount = questions.length - wrongAnswers.length;

  const questionDetails = questions.map((q) => ({
    topic: q.topic,
    subtopic: q.subtopic,
    correct: q.is_correct,
    difficulty: q.difficulty,
    question: q.question_text,
    student_answer: q.selected_answer || "(no answer)",
    correct_answer: q.correct_answer,
  }));

  return `You are an expert educator analyzing assessment results to identify learning weaknesses.

ASSESSMENT RESULTS:
- Total questions: ${questions.length}
- Correct answers: ${correctCount}
- Wrong answers: ${wrongAnswers.length}

QUESTION DETAILS (JSON):
${JSON.stringify(questionDetails, null, 2)}

TASK: Analyze the wrong answers and identify specific learning weaknesses. Group related mistakes by topic and subtopic. For each weakness:
1. Determine priority: HIGH (fundamental concept missed, or multiple errors in topic), MEDIUM (important but not critical), LOW (minor or edge case)
2. Write a clear explanation of WHY the student got it wrong and WHAT they don't understand
3. Recommend 2-4 specific actions to improve (e.g., "Review binary search algorithm", "Practice loop conditions on HackerRank")

Return a JSON object:
{
  "weaknesses": [
    {
      "topic": "topic name",
      "subtopic": "specific subtopic or null",
      "priority": "HIGH" | "MEDIUM" | "LOW",
      "explanation": "clear explanation of the weakness",
      "recommended_actions": ["action 1", "action 2"]
    }
  ]
}

If all answers are correct, return an empty weaknesses array.
Only include weaknesses for topics where the student got at least one question wrong.

IMPORTANT: Return ONLY the JSON object, no markdown, no explanation.`;
}

async function callGroq(prompt: string, apiKeyFromClient?: string): Promise<{ weaknesses: WeaknessAI[] }> {
  const apiKey = Deno.env.get("GROQ_API_KEY") || apiKeyFromClient;
  if (!apiKey) throw new Error("GROQ_API_KEY not configured");

  const client = new OpenAI({
    apiKey,
    baseURL: "https://api.groq.com/openai/v1",
  });

  const completion = await client.chat.completions.create({
    model: "openai/gpt-oss-20b",
    messages: [{ role: "user", content: prompt }],
    temperature: 0.5,
    max_tokens: 4096,
    response_format: { type: "json_object" },
  });

  const text = completion.choices[0]?.message?.content;
  if (!text) throw new Error("Empty response from Groq");

  let parsed: { weaknesses: WeaknessAI[] };
  try {
    parsed = JSON.parse(text);
  } catch {
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error("Could not parse JSON from Groq response");
    parsed = JSON.parse(jsonMatch[0]);
  }

  return parsed;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing authorization" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Invalid token" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body: RequestBody = await req.json();
    if (!body.assessment_id || !body.questions) {
      return new Response(JSON.stringify({ error: "Missing required fields" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const prompt = buildPrompt(body.questions);
    const result = await callGroq(prompt, body.groq_api_key);

    // Save weaknesses to database
    const topics = result.weaknesses.map((w) => w.topic);
    if (topics.length > 0) {
      for (const topic of topics) {
        await supabase
          .from("weaknesses")
          .update({ status: "resolved", resolved_at: new Date().toISOString() })
          .eq("user_id", user.id)
          .eq("topic", topic)
          .in("status", ["active", "recurring"]);
      }
    }

    for (const w of result.weaknesses) {
      const score = Math.round(
        (body.questions.filter((q) => q.topic === w.topic && q.is_correct).length /
          Math.max(1, body.questions.filter((q) => q.topic === w.topic).length)) * 100
      );

      const { data: weaknessRow, error: weaknessError } = await supabase
        .from("weaknesses")
        .insert({
          user_id: user.id,
          topic: w.topic,
          subtopic: w.subtopic || null,
          priority: w.priority,
          status: "active",
          score,
          explanation: w.explanation,
          recommended_actions: w.recommended_actions,
        })
        .select()
        .single();

      if (!weaknessError && weaknessRow) {
        await supabase.from("weakness_history").insert({
          weakness_id: weaknessRow.id,
          user_id: user.id,
          topic: w.topic,
          subtopic: w.subtopic || null,
          score,
        });
      }
    }

    return new Response(JSON.stringify({ weaknesses: result.weaknesses }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
