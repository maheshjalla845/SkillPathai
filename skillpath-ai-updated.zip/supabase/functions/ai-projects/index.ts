import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import OpenAI from "https://esm.sh/openai@4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface RequestBody {
  career_goal: string;
  completed_skills: string[];
  active_weaknesses: string[];
  existing_projects: string[];
  groq_api_key?: string;
}

interface ProjectAI {
  title: string;
  description: string;
  difficulty: "Easy" | "Medium" | "Hard";
  estimated_duration: string;
  required_skills: string[];
  features: string[];
  learning_outcomes: string[];
  completion_checklist: string[];
}

function buildPrompt(body: RequestBody): string {
  return `You are an expert project recommender for software engineering students.

STUDENT PROFILE:
- Career goal: ${body.career_goal}
- Completed skills: ${body.completed_skills.join(", ") || "None yet"}
- Active weaknesses: ${body.active_weaknesses.join(", ") || "None"}
- Existing projects: ${body.existing_projects.join(", ") || "None"}

TASK: Recommend 3 projects that:
1. Match the student's current skill level (use completed skills)
2. Help address their weaknesses
3. Are relevant to their career goal
4. Are NOT duplicates of existing projects
5. Progress in difficulty (one easier, one medium, one more challenging)

Return JSON:
{
  "projects": [
    {
      "title": "Project name",
      "description": "2-3 sentence description",
      "difficulty": "Easy" | "Medium" | "Hard",
      "estimated_duration": "e.g., 1-2 weeks",
      "required_skills": ["skill1", "skill2"],
      "features": ["feature 1", "feature 2", "feature 3"],
      "learning_outcomes": ["what they will learn 1", "what they will learn 2"],
      "completion_checklist": ["checklist item 1", "checklist item 2"]
    }
  ]
}

IMPORTANT: Return ONLY the JSON object, no markdown, no explanation.`;
}

async function callGroq(prompt: string, apiKeyFromClient?: string): Promise<{ projects: ProjectAI[] }> {
  const apiKey = Deno.env.get("GROQ_API_KEY") || apiKeyFromClient;
  if (!apiKey) throw new Error("GROQ_API_KEY not configured");

  const client = new OpenAI({
    apiKey,
    baseURL: "https://api.groq.com/openai/v1",
  });

  const completion = await client.chat.completions.create({
    model: "openai/gpt-oss-20b",
    messages: [{ role: "user", content: prompt }],
    temperature: 0.7,
    max_tokens: 8192,
    response_format: { type: "json_object" },
  });

  const text = completion.choices[0]?.message?.content;
  if (!text) throw new Error("Empty response from Groq");

  let parsed: { projects: ProjectAI[] };
  try {
    parsed = JSON.parse(text);
  } catch {
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error("Could not parse JSON from Groq response");
    parsed = JSON.parse(jsonMatch[0]);
  }

  return parsed;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing authorization" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Invalid token" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body: RequestBody = await req.json();
    const prompt = buildPrompt(body);
    const result = await callGroq(prompt, body.groq_api_key);

    if (result.projects && result.projects.length > 0) {
      const inserts = result.projects.map((p) => ({
        user_id: user.id,
        title: p.title,
        description: p.description,
        difficulty: p.difficulty,
        estimated_duration: p.estimated_duration,
        required_skills: p.required_skills || [],
        features: p.features || [],
        learning_outcomes: p.learning_outcomes || [],
        completion_checklist: p.completion_checklist || [],
        status: "RECOMMENDED",
      }));

      await supabase.from("projects").insert(inserts);
    }

    return new Response(JSON.stringify({ projects: result.projects || [] }), {
      status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return new Response(JSON.stringify({ error: message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
