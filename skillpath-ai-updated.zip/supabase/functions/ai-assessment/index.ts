import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import OpenAI from "https://esm.sh/openai@4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface QuestionPayload {
  question_text: string;
  question_type: string;
  topic: string;
  subtopic: string;
  difficulty: string;
  options: string[] | null;
  correct_answer: string;
}

interface RequestBody {
  assessment_type: "diagnostic" | "topic";
  career_goal: string;
  skills: { skill_name: string; level: string }[];
  topic_name?: string;
  groq_api_key?: string;
}

function buildPrompt(body: RequestBody): string {
  const skillsList = body.skills.length > 0
    ? body.skills.map((s) => `${s.skill_name} (${s.level})`).join(", ")
    : "No skills reported";

  if (body.assessment_type === "diagnostic") {
    return `You are an expert technical interviewer and educator creating a diagnostic assessment.

STUDENT PROFILE:
- Career goal: ${body.career_goal}
- Self-reported skills: ${skillsList}

TASK: Generate exactly 10 diagnostic questions that span multiple question types and difficulty levels. These questions must:
1. Test the student's ACTUAL knowledge across their reported skills
2. Include a mix of: mcq, code_output, debugging, conceptual, scenario
3. Include a mix of difficulty: easy, medium, hard
4. For each skill the student claims, include at least one question
5. If the student reports no skills, test fundamental CS concepts (data structures, algorithms, programming basics)

Return a JSON array of exactly 10 question objects. Each object MUST have:
- "question_text": string (the question)
- "question_type": one of "mcq", "code_output", "debugging", "conceptual", "scenario"
- "topic": string (the skill/subject being tested, e.g. "Python", "DSA", "SQL")
- "subtopic": string (specific area, e.g. "loops", "binary search", "joins")
- "difficulty": one of "easy", "medium", "hard"
- "options": string[] | null (4 options for mcq, null for others)
- "correct_answer": string (the correct option for mcq, or the correct answer/explanation for others)

IMPORTANT: Return ONLY the JSON array, no markdown, no explanation.`;
  }

  return `You are an expert technical interviewer creating a topic assessment.

TOPIC: ${body.topic_name}
STUDENT CAREER GOAL: ${body.career_goal}
STUDENT SKILLS: ${skillsList}

TASK: Generate exactly 8 questions assessing the student's knowledge of "${body.topic_name}". These questions must:
1. Cover different subtopics within "${body.topic_name}"
2. Include a mix of: mcq, code_output, debugging, conceptual, scenario, practical
3. Include a mix of difficulty: easy, medium, hard
4. Test both conceptual understanding and practical application

Return a JSON array of exactly 8 question objects. Each object MUST have:
- "question_text": string
- "question_type": one of "mcq", "code_output", "debugging", "conceptual", "scenario", "practical"
- "topic": "${body.topic_name}"
- "subtopic": string
- "difficulty": one of "easy", "medium", "hard"
- "options": string[] | null (4 options for mcq, null for others)
- "correct_answer": string

IMPORTANT: Return ONLY the JSON array, no markdown, no explanation.`;
}

async function callGroq(prompt: string, apiKeyFromClient?: string): Promise<QuestionPayload[]> {
  const apiKey = Deno.env.get("GROQ_API_KEY") || apiKeyFromClient;
  if (!apiKey) throw new Error("GROQ_API_KEY not configured");

  const client = new OpenAI({
    apiKey,
    baseURL: "https://api.groq.com/openai/v1",
  });

  const completion = await client.chat.completions.create({
    model: "openai/gpt-oss-20b",
    messages: [{ role: "user", content: prompt }],
    temperature: 0.7,
    max_tokens: 8192,
    response_format: { type: "json_object" },
  });

  const text = completion.choices[0]?.message?.content;
  if (!text) throw new Error("Empty response from Groq");

  let parsed: QuestionPayload[];
  try {
    const obj = JSON.parse(text);
    parsed = Array.isArray(obj) ? obj : obj.questions || obj.data || [];
  } catch {
    const jsonMatch = text.match(/\[[\s\S]*\]/);
    if (!jsonMatch) throw new Error("Could not parse JSON from Groq response");
    parsed = JSON.parse(jsonMatch[0]);
  }

  if (!Array.isArray(parsed) || parsed.length === 0) {
    throw new Error("Groq returned no questions");
  }

  return parsed;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing authorization" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Invalid token" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body: RequestBody = await req.json();
    if (!body.assessment_type || !body.career_goal) {
      return new Response(JSON.stringify({ error: "Missing required fields" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const prompt = buildPrompt(body);
    const questions = await callGroq(prompt, body.groq_api_key);

    return new Response(JSON.stringify({ questions }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
