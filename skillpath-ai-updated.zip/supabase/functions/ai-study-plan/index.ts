import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import OpenAI from "https://esm.sh/openai@4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface RequestBody {
  available_minutes: number;
  roadmap_topics: { topic_name: string; status: string; current_proficiency: number; target_proficiency: number }[];
  active_weaknesses: { topic: string; priority: string }[];
  groq_api_key?: string;
}

function buildPrompt(body: RequestBody): string {
  const inProgress = body.roadmap_topics.filter((t) => t.status === "IN_PROGRESS");
  const notStarted = body.roadmap_topics.filter((t) => t.status === "NOT_STARTED").slice(0, 5);
  const needsRevision = body.roadmap_topics.filter((t) => t.status === "NEEDS_REVISION");

  return `You are a personal AI study planner. Create a focused, actionable study plan for today.

AVAILABLE TIME: ${body.available_minutes} minutes

CURRENTLY LEARNING (in progress):
${inProgress.map((t) => `- ${t.topic_name} (${t.current_proficiency}/${t.target_proficiency}% proficiency)`).join("\n") || "None"}

NEEDS REVISION:
${needsRevision.map((t) => `- ${t.topic_name} (${t.current_proficiency}% proficiency)`).join("\n") || "None"}

ACTIVE WEAKNESSES:
${body.active_weaknesses.map((w) => `- ${w.topic} (${w.priority} priority)`).join("\n") || "None"}

NEXT UP (not started):
${notStarted.map((t) => `- ${t.topic_name}`).join("\n") || "None"}

TASK: Create a study plan that fits within ${body.available_minutes} minutes. Prioritize:
1. Fixing HIGH priority weaknesses (if any)
2. Continuing in-progress topics
3. Revising topics that need revision
4. Starting new topics if time permits

Return JSON:
{
  "plan": [
    {
      "activity": "What to do",
      "topic": "topic name",
      "duration_minutes": 30,
      "type": "learn" | "practice" | "revise" | "assess",
      "details": "Specific instructions on what to study or practice"
    }
  ]
}

Keep the plan realistic for the time available. Each activity should be 15-60 minutes.

IMPORTANT: Return ONLY the JSON object, no markdown, no explanation.`;
}

async function callGroq(prompt: string, apiKeyFromClient?: string) {
  const apiKey = Deno.env.get("GROQ_API_KEY") || apiKeyFromClient;
  if (!apiKey) throw new Error("GROQ_API_KEY not configured");

  const client = new OpenAI({
    apiKey,
    baseURL: "https://api.groq.com/openai/v1",
  });

  const completion = await client.chat.completions.create({
    model: "openai/gpt-oss-20b",
    messages: [{ role: "user", content: prompt }],
    temperature: 0.6,
    max_tokens: 4096,
    response_format: { type: "json_object" },
  });

  const text = completion.choices[0]?.message?.content;
  if (!text) throw new Error("Empty response from Groq");

  try {
    return JSON.parse(text);
  } catch {
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error("Could not parse JSON from Groq response");
    return JSON.parse(jsonMatch[0]);
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing authorization" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Invalid token" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body: RequestBody = await req.json();
    const prompt = buildPrompt(body);
    const result = await callGroq(prompt, body.groq_api_key);

    await supabase.from("study_plans").upsert({
      user_id: user.id,
      plan_date: new Date().toISOString().split("T")[0],
      available_minutes: body.available_minutes,
      plan_content: result.plan || [],
    });

    return new Response(JSON.stringify({ plan: result.plan || [] }), {
      status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return new Response(JSON.stringify({ error: message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
