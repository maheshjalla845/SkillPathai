import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import OpenAI from "https://esm.sh/openai@4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface RequestBody {
  career_goal: string;
  skill_profile: { skill: string; proficiency: number }[];
  completed_topics: string[];
  total_topics: number;
  groq_api_key?: string;
}

function buildPrompt(body: RequestBody): string {
  const skillsList = body.skill_profile.length > 0
    ? body.skill_profile.map((s) => `${s.skill}: ${s.proficiency}%`).join(", ")
    : "No skills assessed yet";

  const progressPct = body.total_topics > 0
    ? Math.round((body.completed_topics.length / body.total_topics) * 100)
    : 0;

  return `You are an expert career advisor analyzing a student's readiness for their target role.

STUDENT PROFILE:
- Career goal: ${body.career_goal}
- Skill proficiency: ${skillsList}
- Roadmap progress: ${progressPct}% (${body.completed_topics.length}/${body.total_topics} topics completed)
- Completed topics: ${body.completed_topics.join(", ") || "None yet"}

TASK: Provide a comprehensive career analysis. Return JSON:
{
  "analysis": {
    "job_readiness_score": 0-100,
    "readiness_level": "Early Stage" | "Building Foundation" | "Approaching Readiness" | "Job Ready",
    "strengths": ["strength 1", "strength 2"],
    "gaps": ["missing skill 1", "missing skill 2"],
    "recommended_focus": ["what to focus on next 1", "what to focus on next 2"],
    "job_titles": ["job title they can apply for now or soon"],
    "estimated_weeks_to_ready": 12,
    "advice": "2-3 sentences of personalized career advice"
  }
}

IMPORTANT: Return ONLY the JSON object, no markdown, no explanation.`;
}

async function callGroq(prompt: string, apiKeyFromClient?: string) {
  const apiKey = Deno.env.get("GROQ_API_KEY") || apiKeyFromClient;
  if (!apiKey) throw new Error("GROQ_API_KEY not configured");

  const client = new OpenAI({
    apiKey,
    baseURL: "https://api.groq.com/openai/v1",
  });

  const completion = await client.chat.completions.create({
    model: "openai/gpt-oss-20b",
    messages: [{ role: "user", content: prompt }],
    temperature: 0.6,
    max_tokens: 4096,
    response_format: { type: "json_object" },
  });

  const text = completion.choices[0]?.message?.content;
  if (!text) throw new Error("Empty response from Groq");

  try {
    return JSON.parse(text);
  } catch {
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error("Could not parse JSON from Groq response");
    return JSON.parse(jsonMatch[0]);
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing authorization" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Invalid token" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body: RequestBody = await req.json();
    const prompt = buildPrompt(body);
    const result = await callGroq(prompt, body.groq_api_key);

    return new Response(JSON.stringify({ analysis: result.analysis }), {
      status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return new Response(JSON.stringify({ error: message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
