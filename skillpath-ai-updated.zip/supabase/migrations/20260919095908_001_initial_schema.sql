/*
# SkillPath AI — Initial Database Schema

1. Purpose
   Multi-user career learning platform. Every user's data is completely isolated
   via Row Level Security. All private tables are owner-scoped to auth.uid().

2. New Tables
   - student_profiles: per-user onboarding/profile data
   - student_skills: self-reported and verified skill levels
   - roadmaps: top-level roadmap per user
   - roadmap_phases: ordered phases within a roadmap
   - roadmap_topics: topics within phases, with status and proficiency
   - assessments: assessment metadata (diagnostic + topic)
   - assessment_questions: individual questions and answers
   - weaknesses: detected weaknesses from assessment mistakes
   - weakness_history: score tracking over time per weakness
   - study_sessions: real learning sessions (for streak and hours)
   - dsa_problems: DSA problem tracking
   - contests: public contest catalog (shared, not user-owned)
   - contest_participations: user's contest participation records
   - projects: project recommendations and progress
   - study_plans: AI-generated daily study plans

3. Security
   - RLS enabled on ALL tables.
   - User-owned tables use auth.uid() = user_id ownership checks.
   - contests table is publicly readable (shared contest catalog).
   - Owner columns default to auth.uid() so frontend inserts work without
     explicitly passing user_id.

4. Important Notes
   - No demo data is seeded. Every user starts at zero.
   - All timestamps default to now().
   - Foreign keys use ON DELETE CASCADE for owned child tables.
*/

-- Student profiles
CREATE TABLE IF NOT EXISTS student_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL UNIQUE DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text,
  education text,
  college text,
  year text,
  experience text,
  career_goal text,
  custom_career_goal text,
  academic_background text,
  study_time_per_day text,
  learning_preference text,
  onboarding_completed boolean NOT NULL DEFAULT false,
  diagnostic_completed boolean NOT NULL DEFAULT false,
  roadmap_generated boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE student_profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_profile" ON student_profiles;
CREATE POLICY "select_own_profile" ON student_profiles FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_profile" ON student_profiles;
CREATE POLICY "insert_own_profile" ON student_profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_profile" ON student_profiles;
CREATE POLICY "update_own_profile" ON student_profiles FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Student skills
CREATE TABLE IF NOT EXISTS student_skills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  skill_name text NOT NULL,
  level text NOT NULL DEFAULT 'Beginner',
  verified_proficiency integer,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, skill_name)
);

ALTER TABLE student_skills ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_skills" ON student_skills;
CREATE POLICY "select_own_skills" ON student_skills FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_skills" ON student_skills;
CREATE POLICY "insert_own_skills" ON student_skills FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_skills" ON student_skills;
CREATE POLICY "update_own_skills" ON student_skills FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_skills" ON student_skills;
CREATE POLICY "delete_own_skills" ON student_skills FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Roadmaps
CREATE TABLE IF NOT EXISTS roadmaps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  career_goal text NOT NULL,
  generated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE roadmaps ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_roadmaps" ON roadmaps;
CREATE POLICY "select_own_roadmaps" ON roadmaps FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_roadmaps" ON roadmaps;
CREATE POLICY "insert_own_roadmaps" ON roadmaps FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_roadmaps" ON roadmaps;
CREATE POLICY "delete_own_roadmaps" ON roadmaps FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Roadmap phases
CREATE TABLE IF NOT EXISTS roadmap_phases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  roadmap_id uuid NOT NULL REFERENCES roadmaps(id) ON DELETE CASCADE,
  phase_number integer NOT NULL,
  title text NOT NULL,
  description text
);

ALTER TABLE roadmap_phases ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_phases" ON roadmap_phases;
CREATE POLICY "select_own_phases" ON roadmap_phases FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM roadmaps WHERE roadmaps.id = roadmap_phases.roadmap_id AND roadmaps.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "insert_own_phases" ON roadmap_phases;
CREATE POLICY "insert_own_phases" ON roadmap_phases FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM roadmaps WHERE roadmaps.id = roadmap_phases.roadmap_id AND roadmaps.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "delete_own_phases" ON roadmap_phases;
CREATE POLICY "delete_own_phases" ON roadmap_phases FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM roadmaps WHERE roadmaps.id = roadmap_phases.roadmap_id AND roadmaps.user_id = auth.uid())
  );

-- Roadmap topics
CREATE TABLE IF NOT EXISTS roadmap_topics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  roadmap_id uuid NOT NULL REFERENCES roadmaps(id) ON DELETE CASCADE,
  phase_id uuid NOT NULL REFERENCES roadmap_phases(id) ON DELETE CASCADE,
  topic_name text NOT NULL,
  description text,
  order_index integer NOT NULL DEFAULT 0,
  priority text NOT NULL DEFAULT 'medium',
  estimated_hours numeric NOT NULL DEFAULT 0,
  target_proficiency integer NOT NULL DEFAULT 80,
  prerequisites text[] NOT NULL DEFAULT '{}',
  resources text[] NOT NULL DEFAULT '{}',
  practice text[] NOT NULL DEFAULT '{}',
  subtopics text[] NOT NULL DEFAULT '{}',
  status text NOT NULL DEFAULT 'NOT_STARTED',
  current_proficiency integer NOT NULL DEFAULT 0,
  started_at timestamptz,
  completed_at timestamptz
);

ALTER TABLE roadmap_topics ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_topics" ON roadmap_topics;
CREATE POLICY "select_own_topics" ON roadmap_topics FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM roadmaps WHERE roadmaps.id = roadmap_topics.roadmap_id AND roadmaps.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "insert_own_topics" ON roadmap_topics;
CREATE POLICY "insert_own_topics" ON roadmap_topics FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM roadmaps WHERE roadmaps.id = roadmap_topics.roadmap_id AND roadmaps.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "update_own_topics" ON roadmap_topics;
CREATE POLICY "update_own_topics" ON roadmap_topics FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM roadmaps WHERE roadmaps.id = roadmap_topics.roadmap_id AND roadmaps.user_id = auth.uid())
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM roadmaps WHERE roadmaps.id = roadmap_topics.roadmap_id AND roadmaps.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "delete_own_topics" ON roadmap_topics;
CREATE POLICY "delete_own_topics" ON roadmap_topics FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM roadmaps WHERE roadmaps.id = roadmap_topics.roadmap_id AND roadmaps.user_id = auth.uid())
  );

-- Assessments
CREATE TABLE IF NOT EXISTS assessments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  type text NOT NULL DEFAULT 'topic',
  topic_name text,
  total_questions integer NOT NULL DEFAULT 0,
  score integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE assessments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_assessments" ON assessments;
CREATE POLICY "select_own_assessments" ON assessments FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_assessments" ON assessments;
CREATE POLICY "insert_own_assessments" ON assessments FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_assessments" ON assessments;
CREATE POLICY "delete_own_assessments" ON assessments FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Assessment questions
CREATE TABLE IF NOT EXISTS assessment_questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  assessment_id uuid NOT NULL REFERENCES assessments(id) ON DELETE CASCADE,
  question_text text NOT NULL,
  question_type text NOT NULL DEFAULT 'mcq',
  topic text NOT NULL,
  subtopic text,
  difficulty text NOT NULL DEFAULT 'medium',
  options text[],
  correct_answer text NOT NULL,
  selected_answer text,
  is_correct boolean,
  time_taken_seconds integer
);

ALTER TABLE assessment_questions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_questions" ON assessment_questions;
CREATE POLICY "select_own_questions" ON assessment_questions FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM assessments WHERE assessments.id = assessment_questions.assessment_id AND assessments.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "insert_own_questions" ON assessment_questions;
CREATE POLICY "insert_own_questions" ON assessment_questions FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM assessments WHERE assessments.id = assessment_questions.assessment_id AND assessments.user_id = auth.uid())
  );

-- Weaknesses
CREATE TABLE IF NOT EXISTS weaknesses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  topic text NOT NULL,
  subtopic text,
  priority text NOT NULL DEFAULT 'MEDIUM',
  status text NOT NULL DEFAULT 'active',
  score integer NOT NULL DEFAULT 0,
  explanation text NOT NULL DEFAULT '',
  recommended_actions text[] NOT NULL DEFAULT '{}',
  detected_at timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz
);

ALTER TABLE weaknesses ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_weaknesses" ON weaknesses;
CREATE POLICY "select_own_weaknesses" ON weaknesses FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_weaknesses" ON weaknesses;
CREATE POLICY "insert_own_weaknesses" ON weaknesses FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_weaknesses" ON weaknesses;
CREATE POLICY "update_own_weaknesses" ON weaknesses FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_weaknesses" ON weaknesses;
CREATE POLICY "delete_own_weaknesses" ON weaknesses FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Weakness history
CREATE TABLE IF NOT EXISTS weakness_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  weakness_id uuid NOT NULL REFERENCES weaknesses(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  topic text NOT NULL,
  subtopic text,
  score integer NOT NULL DEFAULT 0,
  assessed_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE weakness_history ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_weakness_history" ON weakness_history;
CREATE POLICY "select_own_weakness_history" ON weakness_history FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_weakness_history" ON weakness_history;
CREATE POLICY "insert_own_weakness_history" ON weakness_history FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

-- Study sessions
CREATE TABLE IF NOT EXISTS study_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  topic_name text NOT NULL,
  duration_minutes integer NOT NULL DEFAULT 0,
  activity_type text NOT NULL DEFAULT 'learning',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE study_sessions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_sessions" ON study_sessions;
CREATE POLICY "select_own_sessions" ON study_sessions FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_sessions" ON study_sessions;
CREATE POLICY "insert_own_sessions" ON study_sessions FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_sessions" ON study_sessions;
CREATE POLICY "delete_own_sessions" ON study_sessions FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- DSA problems
CREATE TABLE IF NOT EXISTS dsa_problems (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  problem_name text NOT NULL,
  topic text NOT NULL,
  difficulty text NOT NULL DEFAULT 'Easy',
  platform text NOT NULL DEFAULT 'Manual',
  attempts integer NOT NULL DEFAULT 1,
  time_spent_minutes integer NOT NULL DEFAULT 0,
  solved boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE dsa_problems ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_dsa" ON dsa_problems;
CREATE POLICY "select_own_dsa" ON dsa_problems FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_dsa" ON dsa_problems;
CREATE POLICY "insert_own_dsa" ON dsa_problems FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_dsa" ON dsa_problems;
CREATE POLICY "update_own_dsa" ON dsa_problems FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_dsa" ON dsa_problems;
CREATE POLICY "delete_own_dsa" ON dsa_problems FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Contests (shared public catalog — not user-owned)
CREATE TABLE IF NOT EXISTS contests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  platform text NOT NULL,
  start_time timestamptz NOT NULL,
  duration_seconds integer NOT NULL DEFAULT 7200,
  url text NOT NULL DEFAULT '',
  difficulty text
);

ALTER TABLE contests ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_contests" ON contests;
CREATE POLICY "select_contests" ON contests FOR SELECT
  TO anon, authenticated USING (true);

-- Contest participations (user-owned)
CREATE TABLE IF NOT EXISTS contest_participations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  contest_id uuid REFERENCES contests(id) ON DELETE SET NULL,
  contest_name text,
  platform text,
  problems_attempted integer NOT NULL DEFAULT 0,
  problems_solved integer NOT NULL DEFAULT 0,
  time_taken_minutes integer NOT NULL DEFAULT 0,
  wrong_submissions integer NOT NULL DEFAULT 0,
  rating integer,
  participated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE contest_participations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_participations" ON contest_participations;
CREATE POLICY "select_own_participations" ON contest_participations FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_participations" ON contest_participations;
CREATE POLICY "insert_own_participations" ON contest_participations FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_participations" ON contest_participations;
CREATE POLICY "update_own_participations" ON contest_participations FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_participations" ON contest_participations;
CREATE POLICY "delete_own_participations" ON contest_participations FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Projects (user-owned — recommendations and progress)
CREATE TABLE IF NOT EXISTS projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text NOT NULL DEFAULT '',
  difficulty text NOT NULL DEFAULT 'Medium',
  estimated_duration text NOT NULL DEFAULT '1-2 weeks',
  required_skills text[] NOT NULL DEFAULT '{}',
  features text[] NOT NULL DEFAULT '{}',
  learning_outcomes text[] NOT NULL DEFAULT '{}',
  completion_checklist text[] NOT NULL DEFAULT '{}',
  status text NOT NULL DEFAULT 'RECOMMENDED',
  started_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE projects ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_projects" ON projects;
CREATE POLICY "select_own_projects" ON projects FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_projects" ON projects;
CREATE POLICY "insert_own_projects" ON projects FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_projects" ON projects;
CREATE POLICY "update_own_projects" ON projects FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_projects" ON projects;
CREATE POLICY "delete_own_projects" ON projects FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Study plans (AI-generated daily plans)
CREATE TABLE IF NOT EXISTS study_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  plan_date date NOT NULL DEFAULT CURRENT_DATE,
  available_minutes integer NOT NULL DEFAULT 120,
  plan_content jsonb NOT NULL DEFAULT '[]',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, plan_date)
);

ALTER TABLE study_plans ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_plans" ON study_plans;
CREATE POLICY "select_own_plans" ON study_plans FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_plans" ON study_plans;
CREATE POLICY "insert_own_plans" ON study_plans FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_plans" ON study_plans;
CREATE POLICY "update_own_plans" ON study_plans FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_plans" ON study_plans;
CREATE POLICY "delete_own_plans" ON study_plans FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_student_profiles_user_id ON student_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_student_skills_user_id ON student_skills(user_id);
CREATE INDEX IF NOT EXISTS idx_roadmaps_user_id ON roadmaps(user_id);
CREATE INDEX IF NOT EXISTS idx_roadmap_topics_roadmap_id ON roadmap_topics(roadmap_id);
CREATE INDEX IF NOT EXISTS idx_roadmap_topics_status ON roadmap_topics(status);
CREATE INDEX IF NOT EXISTS idx_assessments_user_id ON assessments(user_id);
CREATE INDEX IF NOT EXISTS idx_assessment_questions_assessment_id ON assessment_questions(assessment_id);
CREATE INDEX IF NOT EXISTS idx_weaknesses_user_id ON weaknesses(user_id);
CREATE INDEX IF NOT EXISTS idx_weaknesses_status ON weaknesses(status);
CREATE INDEX IF NOT EXISTS idx_weakness_history_user_id ON weakness_history(user_id);
CREATE INDEX IF NOT EXISTS idx_study_sessions_user_id ON study_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_dsa_problems_user_id ON dsa_problems(user_id);
CREATE INDEX IF NOT EXISTS idx_contest_participations_user_id ON contest_participations(user_id);
CREATE INDEX IF NOT EXISTS idx_projects_user_id ON projects(user_id);
CREATE INDEX IF NOT EXISTS idx_study_plans_user_id ON study_plans(user_id);
CREATE INDEX IF NOT EXISTS idx_contests_start_time ON contests(start_time);
