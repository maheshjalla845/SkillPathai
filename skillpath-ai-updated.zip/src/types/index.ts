export type SkillLevel = 'Beginner' | 'Intermediate' | 'Advanced';

export type LearningPreference = 'Video' | 'Reading' | 'Practice' | 'Projects' | 'Mixed';

export type StudyTimePerDay = '1 hour/day' | '2 hours/day' | '3 hours/day' | '4+ hours/day';

export type TopicStatus = 'NOT_STARTED' | 'IN_PROGRESS' | 'COMPLETED' | 'NEEDS_REVISION';

export type WeaknessPriority = 'HIGH' | 'MEDIUM' | 'LOW';

export type WeaknessStatus = 'active' | 'improving' | 'resolved' | 'recurring';

export type ProjectStatus = 'RECOMMENDED' | 'STARTED' | 'IN_PROGRESS' | 'COMPLETED';

export type AssessmentType = 'diagnostic' | 'topic';

export type QuestionType = 'mcq' | 'code_output' | 'debugging' | 'conceptual' | 'scenario' | 'practical';

export type Difficulty = 'easy' | 'medium' | 'hard';

export type ProblemDifficulty = 'Easy' | 'Medium' | 'Hard';

export type ContestStatus = 'upcoming' | 'ongoing' | 'finished';

export interface StudentProfile {
  id: string;
  user_id: string;
  full_name: string | null;
  education: string | null;
  college: string | null;
  year: string | null;
  experience: string | null;
  career_goal: string | null;
  custom_career_goal: string | null;
  academic_background: string | null;
  study_time_per_day: StudyTimePerDay | null;
  learning_preference: LearningPreference | null;
  onboarding_completed: boolean;
  diagnostic_completed: boolean;
  roadmap_generated: boolean;
  created_at: string;
  updated_at: string;
}

export interface StudentSkill {
  id: string;
  user_id: string;
  skill_name: string;
  level: SkillLevel;
  verified_proficiency: number | null;
  created_at: string;
}

export interface Roadmap {
  id: string;
  user_id: string;
  career_goal: string;
  generated_at: string;
}

export interface RoadmapPhase {
  id: string;
  roadmap_id: string;
  phase_number: number;
  title: string;
  description: string | null;
}

export interface RoadmapTopic {
  id: string;
  roadmap_id: string;
  phase_id: string;
  topic_name: string;
  description: string | null;
  order_index: number;
  priority: 'high' | 'medium' | 'low';
  estimated_hours: number;
  target_proficiency: number;
  prerequisites: string[];
  resources: string[];
  practice: string[];
  status: TopicStatus;
  current_proficiency: number;
  subtopics: string[];
  started_at: string | null;
  completed_at: string | null;
}

export interface Assessment {
  id: string;
  user_id: string;
  type: AssessmentType;
  topic_name: string | null;
  total_questions: number;
  score: number;
  created_at: string;
}

export interface AssessmentQuestion {
  id: string;
  assessment_id: string;
  question_text: string;
  question_type: QuestionType;
  topic: string;
  subtopic: string | null;
  difficulty: Difficulty;
  options: string[] | null;
  correct_answer: string;
  selected_answer: string | null;
  is_correct: boolean | null;
  time_taken_seconds: number | null;
}

export interface Weakness {
  id: string;
  user_id: string;
  topic: string;
  subtopic: string | null;
  priority: WeaknessPriority;
  status: WeaknessStatus;
  score: number;
  explanation: string;
  recommended_actions: string[];
  detected_at: string;
  resolved_at: string | null;
}

export interface WeaknessHistory {
  id: string;
  weakness_id: string;
  user_id: string;
  topic: string;
  subtopic: string | null;
  score: number;
  assessed_at: string;
}

export interface StudySession {
  id: string;
  user_id: string;
  topic_name: string;
  duration_minutes: number;
  activity_type: string;
  created_at: string;
}

export interface DSAProblem {
  id: string;
  user_id: string;
  problem_name: string;
  topic: string;
  difficulty: ProblemDifficulty;
  platform: string;
  attempts: number;
  time_spent_minutes: number;
  solved: boolean;
  created_at: string;
}

export interface Contest {
  id: string;
  name: string;
  platform: string;
  start_time: string;
  duration_seconds: number;
  url: string;
  difficulty: string | null;
}

export interface ContestParticipation {
  id: string;
  user_id: string;
  contest_id: string | null;
  contest_name: string | null;
  platform: string | null;
  problems_attempted: number;
  problems_solved: number;
  time_taken_minutes: number;
  wrong_submissions: number;
  rating: number | null;
  participated_at: string;
}

export interface Project {
  id: string;
  user_id: string;
  title: string;
  description: string;
  difficulty: ProblemDifficulty;
  estimated_duration: string;
  required_skills: string[];
  features: string[];
  learning_outcomes: string[];
  completion_checklist: string[];
  status: ProjectStatus;
  started_at: string | null;
  completed_at: string | null;
}

export interface DashboardData {
  full_name: string | null;
  career_goal: string | null;
  overall_progress: number;
  total_topics: number;
  completed_topics: number;
  in_progress_topics: number;
  assessment_count: number;
  weakness_count: number;
  dsa_solved: number;
  dsa_attempted: number;
  contest_participations: number;
  projects_completed: number;
  projects_in_progress: number;
  study_streak: number;
  learning_hours: number;
  job_readiness: string;
  skill_profile: { skill: string; proficiency: number }[];
  current_weaknesses: { topic: string; priority: WeaknessPriority; score: number }[];
  upcoming_contest: Contest | null;
  recommended_project: Project | null;
  roadmap_exists: boolean;
}
