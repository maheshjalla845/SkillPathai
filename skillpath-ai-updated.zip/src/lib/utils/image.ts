export const MAX_IMAGE_DATA_URL_BYTES = 4 * 1024 * 1024; // ~4MB, safely under edge function / Groq limits

/**
 * Reads an image file, downsizes it if needed, and returns it as a
 * JPEG data URL small enough to send to the AI mentor edge function.
 * Throws a user-friendly error if the file isn't an image or can't be
 * compressed under the size limit.
 */
export async function fileToCompressedDataUrl(file: File): Promise<string> {
  if (!file.type.startsWith('image/')) {
    throw new Error('Please choose an image file (PNG, JPG, WEBP, etc.)');
  }

  const bitmap = await loadImage(file);

  let { width, height } = bitmap;
  const maxDimension = 1440;
  if (width > maxDimension || height > maxDimension) {
    const scale = maxDimension / Math.max(width, height);
    width = Math.round(width * scale);
    height = Math.round(height * scale);
  }

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Could not process image');
  ctx.drawImage(bitmap, 0, 0, width, height);

  let quality = 0.82;
  let dataUrl = canvas.toDataURL('image/jpeg', quality);

  while (dataUrl.length > MAX_IMAGE_DATA_URL_BYTES && quality > 0.4) {
    quality -= 0.12;
    dataUrl = canvas.toDataURL('image/jpeg', quality);
  }

  if (dataUrl.length > MAX_IMAGE_DATA_URL_BYTES) {
    throw new Error('That image is too large even after compression. Please try a smaller image.');
  }

  return dataUrl;
}

function loadImage(file: File): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      URL.revokeObjectURL(url);
      resolve(img);
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('Could not read that image file'));
    };
    img.src = url;
  });
}
