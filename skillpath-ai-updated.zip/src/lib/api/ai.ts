import { supabase } from '@/lib/supabase';

const EDGE_FUNCTION_BASE = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1`;

async function callEdgeFunction(name: string, body: Record<string, unknown>) {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) throw new Error('Not authenticated');

  const response = await fetch(`${EDGE_FUNCTION_BASE}/${name}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${session.access_token}`,
    },
    body: JSON.stringify(body),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({ error: 'Request failed' }));
    throw new Error(err.error || `Edge function ${name} failed`);
  }

  return response.json();
}

export interface AIQuestion {
  question_text: string;
  question_type: string;
  topic: string;
  subtopic: string;
  difficulty: string;
  options: string[] | null;
  correct_answer: string;
}

export async function generateAssessment(body: {
  assessment_type: 'diagnostic' | 'topic';
  career_goal: string;
  skills: { skill_name: string; level: string }[];
  topic_name?: string;
}): Promise<{ questions: AIQuestion[] }> {
  return callEdgeFunction('ai-assessment', {
    ...body,
    groq_api_key: import.meta.env.VITE_GROQ_API_KEY,
  });
}

export async function generateRoadmap(body: {
  career_goal: string;
  skills: { skill_name: string; level: string }[];
  diagnostic_results: { topic: string; subtopic: string; is_correct: boolean; difficulty: string }[];
  study_time_per_day: string;
  learning_preference: string;
}): Promise<{ roadmap: unknown }> {
  return callEdgeFunction('ai-roadmap', { ...body, groq_api_key: import.meta.env.VITE_GROQ_API_KEY });
}

export async function generateWeaknessAnalysis(body: {
  assessment_id: string;
  questions: { topic: string; subtopic: string; is_correct: boolean; difficulty: string; question_text: string; selected_answer: string; correct_answer: string }[];
}): Promise<{ weaknesses: unknown }> {
  return callEdgeFunction('ai-weakness', { ...body, groq_api_key: import.meta.env.VITE_GROQ_API_KEY });
}

export async function generateStudyPlan(body: {
  available_minutes: number;
  roadmap_topics: { topic_name: string; status: string; current_proficiency: number; target_proficiency: number }[];
  active_weaknesses: { topic: string; priority: string }[];
}): Promise<{ plan: unknown }> {
  return callEdgeFunction('ai-study-plan', { ...body, groq_api_key: import.meta.env.VITE_GROQ_API_KEY });
}

export async function askMentor(body: {
  question: string;
  context: { career_goal: string; completed_topics: string[]; active_weaknesses: string[]; current_topic: string | null };
  /** Optional base64 data URL (e.g. "data:image/jpeg;base64,...") of an image attached to the question. */
  image?: string;
}): Promise<{ answer: string }> {
  return callEdgeFunction('ai-mentor', { ...body, groq_api_key: import.meta.env.VITE_GROQ_API_KEY });
}

export async function generateProjects(body: {
  career_goal: string;
  completed_skills: string[];
  active_weaknesses: string[];
  existing_projects: string[];
}): Promise<{ projects: unknown }> {
  return callEdgeFunction('ai-projects', { ...body, groq_api_key: import.meta.env.VITE_GROQ_API_KEY });
}

export async function generateCareerAnalysis(body: {
  career_goal: string;
  skill_profile: { skill: string; proficiency: number }[];
  completed_topics: string[];
  total_topics: number;
}): Promise<{ analysis: unknown }> {
  return callEdgeFunction('ai-career', { ...body, groq_api_key: import.meta.env.VITE_GROQ_API_KEY });
}
