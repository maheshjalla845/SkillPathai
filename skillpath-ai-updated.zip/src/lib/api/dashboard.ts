import { supabase } from '@/lib/supabase';
import type { DashboardData } from '@/types';

export async function fetchDashboardData(userId: string): Promise<DashboardData> {
  const { data: profile } = await supabase
    .from('student_profiles')
    .select('*')
    .eq('user_id', userId)
    .maybeSingle();

  // Roadmap topics
  const { data: roadmap } = await supabase
    .from('roadmaps')
    .select('id')
    .eq('user_id', userId)
    .maybeSingle();

  let totalTopics = 0;
  let completedTopics = 0;
  let inProgressTopics = 0;
  let roadmapExists = false;

  if (roadmap) {
    roadmapExists = true;
    const { data: topics } = await supabase
      .from('roadmap_topics')
      .select('status')
      .eq('roadmap_id', roadmap.id);

    totalTopics = topics?.length ?? 0;
    completedTopics = topics?.filter((t) => t.status === 'COMPLETED').length ?? 0;
    inProgressTopics = topics?.filter((t) => t.status === 'IN_PROGRESS').length ?? 0;
  }

  const overallProgress = totalTopics > 0 ? Math.round((completedTopics / totalTopics) * 100) : 0;

  // Assessments
  const { count: assessmentCount } = await supabase
    .from('assessments')
    .select('*', { count: 'exact', head: true })
    .eq('user_id', userId);

  // Weaknesses (active only)
  const { count: weaknessCount } = await supabase
    .from('weaknesses')
    .select('*', { count: 'exact', head: true })
    .eq('user_id', userId)
    .in('status', ['active', 'recurring']);

  // DSA
  const { data: dsaData } = await supabase
    .from('dsa_problems')
    .select('solved')
    .eq('user_id', userId);

  const dsaSolved = dsaData?.filter((d) => d.solved).length ?? 0;
  const dsaAttempted = dsaData?.length ?? 0;

  // Contests
  const { count: contestParticipations } = await supabase
    .from('contest_participations')
    .select('*', { count: 'exact', head: true })
    .eq('user_id', userId);

  // Projects
  const { data: projectData } = await supabase
    .from('projects')
    .select('status')
    .eq('user_id', userId);

  const projectsCompleted = projectData?.filter((p) => p.status === 'COMPLETED').length ?? 0;
  const projectsInProgress = projectData?.filter((p) => p.status === 'IN_PROGRESS' || p.status === 'STARTED').length ?? 0;

  // Study sessions
  const { data: sessions } = await supabase
    .from('study_sessions')
    .select('duration_minutes, created_at')
    .eq('user_id', userId);

  const learningMinutes = sessions?.reduce((sum, s) => sum + s.duration_minutes, 0) ?? 0;
  const learningHours = Math.round((learningMinutes / 60) * 10) / 10;

  // Study streak — count distinct days with study sessions
  const studyDays = new Set<string>();
  sessions?.forEach((s) => {
    const day = new Date(s.created_at).toISOString().split('T')[0];
    studyDays.add(day);
  });

  // Calculate streak from study_days
  let studyStreak = 0;
  if (studyDays.size > 0) {
    const sortedDays = Array.from(studyDays).sort().reverse();
    const today = new Date().toISOString().split('T')[0];
    const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];

    if (sortedDays[0] === today || sortedDays[0] === yesterday) {
      studyStreak = 1;
      for (let i = 1; i < sortedDays.length; i++) {
        const prev = new Date(sortedDays[i - 1]);
        const curr = new Date(sortedDays[i]);
        const diff = (prev.getTime() - curr.getTime()) / 86400000;
        if (diff === 1) {
          studyStreak++;
        } else {
          break;
        }
      }
    }
  }

  // Skill profile
  const { data: skills } = await supabase
    .from('student_skills')
    .select('skill_name, verified_proficiency, level')
    .eq('user_id', userId);

  const skillProfile = (skills ?? []).map((s) => ({
    skill: s.skill_name,
    proficiency: s.verified_proficiency ?? 0,
  }));

  // Current weaknesses
  const { data: weaknesses } = await supabase
    .from('weaknesses')
    .select('topic, priority, score')
    .eq('user_id', userId)
    .in('status', ['active', 'recurring'])
    .order('detected_at', { ascending: false })
    .limit(5);

  // Recommended project
  const { data: recProject } = await supabase
    .from('projects')
    .select('*')
    .eq('user_id', userId)
    .in('status', ['RECOMMENDED'])
    .order('created_at', { ascending: false })
    .limit(1)
    .maybeSingle();

  // Job readiness
  let jobReadiness: string;
  if (totalTopics === 0 && (assessmentCount ?? 0) === 0) {
    jobReadiness = 'Not enough data yet';
  } else if (completedTopics < totalTopics * 0.3) {
    jobReadiness = 'Early stage — keep learning';
  } else if (completedTopics < totalTopics * 0.6) {
    jobReadiness = 'Building foundation';
  } else if (completedTopics < totalTopics * 0.85) {
    jobReadiness = 'Approaching readiness';
  } else {
    jobReadiness = 'Job ready';
  }

  return {
    full_name: profile?.full_name ?? null,
    career_goal: profile?.career_goal ?? profile?.custom_career_goal ?? null,
    overall_progress: overallProgress,
    total_topics: totalTopics,
    completed_topics: completedTopics,
    in_progress_topics: inProgressTopics,
    assessment_count: assessmentCount ?? 0,
    weakness_count: weaknessCount ?? 0,
    dsa_solved: dsaSolved,
    dsa_attempted: dsaAttempted,
    contest_participations: contestParticipations ?? 0,
    projects_completed: projectsCompleted,
    projects_in_progress: projectsInProgress,
    study_streak: studyStreak,
    learning_hours: learningHours,
    job_readiness: jobReadiness,
    skill_profile: skillProfile,
    current_weaknesses: (weaknesses ?? []).map((w) => ({
      topic: w.topic,
      priority: w.priority as 'HIGH' | 'MEDIUM' | 'LOW',
      score: w.score,
    })),
    upcoming_contest: null,
    recommended_project: (recProject as DashboardData['recommended_project']) ?? null,
    roadmap_exists: roadmapExists,
  };
}
