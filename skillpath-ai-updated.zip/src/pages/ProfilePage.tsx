import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { Card, EmptyState, Skeleton, ProgressBar } from '@/components/ui';
import type { StudentProfile, StudentSkill } from '@/types';
import {
  User as UserIcon,
  Mail,
  GraduationCap,
  Target,
  Code2,
  Clock,
  Palette,
  BookOpen,
  Award,
  Calendar,
} from 'lucide-react';

export default function ProfilePage() {
  const { user } = useAuth();
  const [profile, setProfile] = useState<StudentProfile | null>(null);
  const [skills, setSkills] = useState<StudentSkill[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    loadData(user.id);
  }, [user]);

  const loadData = async (userId: string) => {
    const { data: prof } = await supabase
      .from('student_profiles')
      .select('*')
      .eq('user_id', userId)
      .maybeSingle();
    setProfile(prof as StudentProfile | null);

    const { data: sk } = await supabase
      .from('student_skills')
      .select('*')
      .eq('user_id', userId);
    setSkills((sk ?? []) as StudentSkill[]);
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="mx-auto max-w-4xl space-y-6">
        <Skeleton className="h-16 w-full" />
        <Skeleton className="h-48 w-full" />
        <Skeleton className="h-48 w-full" />
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="mx-auto max-w-4xl">
        <h1 className="mb-6 text-2xl font-bold text-gray-900 dark:text-gray-50">Profile</h1>
        <Card className="p-8">
          <EmptyState
            icon={UserIcon}
            title="No profile found"
            description="Complete onboarding to set up your profile."
          />
        </Card>
      </div>
    );
  }

  const careerGoal = profile.custom_career_goal || profile.career_goal;

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-50">Profile</h1>

      {/* Profile header */}
      <Card className="p-6">
        <div className="flex items-center gap-4">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-primary-600 to-secondary-600">
            <UserIcon size={28} className="text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">
              {profile.full_name || user?.email || 'Student'}
            </h2>
            {user?.email && (
              <p className="flex items-center gap-1 text-sm text-gray-500 dark:text-gray-400">
                <Mail size={14} /> {user.email}
              </p>
            )}
            {careerGoal && (
              <p className="mt-1 flex items-center gap-1 text-sm font-medium text-primary-600 dark:text-primary-400">
                <Target size={14} /> {careerGoal}
              </p>
            )}
          </div>
        </div>
      </Card>

      {/* Student Info */}
      <Card className="p-6">
        <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold text-gray-900 dark:text-gray-100">
          <GraduationCap size={20} className="text-primary-600 dark:text-primary-400" /> Education
        </h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <InfoItem label="Education Level" value={profile.education} />
          <InfoItem label="College / Institution" value={profile.college} />
          <InfoItem label="Year of Study" value={profile.year} />
          <InfoItem label="Programming Experience" value={profile.experience} />
        </div>
        {profile.academic_background && (
          <div className="mt-4">
            <InfoItem label="Academic Background" value={profile.academic_background} />
          </div>
        )}
      </Card>

      {/* Study Preferences */}
      <Card className="p-6">
        <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold text-gray-900 dark:text-gray-100">
          <Clock size={20} className="text-primary-600 dark:text-primary-400" /> Study Preferences
        </h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <InfoItem label="Study Time" value={profile.study_time_per_day} icon={<Clock size={14} />} />
          <InfoItem label="Learning Preference" value={profile.learning_preference} icon={<Palette size={14} />} />
        </div>
      </Card>

      {/* Skills */}
      <Card className="p-6">
        <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold text-gray-900 dark:text-gray-100">
          <Code2 size={20} className="text-primary-600 dark:text-primary-400" /> Skills
        </h2>
        {skills.length === 0 ? (
          <p className="text-sm text-gray-400 dark:text-gray-500">No skills added yet.</p>
        ) : (
          <div className="space-y-3">
            {skills.map((skill) => (
              <div key={skill.id} className="flex items-center justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-gray-900 dark:text-gray-100">{skill.skill_name}</span>
                    <span className="text-xs text-gray-400 dark:text-gray-500">
                      {skill.level} · Verified: {skill.verified_proficiency ?? 'N/A'}%
                    </span>
                  </div>
                  <ProgressBar
                    value={skill.verified_proficiency ?? 0}
                    className="mt-1.5 h-1.5"
                  />
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* Progress flags */}
      <Card className="p-6">
        <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold text-gray-900 dark:text-gray-100">
          <Award size={20} className="text-primary-600 dark:text-primary-400" /> Progress
        </h2>
        <div className="space-y-3">
          <ProgressFlag label="Onboarding Completed" done={profile.onboarding_completed} />
          <ProgressFlag label="Diagnostic Assessment" done={profile.diagnostic_completed} />
          <ProgressFlag label="Roadmap Generated" done={profile.roadmap_generated} />
        </div>
        <p className="mt-4 flex items-center gap-1 text-xs text-gray-400 dark:text-gray-500">
          <Calendar size={12} /> Joined {new Date(profile.created_at).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
        </p>
      </Card>
    </div>
  );
}

function InfoItem({ label, value, icon }: { label: string; value: string | null; icon?: React.ReactNode }) {
  return (
    <div>
      <p className="text-xs font-medium text-gray-500 dark:text-gray-400">{label}</p>
      <p className="mt-1 flex items-center gap-1.5 text-sm font-medium text-gray-900 dark:text-gray-100">
        {icon}
        {value || 'Not set'}
      </p>
    </div>
  );
}

function ProgressFlag({ label, done }: { label: string; done: boolean }) {
  return (
    <div className="flex items-center gap-2 text-sm">
      <div className={`flex h-5 w-5 items-center justify-center rounded-full ${done ? 'bg-success-500' : 'bg-gray-200 dark:bg-gray-700'}`}>
        {done && <svg className="h-3 w-3 text-white" viewBox="0 0 12 12" fill="none"><path d="M2 6l3 3 5-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>}
      </div>
      <span className={done ? 'text-gray-900 dark:text-gray-100' : 'text-gray-400 dark:text-gray-500'}>{label}</span>
    </div>
  );
}
