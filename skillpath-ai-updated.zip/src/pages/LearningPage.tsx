import { useEffect, useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { Card, EmptyState, ProgressBar, Spinner, ErrorBanner, Skeleton } from '@/components/ui';
import { generateAssessment, type AIQuestion } from '@/lib/api/ai';
import type { RoadmapTopic } from '@/types';
import {
  BookOpen,
  ArrowLeft,
  Clock,
  Target,
  Lightbulb,
  Code2,
  Check,
  Play,
  RefreshCw,
  ClipboardCheck,
  ChevronRight,
  AlertCircle,
  Circle,
} from 'lucide-react';

type View = 'select' | 'detail' | 'assessment' | 'assessment-result';

export default function LearningPage() {
  const { user } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const [view, setView] = useState<View>('select');
  const [topics, setTopics] = useState<RoadmapTopic[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTopic, setSelectedTopic] = useState<RoadmapTopic | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Assessment state
  const [questions, setQuestions] = useState<AIQuestion[]>([]);
  const [currentQ, setCurrentQ] = useState(0);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [assessmentLoading, setAssessmentLoading] = useState(false);
  const [assessmentResult, setAssessmentResult] = useState<{ score: number; correct: number; total: number; assessmentId: string } | null>(null);

  useEffect(() => {
    if (!user) return;
    loadTopics(user.id);
  }, [user]);

  const loadTopics = async (userId: string) => {
    const { data: roadmap } = await supabase
      .from('roadmaps')
      .select('id')
      .eq('user_id', userId)
      .maybeSingle();

    if (!roadmap) {
      setLoading(false);
      return;
    }

    const { data: topicData } = await supabase
      .from('roadmap_topics')
      .select('*')
      .eq('roadmap_id', roadmap.id)
      .order('order_index', { ascending: true });

    setTopics((topicData ?? []) as RoadmapTopic[]);
    setLoading(false);

    // If topic param exists, auto-select it
    const topicParam = searchParams.get('topic');
    if (topicParam) {
      const found = (topicData ?? []).find((t) => t.topic_name === topicParam);
      if (found) {
        setSelectedTopic(found as RoadmapTopic);
        setView('detail');
      }
    }
  };

  const selectTopic = (topic: RoadmapTopic) => {
    setSelectedTopic(topic);
    setView('detail');
    setSearchParams({ topic: topic.topic_name });
  };

  const startAssessment = async (topic: RoadmapTopic) => {
    if (!user) return;
    setAssessmentLoading(true);
    setError(null);

    try {
      const { data: profile } = await supabase
        .from('student_profiles')
        .select('career_goal, custom_career_goal')
        .eq('user_id', user.id)
        .maybeSingle();

      const { data: skills } = await supabase
        .from('student_skills')
        .select('skill_name, level')
        .eq('user_id', user.id);

      const result = await generateAssessment({
        assessment_type: 'topic',
        career_goal: profile?.custom_career_goal || profile?.career_goal || 'Software Engineer',
        skills: (skills ?? []).map((s) => ({ skill_name: s.skill_name, level: s.level })),
        topic_name: topic.topic_name,
      });

      setQuestions(result.questions);
      setCurrentQ(0);
      setAnswers({});
      setView('assessment');
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to generate assessment';
      setError(msg);
    } finally {
      setAssessmentLoading(false);
    }
  };

  const submitAssessment = async () => {
    if (!user || !selectedTopic) return;
    let correct = 0;
    const records = questions.map((q, i) => {
      const selected = answers[i] || null;
      const isCorrect = selected === q.correct_answer;
      if (isCorrect) correct++;
      return {
        question_text: q.question_text,
        question_type: q.question_type,
        topic: q.topic,
        subtopic: q.subtopic,
        difficulty: q.difficulty,
        options: q.options,
        correct_answer: q.correct_answer,
        selected_answer: selected,
        is_correct: isCorrect,
        time_taken_seconds: null,
      };
    });

    const total = questions.length;
    const score = Math.round((correct / total) * 100);

    const { data: assessment, error: insertError } = await supabase
      .from('assessments')
      .insert({
        user_id: user.id,
        type: 'topic',
        topic_name: selectedTopic.topic_name,
        total_questions: total,
        score,
      })
      .select()
      .single();

    if (insertError) {
      setError('Failed to save assessment.');
      return;
    }

    await supabase.from('assessment_questions').insert(
      records.map((r) => ({ ...r, assessment_id: assessment.id }))
    );

    // Update topic proficiency
    const newProficiency = Math.round((selectedTopic.current_proficiency + score) / 2);
    const newStatus = score >= 70 ? 'COMPLETED' : score >= 40 ? 'NEEDS_REVISION' : selectedTopic.status;

    await supabase
      .from('roadmap_topics')
      .update({
        current_proficiency: newProficiency,
        status: newStatus,
        completed_at: newStatus === 'COMPLETED' ? new Date().toISOString() : null,
      })
      .eq('id', selectedTopic.id);

    setAssessmentResult({ score, correct, total, assessmentId: assessment.id });
    setView('assessment-result');
  };

  if (loading) {
    return (
      <div className="mx-auto max-w-5xl space-y-6">
        <Skeleton className="h-16 w-full" />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[...Array(6)].map((_, i) => <Skeleton key={i} className="h-32 w-full" />)}
        </div>
      </div>
    );
  }

  if (topics.length === 0 && view === 'select') {
    return (
      <div className="mx-auto max-w-7xl">
        <h1 className="mb-6 text-2xl font-bold text-gray-900 dark:text-gray-50">Learning</h1>
        <Card className="p-8">
          <EmptyState
            icon={BookOpen}
            title="No topics available"
            description="Complete your diagnostic assessment and generate your roadmap to start learning."
            action={<button onClick={() => navigate('/roadmap')} className="btn-primary btn-sm">Go to Roadmap</button>}
          />
        </Card>
      </div>
    );
  }

  // --- ASSESSMENT VIEW ---
  if (view === 'assessment' && questions.length > 0) {
    const q = questions[currentQ];
    const progress = ((currentQ + 1) / questions.length) * 100;

    return (
      <div className="mx-auto max-w-3xl space-y-6">
        <div className="flex items-center justify-between">
          <button onClick={() => setView('detail')} className="btn-ghost btn-sm">
            <ArrowLeft size={16} /> Exit Assessment
          </button>
          <span className="text-sm text-gray-500 dark:text-gray-400">
            Question {currentQ + 1} of {questions.length}
          </span>
        </div>
        <ProgressBar value={progress} />

        {error && <ErrorBanner message={error} />}

        <Card className="p-8">
          <div className="mb-4 flex flex-wrap items-center gap-2">
            <span className="badge-primary">{q.topic}</span>
            {q.subtopic && <span className="badge-neutral">{q.subtopic}</span>}
            <span className={q.difficulty === 'easy' ? 'badge-success' : q.difficulty === 'medium' ? 'badge-warning' : 'badge-error'}>
              {q.difficulty}
            </span>
          </div>

          <h2 className="mb-6 text-lg font-semibold text-gray-900 dark:text-gray-50">{q.question_text}</h2>

          {q.options ? (
            <div className="space-y-3">
              {q.options.map((opt, i) => (
                <button
                  key={i}
                  onClick={() => setAnswers({ ...answers, [currentQ]: opt })}
                  className={`flex w-full items-center gap-3 rounded-lg border px-4 py-3 text-left text-sm font-medium transition-all ${
                    answers[currentQ] === opt
                      ? 'border-primary-500 bg-primary-50 text-primary-700 dark:border-primary-500 dark:bg-primary-950/40 dark:text-primary-300'
                      : 'border-gray-200 text-gray-700 hover:border-gray-300 dark:border-gray-700 dark:text-gray-300 dark:hover:border-gray-600'
                  }`}
                >
                  <div className={`flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full border-2 ${
                    answers[currentQ] === opt ? 'border-primary-600 bg-primary-600' : 'border-gray-300 dark:border-gray-600'
                  }`}>
                    {answers[currentQ] === opt && <Check size={14} className="text-white" />}
                  </div>
                  <span className="font-mono text-xs text-gray-400">{String.fromCharCode(65 + i)}</span>
                  <span className="flex-1">{opt}</span>
                </button>
              ))}
            </div>
          ) : (
            <textarea
              value={answers[currentQ] ?? ''}
              onChange={(e) => setAnswers({ ...answers, [currentQ]: e.target.value })}
              className="input min-h-[150px] resize-y font-mono text-sm"
              placeholder="Type your answer..."
            />
          )}

          <div className="mt-8 flex items-center justify-between">
            <button onClick={() => setCurrentQ(Math.max(0, currentQ - 1))} className="btn-secondary" disabled={currentQ === 0}>
              Previous
            </button>
            {currentQ < questions.length - 1 ? (
              <button onClick={() => setCurrentQ(currentQ + 1)} className="btn-primary" disabled={!answers[currentQ]}>
                Next <ChevronRight size={18} />
              </button>
            ) : (
              <button onClick={submitAssessment} className="btn-primary" disabled={!answers[currentQ]}>
                Submit <Check size={18} />
              </button>
            )}
          </div>
        </Card>
      </div>
    );
  }

  // --- ASSESSMENT RESULT VIEW ---
  if (view === 'assessment-result' && assessmentResult) {
    const passed = assessmentResult.score >= 70;
    return (
      <div className="mx-auto max-w-2xl py-8">
        <Card className="p-8 text-center">
          <div className={`mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-full ${
            passed ? 'bg-success-100 dark:bg-success-900/30' : 'bg-warning-100 dark:bg-warning-900/30'
          }`}>
            <ClipboardCheck size={40} className={passed ? 'text-success-600 dark:text-success-400' : 'text-warning-600 dark:text-warning-400'} />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-50">Assessment Complete</h2>
          <p className="mt-2 text-gray-500 dark:text-gray-400">
            You scored {assessmentResult.correct}/{assessmentResult.total} on {selectedTopic?.topic_name}
          </p>
          <div className="my-6 text-5xl font-bold text-primary-600 dark:text-primary-400">{assessmentResult.score}%</div>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            {passed
              ? 'You passed! This topic has been marked as completed.'
              : 'You need more practice. This topic has been marked for revision.'}
          </p>
          <div className="mt-8 flex justify-center gap-3">
            <button onClick={() => { setView('select'); setSearchParams({}); }} className="btn-secondary">
              Back to Topics
            </button>
            <button onClick={() => navigate('/weaknesses')} className="btn-primary">
              View Weaknesses <ChevronRight size={16} />
            </button>
          </div>
        </Card>
      </div>
    );
  }

  // --- DETAIL VIEW ---
  if (view === 'detail' && selectedTopic) {
    return (
      <div className="mx-auto max-w-4xl space-y-6">
        <button onClick={() => { setView('select'); setSelectedTopic(null); setSearchParams({}); }} className="btn-ghost btn-sm">
          <ArrowLeft size={16} /> Back to Topics
        </button>

        <Card className="p-6">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-50">{selectedTopic.topic_name}</h1>
              {selectedTopic.description && <p className="mt-2 text-gray-600 dark:text-gray-400">{selectedTopic.description}</p>}
            </div>
            <span className={
              selectedTopic.status === 'COMPLETED' ? 'badge-success' :
              selectedTopic.status === 'IN_PROGRESS' ? 'badge-primary' :
              selectedTopic.status === 'NEEDS_REVISION' ? 'badge-warning' : 'badge-neutral'
            }>{selectedTopic.status.replace(/_/g, ' ')}</span>
          </div>

          <div className="mt-4 grid grid-cols-3 gap-4">
            <div className="rounded-lg border border-gray-200 p-3 dark:border-gray-800">
              <p className="flex items-center gap-1 text-xs text-gray-500 dark:text-gray-400"><Clock size={12} /> Estimated</p>
              <p className="mt-1 font-semibold text-gray-900 dark:text-gray-100">{selectedTopic.estimated_hours}h</p>
            </div>
            <div className="rounded-lg border border-gray-200 p-3 dark:border-gray-800">
              <p className="flex items-center gap-1 text-xs text-gray-500 dark:text-gray-400"><Target size={12} /> Proficiency</p>
              <p className="mt-1 font-semibold text-gray-900 dark:text-gray-100">{selectedTopic.current_proficiency}/{selectedTopic.target_proficiency}%</p>
            </div>
            <div className="rounded-lg border border-gray-200 p-3 dark:border-gray-800">
              <p className="flex items-center gap-1 text-xs text-gray-500 dark:text-gray-400"><AlertCircle size={12} /> Priority</p>
              <p className="mt-1 font-semibold capitalize text-gray-900 dark:text-gray-100">{selectedTopic.priority}</p>
            </div>
          </div>

          <ProgressBar value={selectedTopic.current_proficiency} max={selectedTopic.target_proficiency} className="mt-4" />
        </Card>

        {selectedTopic.subtopics.length > 0 && (
          <Card className="p-6">
            <h2 className="mb-3 flex items-center gap-2 text-lg font-semibold text-gray-900 dark:text-gray-100">
              <BookOpen size={20} /> Subtopics
            </h2>
            <div className="flex flex-wrap gap-2">
              {selectedTopic.subtopics.map((s, i) => (
                <span key={i} className="rounded-lg bg-gray-100 px-3 py-1.5 text-sm text-gray-700 dark:bg-gray-800 dark:text-gray-300">{s}</span>
              ))}
            </div>
          </Card>
        )}

        {selectedTopic.resources.length > 0 && (
          <Card className="p-6">
            <h2 className="mb-3 flex items-center gap-2 text-lg font-semibold text-gray-900 dark:text-gray-100">
              <Lightbulb size={20} /> Learning Resources
            </h2>
            <ul className="space-y-2">
              {selectedTopic.resources.map((r, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-gray-700 dark:text-gray-300">
                  <ChevronRight size={16} className="mt-0.5 flex-shrink-0 text-primary-600" /> {r}
                </li>
              ))}
            </ul>
          </Card>
        )}

        {selectedTopic.practice.length > 0 && (
          <Card className="p-6">
            <h2 className="mb-3 flex items-center gap-2 text-lg font-semibold text-gray-900 dark:text-gray-100">
              <Code2 size={20} /> Practice Problems
            </h2>
            <ul className="space-y-2">
              {selectedTopic.practice.map((p, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-gray-700 dark:text-gray-300">
                  <Code2 size={16} className="mt-0.5 flex-shrink-0 text-primary-600" /> {p}
                </li>
              ))}
            </ul>
          </Card>
        )}

        <Card className="p-6">
          <h2 className="mb-3 flex items-center gap-2 text-lg font-semibold text-gray-900 dark:text-gray-100">
            <ClipboardCheck size={20} /> Test Your Knowledge
          </h2>
          <p className="mb-4 text-sm text-gray-600 dark:text-gray-400">
            Take an AI-generated assessment to verify your understanding of {selectedTopic.topic_name}.
          </p>
          <button onClick={() => startAssessment(selectedTopic)} className="btn-primary" disabled={assessmentLoading}>
            {assessmentLoading ? <Spinner size={18} /> : <Play size={18} />} Start Topic Assessment
          </button>
          {error && <div className="mt-4"><ErrorBanner message={error} /></div>}
        </Card>
      </div>
    );
  }

  // --- SELECT VIEW (topic list) ---
  const inProgress = topics.filter((t) => t.status === 'IN_PROGRESS' || t.status === 'NEEDS_REVISION');
  const notStarted = topics.filter((t) => t.status === 'NOT_STARTED');
  const completed = topics.filter((t) => t.status === 'COMPLETED');

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-50">Learning</h1>

      {inProgress.length > 0 && (
        <div>
          <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">Continue Learning</h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {inProgress.map((topic) => <TopicCard key={topic.id} topic={topic} onClick={() => selectTopic(topic)} />)}
          </div>
        </div>
      )}

      {notStarted.length > 0 && (
        <div>
          <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">Up Next</h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {notStarted.map((topic) => <TopicCard key={topic.id} topic={topic} onClick={() => selectTopic(topic)} />)}
          </div>
        </div>
      )}

      {completed.length > 0 && (
        <div>
          <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">Completed</h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {completed.map((topic) => <TopicCard key={topic.id} topic={topic} onClick={() => selectTopic(topic)} />)}
          </div>
        </div>
      )}
    </div>
  );
}

function TopicCard({ topic, onClick }: { topic: RoadmapTopic; onClick: () => void }) {
  const statusIcon = {
    NOT_STARTED: Circle,
    IN_PROGRESS: Play,
    COMPLETED: Check,
    NEEDS_REVISION: RefreshCw,
  };
  const StatusIcon = statusIcon[topic.status];
  const statusColor = {
    NOT_STARTED: 'text-gray-400',
    IN_PROGRESS: 'text-primary-600',
    COMPLETED: 'text-success-600',
    NEEDS_REVISION: 'text-warning-600',
  };

  return (
    <button onClick={onClick} className="card-hover p-5 text-left">
      <div className="flex items-start justify-between">
        <StatusIcon size={20} className={statusColor[topic.status]} />
        <span className="text-xs text-gray-400 dark:text-gray-500">{topic.estimated_hours}h</span>
      </div>
      <h3 className="mt-3 font-semibold text-gray-900 dark:text-gray-100">{topic.topic_name}</h3>
      {topic.description && <p className="mt-1 text-sm text-gray-500 dark:text-gray-400 line-clamp-2">{topic.description}</p>}
      <div className="mt-3">
        <ProgressBar value={topic.current_proficiency} max={topic.target_proficiency} className="h-1.5" />
        <p className="mt-1 text-xs text-gray-400 dark:text-gray-500">{topic.current_proficiency}/{topic.target_proficiency}% proficiency</p>
      </div>
    </button>
  );
}


