import { Card, EmptyState } from '@/components/ui';
import { Construction, type LucideIcon } from 'lucide-react';

export function ComingSoon({ title, description }: { title: string; description: string }) {
  return (
    <div className="mx-auto max-w-7xl">
      <h1 className="mb-6 text-2xl font-bold text-gray-900 dark:text-gray-50">{title}</h1>
      <Card className="p-6">
        <EmptyState
          icon={Construction as LucideIcon}
          title="Coming soon"
          description={description}
        />
      </Card>
    </div>
  );
}
