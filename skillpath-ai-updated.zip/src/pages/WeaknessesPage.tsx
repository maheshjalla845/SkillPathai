import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { Card, EmptyState, Skeleton } from '@/components/ui';
import type { Weakness, WeaknessHistory } from '@/types';
import {
  TrendingDown,
  AlertTriangle,
  Check,
  RefreshCw,
  Target,
  ArrowRight,
  BookOpen,
} from 'lucide-react';

export default function WeaknessesPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [weaknesses, setWeaknesses] = useState<Weakness[]>([]);
  const [history, setHistory] = useState<WeaknessHistory[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'active' | 'improving' | 'resolved' | 'all'>('active');

  useEffect(() => {
    if (!user) return;
    loadWeaknesses(user.id);
  }, [user]);

  const loadWeaknesses = async (userId: string) => {
    const { data: w } = await supabase
      .from('weaknesses')
      .select('*')
      .eq('user_id', userId)
      .order('detected_at', { ascending: false });

    setWeaknesses((w ?? []) as Weakness[]);

    const { data: h } = await supabase
      .from('weakness_history')
      .select('*')
      .eq('user_id', userId)
      .order('assessed_at', { ascending: true });

    setHistory((h ?? []) as WeaknessHistory[]);
    setLoading(false);
  };

  const markResolved = async (id: string) => {
    await supabase
      .from('weaknesses')
      .update({ status: 'resolved', resolved_at: new Date().toISOString() })
      .eq('id', id);
    setWeaknesses((prev) => prev.map((w) => w.id === id ? { ...w, status: 'resolved', resolved_at: new Date().toISOString() } : w));
  };

  const markImproving = async (id: string) => {
    await supabase
      .from('weaknesses')
      .update({ status: 'improving' })
      .eq('id', id);
    setWeaknesses((prev) => prev.map((w) => w.id === id ? { ...w, status: 'improving' } : w));
  };

  if (loading) {
    return (
      <div className="mx-auto max-w-5xl space-y-6">
        <Skeleton className="h-16 w-full" />
        <Skeleton className="h-48 w-full" />
        <Skeleton className="h-48 w-full" />
      </div>
    );
  }

  const filtered = filter === 'all' ? weaknesses : weaknesses.filter((w) => w.status === filter);
  const activeCount = weaknesses.filter((w) => w.status === 'active').length;
  const improvingCount = weaknesses.filter((w) => w.status === 'improving').length;
  const resolvedCount = weaknesses.filter((w) => w.status === 'resolved').length;

  const filters = [
    { key: 'active' as const, label: 'Active', count: activeCount },
    { key: 'improving' as const, label: 'Improving', count: improvingCount },
    { key: 'resolved' as const, label: 'Resolved', count: resolvedCount },
    { key: 'all' as const, label: 'All', count: weaknesses.length },
  ];

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-50">Weaknesses</h1>
        <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
          Areas identified from your assessments that need improvement.
        </p>
      </div>

      {/* Filter tabs */}
      <div className="flex gap-2">
        {filters.map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={`rounded-lg px-4 py-2 text-sm font-medium transition-colors ${
              filter === f.key
                ? 'bg-primary-600 text-white'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-gray-700'
            }`}
          >
            {f.label} ({f.count})
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <Card className="p-8">
          <EmptyState
            icon={filter === 'resolved' ? Check : TrendingDown}
            title={filter === 'resolved' ? 'No resolved weaknesses yet' : 'No weaknesses detected'}
            description={filter === 'active'
              ? 'Take assessments to discover areas that need improvement.'
              : filter === 'resolved'
              ? 'Weaknesses you resolve will appear here.'
              : 'Take assessments to discover areas that need improvement.'}
            action={filter === 'active' ? (
              <button onClick={() => navigate('/assessments')} className="btn-primary btn-sm">
                Take Assessment <ArrowRight size={16} />
              </button>
            ) : undefined}
          />
        </Card>
      ) : (
        <div className="space-y-4">
          {filtered.map((w) => (
            <WeaknessCard
              key={w.id}
              weakness={w}
              onResolve={() => markResolved(w.id)}
              onImprove={() => markImproving(w.id)}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function WeaknessCard({
  weakness,
  onResolve,
  onImprove,
}: {
  weakness: Weakness;
  onResolve: () => void;
  onImprove: () => void;
}) {
  const priorityConfig = {
    HIGH: { label: 'High Priority', class: 'badge-error', icon: AlertTriangle },
    MEDIUM: { label: 'Medium Priority', class: 'badge-warning', icon: Target },
    LOW: { label: 'Low Priority', class: 'badge-neutral', icon: Target },
  };

  const statusConfig = {
    active: { label: 'Active', class: 'badge-error' },
    improving: { label: 'Improving', class: 'badge-warning' },
    resolved: { label: 'Resolved', class: 'badge-success' },
    recurring: { label: 'Recurring', class: 'badge-error' },
  };

  const pConfig = priorityConfig[weakness.priority];
  const PriorityIcon = pConfig.icon;
  const sConfig = statusConfig[weakness.status];

  return (
    <Card className="p-6">
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">{weakness.topic}</h3>
            {weakness.subtopic && <span className="badge-neutral">{weakness.subtopic}</span>}
          </div>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <span className={`flex items-center gap-1 ${pConfig.class}`}>
              <PriorityIcon size={12} /> {pConfig.label}
            </span>
            <span className={sConfig.class}>{sConfig.label}</span>
            <span className="text-xs text-gray-400 dark:text-gray-500">Score: {weakness.score}%</span>
          </div>
        </div>
      </div>

      <p className="mt-4 text-sm text-gray-600 dark:text-gray-400">{weakness.explanation}</p>

      {weakness.recommended_actions.length > 0 && (
        <div className="mt-4">
          <p className="mb-2 flex items-center gap-1 text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
            <BookOpen size={12} /> Recommended Actions
          </p>
          <ul className="space-y-1.5">
            {weakness.recommended_actions.map((action, i) => (
              <li key={i} className="flex items-start gap-2 text-sm text-gray-700 dark:text-gray-300">
                <ArrowRight size={14} className="mt-0.5 flex-shrink-0 text-primary-600" /> {action}
              </li>
            ))}
          </ul>
        </div>
      )}

      {weakness.status === 'active' && (
        <div className="mt-4 flex gap-2">
          <button onClick={onImprove} className="btn-secondary btn-sm">
            <RefreshCw size={14} /> Mark Improving
          </button>
          <button onClick={onResolve} className="btn-primary btn-sm">
            <Check size={14} /> Mark Resolved
          </button>
        </div>
      )}
      {weakness.status === 'improving' && (
        <div className="mt-4">
          <button onClick={onResolve} className="btn-primary btn-sm">
            <Check size={14} /> Mark Resolved
          </button>
        </div>
      )}
    </Card>
  );
}
