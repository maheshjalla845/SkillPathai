import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { Card, EmptyState, Skeleton, Spinner, ErrorBanner, ProgressBar } from '@/components/ui';
import { generateCareerAnalysis } from '@/lib/api/ai';
import {
  Briefcase,
  Sparkles,
  Target,
  TrendingUp,
  Check,
  AlertCircle,
  Lightbulb,
  Clock,
} from 'lucide-react';

interface CareerAnalysis {
  job_readiness_score: number;
  readiness_level: string;
  strengths: string[];
  gaps: string[];
  recommended_focus: string[];
  job_titles: string[];
  estimated_weeks_to_ready: number;
  advice: string;
}

export default function CareerPage() {
  const { user } = useAuth();
  const [analysis, setAnalysis] = useState<CareerAnalysis | null>(null);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [careerGoal, setCareerGoal] = useState<string | null>(null);
  const [skillProfile, setSkillProfile] = useState<{ skill: string; proficiency: number }[]>([]);

  useEffect(() => {
    if (!user) return;
    loadInitialData(user.id);
  }, [user]);

  const loadInitialData = async (userId: string) => {
    const { data: profile } = await supabase
      .from('student_profiles')
      .select('career_goal, custom_career_goal')
      .eq('user_id', userId)
      .maybeSingle();

    setCareerGoal(profile?.custom_career_goal || profile?.career_goal || null);

    const { data: skills } = await supabase
      .from('student_skills')
      .select('skill_name, verified_proficiency')
      .eq('user_id', userId);

    setSkillProfile((skills ?? []).map((s) => ({ skill: s.skill_name, proficiency: s.verified_proficiency ?? 0 })));
    setLoading(false);
  };

  const handleAnalyze = async () => {
    if (!user) return;
    setGenerating(true);
    setError(null);

    try {
      const { data: roadmap } = await supabase
        .from('roadmaps')
        .select('id')
        .eq('user_id', user.id)
        .maybeSingle();

      let completedTopics: string[] = [];
      let totalTopics = 0;

      if (roadmap) {
        const { data: topics } = await supabase
          .from('roadmap_topics')
          .select('topic_name, status')
          .eq('roadmap_id', roadmap.id);
        totalTopics = topics?.length ?? 0;
        completedTopics = (topics ?? []).filter((t) => t.status === 'COMPLETED').map((t) => t.topic_name);
      }

      const result = await generateCareerAnalysis({
        career_goal: careerGoal || 'Software Engineer',
        skill_profile: skillProfile,
        completed_topics: completedTopics,
        total_topics: totalTopics,
      });

      setAnalysis(result.analysis as CareerAnalysis);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to generate career analysis';
      setError(msg);
    } finally {
      setGenerating(false);
    }
  };

  if (loading) {
    return (
      <div className="mx-auto max-w-5xl space-y-6">
        <Skeleton className="h-16 w-full" />
        <Skeleton className="h-48 w-full" />
        <Skeleton className="h-48 w-full" />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-50">Career Intelligence</h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            {careerGoal ? `Target: ${careerGoal}` : 'Set your career goal in onboarding to get analysis'}
          </p>
        </div>
        <button onClick={handleAnalyze} className="btn-primary btn-sm" disabled={generating}>
          {generating ? <Spinner size={16} /> : <Sparkles size={16} />} Analyze My Readiness
        </button>
      </div>

      {error && <ErrorBanner message={error} />}

      {!analysis && !generating ? (
        <Card className="p-8">
          <EmptyState
            icon={Briefcase}
            title="No career analysis yet"
            description="Get an AI-powered analysis of your job readiness, skill gaps, and recommended focus areas."
            action={<button onClick={handleAnalyze} className="btn-primary btn-sm"><Sparkles size={16} /> Analyze My Readiness</button>}
          />
        </Card>
      ) : generating ? (
        <Card className="p-8">
          <div className="flex flex-col items-center gap-4">
            <Spinner size={32} className="text-primary-600" />
            <p className="text-sm text-gray-500 dark:text-gray-400">Analyzing your profile...</p>
          </div>
        </Card>
      ) : analysis ? (
        <>
          {/* Job Readiness Score */}
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">Job Readiness Score</h2>
                <p className="text-sm text-gray-500 dark:text-gray-400">{analysis.readiness_level}</p>
              </div>
              <div className="text-right">
                <span className="text-4xl font-bold text-primary-600 dark:text-primary-400">{analysis.job_readiness_score}</span>
                <span className="text-lg text-gray-400">/100</span>
              </div>
            </div>
            <ProgressBar value={analysis.job_readiness_score} className="mt-4 h-3" />
            {analysis.estimated_weeks_to_ready && (
              <p className="mt-3 flex items-center gap-1.5 text-sm text-gray-500 dark:text-gray-400">
                <Clock size={14} /> Estimated {analysis.estimated_weeks_to_ready} weeks to job-ready
              </p>
            )}
          </Card>

          {/* Strengths and Gaps */}
          <div className="grid gap-4 sm:grid-cols-2">
            <Card className="p-6">
              <h2 className="mb-3 flex items-center gap-2 text-lg font-semibold text-gray-900 dark:text-gray-100">
                <TrendingUp size={20} className="text-success-600" /> Strengths
              </h2>
              {analysis.strengths.length > 0 ? (
                <ul className="space-y-2">
                  {analysis.strengths.map((s, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-gray-700 dark:text-gray-300">
                      <Check size={16} className="mt-0.5 flex-shrink-0 text-success-600" /> {s}
                    </li>
                  ))}
                </ul>
              ) : <p className="text-sm text-gray-400">No strengths identified yet.</p>}
            </Card>
            <Card className="p-6">
              <h2 className="mb-3 flex items-center gap-2 text-lg font-semibold text-gray-900 dark:text-gray-100">
                <AlertCircle size={20} className="text-warning-600" /> Skill Gaps
              </h2>
              {analysis.gaps.length > 0 ? (
                <ul className="space-y-2">
                  {analysis.gaps.map((g, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-gray-700 dark:text-gray-300">
                      <AlertCircle size={16} className="mt-0.5 flex-shrink-0 text-warning-600" /> {g}
                    </li>
                  ))}
                </ul>
              ) : <p className="text-sm text-gray-400">No gaps identified.</p>}
            </Card>
          </div>

          {/* Recommended Focus */}
          {analysis.recommended_focus.length > 0 && (
            <Card className="p-6">
              <h2 className="mb-3 flex items-center gap-2 text-lg font-semibold text-gray-900 dark:text-gray-100">
                <Target size={20} className="text-primary-600" /> Recommended Focus Areas
              </h2>
              <ul className="space-y-2">
                {analysis.recommended_focus.map((f, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-gray-700 dark:text-gray-300">
                    <Target size={16} className="mt-0.5 flex-shrink-0 text-primary-600" /> {f}
                  </li>
                ))}
              </ul>
            </Card>
          )}

          {/* Job Titles */}
          {analysis.job_titles.length > 0 && (
            <Card className="p-6">
              <h2 className="mb-3 flex items-center gap-2 text-lg font-semibold text-gray-900 dark:text-gray-100">
                <Briefcase size={20} className="text-primary-600" /> Roles You Can Target
              </h2>
              <div className="flex flex-wrap gap-2">
                {analysis.job_titles.map((j, i) => (
                  <span key={i} className="rounded-lg border border-gray-200 bg-gray-50 px-3 py-1.5 text-sm font-medium text-gray-700 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300">{j}</span>
                ))}
              </div>
            </Card>
          )}

          {/* Advice */}
          {analysis.advice && (
            <Card className="border-primary-200 bg-primary-50/50 p-6 dark:border-primary-800 dark:bg-primary-950/20">
              <h2 className="mb-2 flex items-center gap-2 text-lg font-semibold text-gray-900 dark:text-gray-100">
                <Lightbulb size={20} className="text-primary-600" /> Personalized Advice
              </h2>
              <p className="text-sm leading-relaxed text-gray-700 dark:text-gray-300">{analysis.advice}</p>
            </Card>
          )}
        </>
      ) : null}
    </div>
  );
}
