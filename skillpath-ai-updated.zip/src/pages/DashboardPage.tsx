import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { fetchDashboardData } from '@/lib/api/dashboard';
import { Card, StatCard, EmptyState, ProgressBar, Skeleton, Spinner } from '@/components/ui';
import {
  TrendingUp,
  BookCheck,
  ClipboardCheck,
  TrendingDown,
  Code2,
  FolderKanban,
  Flame,
  Clock,
  Target,
  Route as RouteIcon,
  AlertCircle,
  ArrowRight,
  Lightbulb,
  Briefcase,
} from 'lucide-react';
import type { DashboardData } from '@/types';

export default function DashboardPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [nextAction, setNextAction] = useState<string | null>(null);
  const [nextActionLoading, setNextActionLoading] = useState(false);

  useEffect(() => {
    if (!user) return;
    fetchDashboardData(user.id).then((d) => {
      setData(d);
      setLoading(false);
    });
  }, [user]);

  const handleWhatShouldIStudy = () => {
    setNextActionLoading(true);
    if (!data?.roadmap_exists) {
      setNextAction('Complete your diagnostic assessment first. We need to understand your current skill level before deciding your learning priorities.');
      setNextActionLoading(false);
    } else if (data.completed_topics === 0) {
      setNextAction('Start with your first roadmap topic. Head to My Roadmap and begin with the first unlocked topic.');
      setNextActionLoading(false);
    } else if (data.current_weaknesses.length > 0) {
      const w = data.current_weaknesses[0];
      setNextAction(`Revise ${w.topic}. Your latest assessment identified this as a ${w.priority.toLowerCase()} priority weakness (score: ${w.score}%).`);
      setNextActionLoading(false);
    } else {
      setNextAction('Continue to the next topic in your roadmap. You have no active weaknesses — great progress!');
      setNextActionLoading(false);
    }
  };

  if (loading || !data) {
    return (
      <div className="mx-auto max-w-7xl space-y-6">
        <Skeleton className="h-24 w-full" />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[...Array(8)].map((_, i) => <Skeleton key={i} className="h-28 w-full" />)}
        </div>
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      {/* Welcome header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-50">
            Welcome, {data.full_name ?? 'Student'}
          </h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            {data.career_goal ? `Target career: ${data.career_goal}` : 'Complete onboarding to set your career goal'}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 rounded-lg border border-gray-200 bg-white px-4 py-2 dark:border-gray-800 dark:bg-gray-900">
            <Target size={18} className="text-primary-600" />
            <div>
              <p className="text-xs text-gray-500 dark:text-gray-400">Job Readiness</p>
              <p className="text-sm font-semibold text-gray-900 dark:text-gray-100">{data.job_readiness}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Overall progress */}
      <Card className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">Overall Progress</h2>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              {data.completed_topics} of {data.total_topics} topics completed
            </p>
          </div>
          <span className="text-3xl font-bold text-primary-600 dark:text-primary-400">{data.overall_progress}%</span>
        </div>
        <ProgressBar value={data.overall_progress} className="mt-4 h-3" />
      </Card>

      {/* What Should I Study Now */}
      <Card className="border-primary-200 bg-primary-50/50 p-6 dark:border-primary-800 dark:bg-primary-950/20">
        <div className="flex items-start gap-4">
          <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-xl bg-primary-100 dark:bg-primary-900/40">
            <Lightbulb size={24} className="text-primary-600 dark:text-primary-400" />
          </div>
          <div className="flex-1">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">What Should I Study Now?</h2>
            {nextAction ? (
              <p className="mt-2 text-sm leading-relaxed text-gray-700 dark:text-gray-300">{nextAction}</p>
            ) : (
              <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
                Get a personalized recommendation based on your real progress and weaknesses.
              </p>
            )}
            <button onClick={handleWhatShouldIStudy} className="btn-primary btn-sm mt-3" disabled={nextActionLoading}>
              {nextActionLoading ? <Spinner size={16} /> : 'Get Recommendation'}
            </button>
          </div>
        </div>
      </Card>

      {/* Stats grid */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Topics Completed" value={data.completed_topics} icon={BookCheck} sublabel={`${data.in_progress_topics} in progress`} />
        <StatCard label="Assessments" value={data.assessment_count} icon={ClipboardCheck} />
        <StatCard label="Weaknesses" value={data.weakness_count} icon={TrendingDown} />
        <StatCard label="DSA Solved" value={data.dsa_solved} icon={Code2} sublabel={`${data.dsa_attempted} attempted`} />
        <StatCard label="Contests" value={data.contest_participations} icon={Target} />
        <StatCard label="Projects Done" value={data.projects_completed} icon={FolderKanban} sublabel={`${data.projects_in_progress} in progress`} />
        <StatCard label="Study Streak" value={`${data.study_streak} days`} icon={Flame} />
        <StatCard label="Learning Hours" value={data.learning_hours} icon={Clock} />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Current weaknesses */}
        <Card className="p-6">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">Current Weaknesses</h2>
            <Link to="/weaknesses" className="text-sm text-primary-600 hover:text-primary-700 dark:text-primary-400">View all</Link>
          </div>
          {data.current_weaknesses.length === 0 ? (
            <EmptyState
              icon={TrendingDown}
              title="No weaknesses detected yet"
              description="Complete an assessment to discover areas that need improvement."
            />
          ) : (
            <div className="space-y-3">
              {data.current_weaknesses.map((w, i) => (
                <div key={i} className="flex items-center justify-between rounded-lg border border-gray-200 px-4 py-3 dark:border-gray-800">
                  <div>
                    <p className="font-medium text-gray-900 dark:text-gray-100">{w.topic}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">Score: {w.score}%</p>
                  </div>
                  <span className={
                    w.priority === 'HIGH' ? 'badge-error' :
                    w.priority === 'MEDIUM' ? 'badge-warning' : 'badge-neutral'
                  }>{w.priority}</span>
                </div>
              ))}
            </div>
          )}
        </Card>

        {/* Roadmap progress / next steps */}
        <Card className="p-6">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">Roadmap Progress</h2>
            <Link to="/roadmap" className="text-sm text-primary-600 hover:text-primary-700 dark:text-primary-400">View roadmap</Link>
          </div>
          {!data.roadmap_exists ? (
            <EmptyState
              icon={RouteIcon}
              title="No roadmap yet"
              description="Complete onboarding and your diagnostic assessment to generate your personalized roadmap."
              action={
                <button onClick={() => navigate('/onboarding')} className="btn-primary btn-sm">
                  Start Onboarding <ArrowRight size={16} />
                </button>
              }
            />
          ) : (
            <div className="space-y-4">
              <div>
                <div className="mb-2 flex justify-between text-sm">
                  <span className="text-gray-600 dark:text-gray-400">{data.completed_topics}/{data.total_topics} topics</span>
                  <span className="font-medium text-gray-900 dark:text-gray-100">{data.overall_progress}%</span>
                </div>
                <ProgressBar value={data.overall_progress} />
              </div>
              <Link to="/roadmap" className="btn-secondary w-full">
                Continue Learning <ArrowRight size={16} />
              </Link>
            </div>
          )}
        </Card>
      </div>

      {/* Recommended project */}
      {data.recommended_project && (
        <Card className="p-6">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">Recommended Project</h2>
            <Link to="/projects" className="text-sm text-primary-600 hover:text-primary-700 dark:text-primary-400">View all</Link>
          </div>
          <div className="flex items-start justify-between gap-4">
            <div>
              <h3 className="font-semibold text-gray-900 dark:text-gray-100">{data.recommended_project.title}</h3>
              <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">{data.recommended_project.description}</p>
              <div className="mt-2 flex gap-2">
                <span className="badge-primary">{data.recommended_project.difficulty}</span>
                <span className="badge-neutral">{data.recommended_project.estimated_duration}</span>
              </div>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}
