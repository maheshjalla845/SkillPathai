import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { Card, EmptyState, Skeleton, ProgressBar } from '@/components/ui';
import type { Assessment } from '@/types';
import {
  ClipboardCheck,
  ArrowRight,
  Play,
  Trophy,
  TrendingUp,
  Calendar,
} from 'lucide-react';

export default function AssessmentsPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [assessments, setAssessments] = useState<Assessment[]>([]);
  const [loading, setLoading] = useState(true);
  const [avgScore, setAvgScore] = useState(0);

  useEffect(() => {
    if (!user) return;
    loadAssessments(user.id);
  }, [user]);

  const loadAssessments = async (userId: string) => {
    const { data } = await supabase
      .from('assessments')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    setAssessments((data ?? []) as Assessment[]);
    if (data && data.length > 0) {
      const avg = Math.round(data.reduce((sum, a) => sum + a.score, 0) / data.length);
      setAvgScore(avg);
    }
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="mx-auto max-w-5xl space-y-6">
        <Skeleton className="h-16 w-full" />
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  const diagnosticAssessments = assessments.filter((a) => a.type === 'diagnostic');
  const topicAssessments = assessments.filter((a) => a.type === 'topic');

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-50">Assessments</h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">Track your assessment history and progress.</p>
        </div>
        <button onClick={() => navigate('/learning')} className="btn-primary btn-sm">
          <Play size={16} /> Take New Assessment
        </button>
      </div>

      {/* Stats */}
      {assessments.length > 0 && (
        <div className="grid gap-4 sm:grid-cols-3">
          <Card className="p-5">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary-50 dark:bg-primary-950/40">
                <ClipboardCheck size={20} className="text-primary-600 dark:text-primary-400" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">{assessments.length}</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">Total Assessments</p>
              </div>
            </div>
          </Card>
          <Card className="p-5">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-success-50 dark:bg-success-950/40">
                <TrendingUp size={20} className="text-success-600 dark:text-success-400" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">{avgScore}%</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">Average Score</p>
              </div>
            </div>
          </Card>
          <Card className="p-5">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-warning-50 dark:bg-warning-950/40">
                <Trophy size={20} className="text-warning-600 dark:text-warning-400" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">
                  {assessments.filter((a) => a.score >= 70).length}
                </p>
                <p className="text-sm text-gray-500 dark:text-gray-400">Passed (70%+)</p>
              </div>
            </div>
          </Card>
        </div>
      )}

      {assessments.length === 0 ? (
        <Card className="p-8">
          <EmptyState
            icon={ClipboardCheck}
            title="No assessments yet"
            description="Take your first assessment from any topic in the Learning section."
            action={<button onClick={() => navigate('/learning')} className="btn-primary btn-sm">Browse Topics <ArrowRight size={16} /></button>}
          />
        </Card>
      ) : (
        <>
          {/* Diagnostic assessments */}
          {diagnosticAssessments.length > 0 && (
            <div>
              <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">Diagnostic</h2>
              <div className="space-y-3">
                {diagnosticAssessments.map((a) => <AssessmentRow key={a.id} assessment={a} />)}
              </div>
            </div>
          )}

          {/* Topic assessments */}
          {topicAssessments.length > 0 && (
            <div>
              <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">Topic Assessments</h2>
              <div className="space-y-3">
                {topicAssessments.map((a) => <AssessmentRow key={a.id} assessment={a} />)}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

function AssessmentRow({ assessment }: { assessment: Assessment }) {
  const date = new Date(assessment.created_at).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });

  const scoreColor = assessment.score >= 70 ? 'success' : assessment.score >= 40 ? 'warning' : 'error';

  return (
    <Card className="p-4">
      <div className="flex items-center justify-between gap-4">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="font-medium text-gray-900 dark:text-gray-100">
              {assessment.topic_name || 'Diagnostic Assessment'}
            </h3>
            <span className="badge-neutral capitalize">{assessment.type}</span>
          </div>
          <p className="mt-1 flex items-center gap-1 text-xs text-gray-400 dark:text-gray-500">
            <Calendar size={12} /> {date} · {assessment.total_questions} questions
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="w-24">
            <ProgressBar value={assessment.score} color={scoreColor} className="h-2" />
          </div>
          <span className={`text-lg font-bold ${
            scoreColor === 'success' ? 'text-success-600 dark:text-success-400' :
            scoreColor === 'warning' ? 'text-warning-600 dark:text-warning-400' :
            'text-error-600 dark:text-error-400'
          }`}>{assessment.score}%</span>
        </div>
      </div>
    </Card>
  );
}
