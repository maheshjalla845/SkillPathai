import { useEffect, useState, useRef, type FormEvent, type ChangeEvent } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { Card, EmptyState, Spinner, ErrorBanner } from '@/components/ui';
import { askMentor } from '@/lib/api/ai';
import { fileToCompressedDataUrl } from '@/lib/utils/image';
import {
  MessageSquare,
  Send,
  Sparkles,
  User,
  Bot,
  Lightbulb,
  ImagePlus,
  X,
} from 'lucide-react';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  image?: string;
}

export default function AIMentorPage() {
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pendingImage, setPendingImage] = useState<string | null>(null);
  const [imageProcessing, setImageProcessing] = useState(false);
  const [context, setContext] = useState<{
    career_goal: string;
    completed_topics: string[];
    active_weaknesses: string[];
    current_topic: string | null;
  } | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!user) return;
    loadContext(user.id);
  }, [user]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const loadContext = async (userId: string) => {
    const { data: profile } = await supabase
      .from('student_profiles')
      .select('career_goal, custom_career_goal')
      .eq('user_id', userId)
      .maybeSingle();

    const { data: roadmap } = await supabase
      .from('roadmaps')
      .select('id')
      .eq('user_id', userId)
      .maybeSingle();

    let completedTopics: string[] = [];
    let currentTopic: string | null = null;

    if (roadmap) {
      const { data: topics } = await supabase
        .from('roadmap_topics')
        .select('topic_name, status')
        .eq('roadmap_id', roadmap.id);
      completedTopics = (topics ?? []).filter((t) => t.status === 'COMPLETED').map((t) => t.topic_name);
      const inProgress = (topics ?? []).find((t) => t.status === 'IN_PROGRESS');
      if (inProgress) currentTopic = inProgress.topic_name;
    }

    const { data: weaknesses } = await supabase
      .from('weaknesses')
      .select('topic')
      .eq('user_id', userId)
      .in('status', ['active', 'recurring']);

    setContext({
      career_goal: profile?.custom_career_goal || profile?.career_goal || 'Software Engineer',
      completed_topics: completedTopics,
      active_weaknesses: (weaknesses ?? []).map((w) => w.topic),
      current_topic: currentTopic,
    });
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if ((!input.trim() && !pendingImage) || loading || !context) return;

    const userMsg = input.trim();
    const userImage = pendingImage ?? undefined;
    setMessages((prev) => [...prev, { role: 'user', content: userMsg, image: userImage }]);
    setInput('');
    setPendingImage(null);
    setLoading(true);
    setError(null);

    try {
      const result = await askMentor({ question: userMsg, context, image: userImage });
      setMessages((prev) => [...prev, { role: 'assistant', content: result.answer }]);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to get response';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  const handleImageSelect = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    setError(null);
    setImageProcessing(true);
    try {
      const dataUrl = await fileToCompressedDataUrl(file);
      setPendingImage(dataUrl);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Could not process that image';
      setError(msg);
    } finally {
      setImageProcessing(false);
    }
  };

  const suggestedQuestions = [
    'What should I study next?',
    'How do I improve my weak areas?',
    'Am I ready for job interviews?',
    'Explain dynamic programming simply',
  ];

  return (
    <div className="mx-auto flex max-w-4xl flex-col space-y-4" style={{ minHeight: 'calc(100vh - 8rem)' }}>
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-50">AI Mentor</h1>
        <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
          Ask anything about your learning journey, career, or technical concepts.
        </p>
      </div>

      {error && <ErrorBanner message={error} />}

      {/* Chat area */}
      <Card className="flex flex-1 flex-col overflow-hidden">
        <div ref={scrollRef} className="flex-1 space-y-4 overflow-y-auto p-6" style={{ minHeight: '300px' }}>
          {messages.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center py-12">
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-primary-600 to-secondary-600">
                <Sparkles size={32} className="text-white" />
              </div>
              <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">Ask me anything</h2>
              <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">I know your progress, weaknesses, and career goals.</p>
              <div className="mt-6 grid w-full max-w-md gap-2">
                {suggestedQuestions.map((q) => (
                  <button
                    key={q}
                    onClick={() => setInput(q)}
                    className="flex items-center gap-2 rounded-lg border border-gray-200 px-4 py-2.5 text-left text-sm text-gray-700 transition-colors hover:border-primary-300 hover:bg-primary-50 dark:border-gray-700 dark:text-gray-300 dark:hover:border-primary-700 dark:hover:bg-primary-950/30"
                  >
                    <Lightbulb size={14} className="text-primary-600" /> {q}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            messages.map((msg, i) => (
              <div key={i} className={`flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                <div className={`flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-lg ${
                  msg.role === 'user' ? 'bg-gray-200 dark:bg-gray-700' : 'bg-gradient-to-br from-primary-600 to-secondary-600'
                }`}>
                  {msg.role === 'user' ? <User size={16} className="text-gray-600 dark:text-gray-300" /> : <Bot size={16} className="text-white" />}
                </div>
                <div className={`max-w-[80%] rounded-lg px-4 py-3 text-sm ${
                  msg.role === 'user'
                    ? 'bg-primary-600 text-white'
                    : 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200'
                }`}>
                  {msg.image && (
                    <img
                      src={msg.image}
                      alt="Attached"
                      className="mb-2 max-h-56 w-auto rounded-md border border-white/20 object-contain"
                    />
                  )}
                  {msg.content && <p className="whitespace-pre-wrap leading-relaxed">{msg.content}</p>}
                </div>
              </div>
            ))
          )}
          {loading && (
            <div className="flex gap-3">
              <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-primary-600 to-secondary-600">
                <Bot size={16} className="text-white" />
              </div>
              <div className="rounded-lg bg-gray-100 px-4 py-3 dark:bg-gray-800">
                <Spinner size={16} />
              </div>
            </div>
          )}
        </div>

        {/* Input */}
        <div className="border-t border-gray-200 dark:border-gray-800">
          {pendingImage && (
            <div className="flex items-center gap-2 border-b border-gray-200 px-4 pt-3 dark:border-gray-800">
              <div className="relative">
                <img src={pendingImage} alt="Attached preview" className="h-16 w-16 rounded-md border border-gray-200 object-cover dark:border-gray-700" />
                <button
                  type="button"
                  onClick={() => setPendingImage(null)}
                  className="absolute -right-1.5 -top-1.5 flex h-5 w-5 items-center justify-center rounded-full bg-gray-900 text-white shadow-sm hover:bg-gray-700"
                  aria-label="Remove attached image"
                >
                  <X size={12} />
                </button>
              </div>
              <span className="text-xs text-gray-500 dark:text-gray-400">Image attached</span>
            </div>
          )}
          <form onSubmit={handleSubmit} className="flex items-center gap-2 p-4">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageSelect}
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="btn-secondary !px-3"
              disabled={loading || imageProcessing}
              aria-label="Attach an image"
              title="Attach an image"
            >
              {imageProcessing ? <Spinner size={18} /> : <ImagePlus size={18} />}
            </button>
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              className="input flex-1"
              placeholder="Ask a question, or attach an image..."
              disabled={loading}
            />
            <button type="submit" className="btn-primary" disabled={loading || (!input.trim() && !pendingImage)}>
              {loading ? <Spinner size={18} /> : <Send size={18} />}
            </button>
          </form>
        </div>
      </Card>
    </div>
  );
}
