import { Link } from 'react-router-dom';
import {
  Brain,
  Route,
  Target,
  TrendingDown,
  RefreshCw,
  Code2,
  CalendarDays,
  FolderKanban,
  Briefcase,
  MessageSquare,
  ArrowRight,
  Sparkles,
  CheckCircle2,
  Moon,
  Sun,
} from 'lucide-react';
import { useTheme } from '@/context/ThemeContext';

const features = [
  {
    icon: Route,
    title: 'Personalized Roadmaps',
    desc: 'One adaptive roadmap built from your actual knowledge, career goal, and study time — not a generic template.',
  },
  {
    icon: Brain,
    title: 'AI Assessments',
    desc: 'Test what you actually know with AI-generated questions across MCQ, debugging, scenario-based, and practical formats.',
  },
  {
    icon: TrendingDown,
    title: 'Weakness Detection',
    desc: 'AI analyzes your mistakes and pinpoints exactly where you struggle, with targeted revision recommendations.',
  },
  {
    icon: RefreshCw,
    title: 'Adaptive Learning',
    desc: 'Your roadmap continuously adapts as you learn, complete topics, and improve on weak areas.',
  },
  {
    icon: Code2,
    title: 'DSA Tracking',
    desc: 'Track real problem-solving across arrays, trees, graphs, DP, and more. Zero inflated stats — only real activity.',
  },
  {
    icon: CalendarDays,
    title: 'Contest Calendar',
    desc: 'A unified calendar pulling upcoming contests from Codeforces, LeetCode, AtCoder, and more.',
  },
  {
    icon: FolderKanban,
    title: 'Project Recommendations',
    desc: 'Get project suggestions matched to your completed skills, weaknesses, and career trajectory.',
  },
  {
    icon: Briefcase,
    title: 'Career Intelligence',
    desc: 'See the real skill gap between where you are and where your target role demands you to be.',
  },
  {
    icon: MessageSquare,
    title: 'AI Mentor',
    desc: 'Ask questions and get personalized guidance based on your real progress, weaknesses, and goals.',
  },
];

export default function LandingPage() {
  const { theme, toggleTheme } = useTheme();

  return (
    <div className="min-h-screen bg-white dark:bg-gray-950">
      {/* Nav */}
      <nav className="sticky top-0 z-50 border-b border-gray-100 bg-white/80 backdrop-blur-md dark:border-gray-900 dark:bg-gray-950/80">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3.5 sm:px-6 lg:px-8">
          <Link to="/" className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-primary-600 to-secondary-600">
              <Sparkles size={20} className="text-white" />
            </div>
            <span className="text-lg font-bold tracking-tight">SkillPath AI</span>
          </Link>
          <div className="flex items-center gap-2 sm:gap-4">
            <button
              onClick={toggleTheme}
              className="btn-ghost btn-sm"
              aria-label="Toggle theme"
            >
              {theme === 'light' ? <Moon size={18} /> : <Sun size={18} />}
            </button>
            <Link to="/login" className="btn-ghost btn-sm hidden sm:inline-flex">
              Login
            </Link>
            <Link to="/signup" className="btn-primary btn-sm">
              Get Started
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-primary-50/50 to-transparent dark:from-primary-950/20" />
        <div className="relative mx-auto max-w-4xl px-4 py-20 text-center sm:px-6 sm:py-28 lg:py-36">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-primary-200 bg-primary-50 px-4 py-1.5 text-sm font-medium text-primary-700 dark:border-primary-800 dark:bg-primary-950/40 dark:text-primary-300">
            <Sparkles size={14} />
            AI-Powered Personalized Career Learning
          </div>
          <h1 className="text-4xl font-bold tracking-tight text-gray-900 dark:text-gray-50 sm:text-5xl lg:text-6xl">
            Stop Searching for Roadmaps.
            <br />
            <span className="bg-gradient-to-r from-primary-600 to-secondary-600 bg-clip-text text-transparent">
              Start Following Yours.
            </span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-gray-600 dark:text-gray-400">
            AI-powered personalized career roadmaps that adapt to your skills, assessments,
            weaknesses, and goals.
          </p>
          <div className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Link to="/signup" className="btn-primary btn-lg w-full sm:w-auto">
              Get Started
              <ArrowRight size={18} />
            </Link>
            <Link to="/login" className="btn-secondary btn-lg w-full sm:w-auto">
              Login
            </Link>
          </div>

          <div className="mt-12 flex flex-wrap items-center justify-center gap-x-8 gap-y-3 text-sm text-gray-500 dark:text-gray-400">
            <span className="flex items-center gap-1.5">
              <CheckCircle2 size={16} className="text-success-500" />
              No fake progress
            </span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 size={16} className="text-success-500" />
              Adaptive roadmaps
            </span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 size={16} className="text-success-500" />
              Real weakness tracking
            </span>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight text-gray-900 dark:text-gray-50 sm:text-4xl">
            Your Personal Learning OS
          </h2>
          <p className="mt-4 text-lg text-gray-600 dark:text-gray-400">
            Every feature works together in a continuous feedback loop — learn, assess, detect
            weaknesses, revise, and adapt.
          </p>
        </div>

        <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((f) => (
            <div
              key={f.title}
              className="card-hover group p-6 transition-transform hover:-translate-y-1"
            >
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-primary-50 transition-colors group-hover:bg-primary-100 dark:bg-primary-950/40 dark:group-hover:bg-primary-900/40">
                <f.icon size={24} className="text-primary-600 dark:text-primary-400" />
              </div>
              <h3 className="mb-2 text-lg font-semibold text-gray-900 dark:text-gray-100">
                {f.title}
              </h3>
              <p className="text-sm leading-relaxed text-gray-600 dark:text-gray-400">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section className="border-t border-gray-100 bg-gray-50/50 py-16 dark:border-gray-900 dark:bg-gray-900/30 lg:py-24">
        <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-center text-3xl font-bold tracking-tight text-gray-900 dark:text-gray-50 sm:text-4xl">
            How It Works
          </h2>
          <div className="mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { step: '01', title: 'Sign Up & Onboard', desc: 'Tell us your career goal, current skills, and study time.' },
              { step: '02', title: 'Diagnostic Assessment', desc: 'AI tests your actual knowledge to build a real skill profile.' },
              { step: '03', title: 'Personalized Roadmap', desc: 'Get one adaptive roadmap tailored to your level and goal.' },
              { step: '04', title: 'Learn & Adapt', desc: 'Learn, take assessments, fix weaknesses, and watch your roadmap adapt.' },
            ].map((s) => (
              <div key={s.step} className="text-center">
                <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-primary-600 to-secondary-600 text-sm font-bold text-white">
                  {s.step}
                </div>
                <h3 className="mb-2 font-semibold text-gray-900 dark:text-gray-100">{s.title}</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-4xl px-4 py-16 text-center sm:px-6 lg:py-24">
        <h2 className="text-3xl font-bold tracking-tight text-gray-900 dark:text-gray-50 sm:text-4xl">
          Ready to find your path?
        </h2>
        <p className="mt-4 text-lg text-gray-600 dark:text-gray-400">
          Join SkillPath AI and stop guessing what to learn next.
        </p>
        <Link to="/signup" className="btn-primary btn-lg mt-8 inline-flex">
          Get Started
          <ArrowRight size={18} />
        </Link>
      </section>

      {/* Footer */}
      <footer className="border-t border-gray-100 py-8 dark:border-gray-900">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-md bg-gradient-to-br from-primary-600 to-secondary-600">
              <Sparkles size={16} className="text-white" />
            </div>
            <span className="font-semibold">SkillPath AI</span>
          </div>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Your AI Career Navigator
          </p>
        </div>
      </footer>
    </div>
  );
}
