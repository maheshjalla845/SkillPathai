import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { Card, EmptyState, Skeleton, StatCard } from '@/components/ui';
import type { Contest, ContestParticipation } from '@/types';
import {
  CalendarDays,
  ExternalLink,
  Clock,
  Trophy,
  Target,
  Plus,
  Check,
  TrendingUp,
} from 'lucide-react';

const platformColors: Record<string, string> = {
  Codeforces: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400',
  LeetCode: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400',
  AtCoder: 'bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-300',
  CodeChef: 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400',
  GeeksforGeeks: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400',
};

export default function ContestsPage() {
  const { user } = useAuth();
  const [contests, setContests] = useState<Contest[]>([]);
  const [participations, setParticipations] = useState<ContestParticipation[]>([]);
  const [loading, setLoading] = useState(true);
  const [showLogForm, setShowLogForm] = useState(false);

  useEffect(() => {
    if (!user) return;
    loadData(user.id);
  }, [user]);

  const loadData = async (userId: string) => {
    const { data: c } = await supabase
      .from('contests')
      .select('*')
      .gte('start_time', new Date().toISOString())
      .order('start_time', { ascending: true })
      .limit(20);

    setContests((c ?? []) as Contest[]);

    const { data: p } = await supabase
      .from('contest_participations')
      .select('*')
      .eq('user_id', userId)
      .order('participated_at', { ascending: false });

    setParticipations((p ?? []) as ContestParticipation[]);
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="mx-auto max-w-5xl space-y-6">
        <Skeleton className="h-16 w-full" />
        <Skeleton className="h-48 w-full" />
      </div>
    );
  }

  const totalSolved = participations.reduce((sum, p) => sum + p.problems_solved, 0);
  const totalAttempted = participations.reduce((sum, p) => sum + p.problems_attempted, 0);
  const avgRating = participations.length > 0 && participations.some((p) => p.rating)
    ? Math.round(participations.filter((p) => p.rating).reduce((sum, p) => sum + (p.rating ?? 0), 0) / participations.filter((p) => p.rating).length)
    : null;

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-50">Contests</h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">Upcoming contests and your participation history.</p>
        </div>
        <button onClick={() => setShowLogForm(!showLogForm)} className="btn-primary btn-sm">
          <Plus size={16} /> Log Participation
        </button>
      </div>

      {/* Stats */}
      {participations.length > 0 && (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Contests" value={participations.length} icon={Trophy} />
          <StatCard label="Problems Solved" value={totalSolved} icon={Check} sublabel={`of ${totalAttempted} attempted`} />
          <StatCard label="Success Rate" value={totalAttempted > 0 ? `${Math.round((totalSolved / totalAttempted) * 100)}%` : '0%'} icon={Target} />
          <StatCard label="Avg Rating" value={avgRating ?? 'N/A'} icon={TrendingUp} />
        </div>
      )}

      {/* Log participation form */}
      {showLogForm && <LogParticipationForm userId={user?.id ?? ''} onDone={() => { setShowLogForm(false); if (user) loadData(user.id); }} />}

      {/* Upcoming contests */}
      <div>
        <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">Upcoming Contests</h2>
        {contests.length === 0 ? (
          <Card className="p-8">
            <EmptyState
              icon={CalendarDays}
              title="No upcoming contests"
              description="Contest data from Codeforces, LeetCode, and other platforms will appear here."
            />
          </Card>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2">
            {contests.map((c) => {
              const startTime = new Date(c.start_time);
              const durationHours = Math.floor(c.duration_seconds / 3600);
              const platformClass = platformColors[c.platform] || 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300';
              return (
                <Card key={c.id} className="p-5">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-gray-900 dark:text-gray-100">{c.name}</h3>
                      <div className="mt-2 flex flex-wrap items-center gap-2 text-xs">
                        <span className={`rounded-md px-2 py-0.5 font-medium ${platformClass}`}>{c.platform}</span>
                        {c.difficulty && <span className="badge-neutral">{c.difficulty}</span>}
                      </div>
                      <div className="mt-3 space-y-1 text-sm text-gray-500 dark:text-gray-400">
                        <p className="flex items-center gap-1.5">
                          <Clock size={14} /> {startTime.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} at {startTime.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
                        </p>
                        <p className="flex items-center gap-1.5">
                          <CalendarDays size={14} /> {durationHours}h duration
                        </p>
                      </div>
                    </div>
                    {c.url && (
                      <a href={c.url} target="_blank" rel="noopener noreferrer" className="btn-secondary btn-sm flex-shrink-0">
                        <ExternalLink size={14} /> Visit
                      </a>
                    )}
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      {/* Participation history */}
      {participations.length > 0 && (
        <div>
          <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">Your History</h2>
          <div className="space-y-2">
            {participations.map((p) => (
              <Card key={p.id} className="p-4">
                <div className="flex items-center justify-between gap-4">
                  <div>
                    <h3 className="font-medium text-gray-900 dark:text-gray-100">
                      {p.contest_name || 'Contest'}
                    </h3>
                    <p className="mt-0.5 text-xs text-gray-400 dark:text-gray-500">
                      {p.platform} · {new Date(p.participated_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                    </p>
                  </div>
                  <div className="flex items-center gap-4 text-sm">
                    <div className="text-center">
                      <p className="font-bold text-gray-900 dark:text-gray-100">{p.problems_solved}</p>
                      <p className="text-xs text-gray-400">solved</p>
                    </div>
                    <div className="text-center">
                      <p className="font-bold text-gray-900 dark:text-gray-100">{p.problems_attempted}</p>
                      <p className="text-xs text-gray-400">attempted</p>
                    </div>
                    {p.rating && (
                      <div className="text-center">
                        <p className="font-bold text-primary-600 dark:text-primary-400">{p.rating}</p>
                        <p className="text-xs text-gray-400">rating</p>
                      </div>
                    )}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function LogParticipationForm({ userId, onDone }: { userId: string; onDone: () => void }) {
  const [contestName, setContestName] = useState('');
  const [platform, setPlatform] = useState('Codeforces');
  const [solved, setSolved] = useState('0');
  const [attempted, setAttempted] = useState('0');
  const [timeTaken, setTimeTaken] = useState('');
  const [wrongSubs, setWrongSubs] = useState('0');
  const [rating, setRating] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!contestName.trim()) return;

    const { error: insertError } = await supabase.from('contest_participations').insert({
      user_id: userId,
      contest_name: contestName.trim(),
      platform,
      problems_solved: parseInt(solved) || 0,
      problems_attempted: parseInt(attempted) || 0,
      time_taken_minutes: parseInt(timeTaken) || 0,
      wrong_submissions: parseInt(wrongSubs) || 0,
      rating: rating ? parseInt(rating) : null,
    });

    if (insertError) {
      setError('Failed to log participation.');
      return;
    }
    onDone();
  };

  return (
    <Card className="p-6">
      <h2 className="mb-4 text-lg font-semibold text-gray-900 dark:text-gray-100">Log Contest Participation</h2>
      {error && <p className="mb-4 text-sm text-error-600 dark:text-error-400">{error}</p>}
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="label">Contest Name</label>
            <input value={contestName} onChange={(e) => setContestName(e.target.value)} className="input" placeholder="e.g., Codeforces Round 900" required />
          </div>
          <div>
            <label className="label">Platform</label>
            <select value={platform} onChange={(e) => setPlatform(e.target.value)} className="input">
              {['Codeforces', 'LeetCode', 'AtCoder', 'CodeChef', 'GeeksforGeeks', 'Other'].map((p) => <option key={p} value={p}>{p}</option>)}
            </select>
          </div>
          <div>
            <label className="label">Problems Solved</label>
            <input type="number" value={solved} onChange={(e) => setSolved(e.target.value)} className="input" placeholder="0" />
          </div>
          <div>
            <label className="label">Problems Attempted</label>
            <input type="number" value={attempted} onChange={(e) => setAttempted(e.target.value)} className="input" placeholder="0" />
          </div>
          <div>
            <label className="label">Time Taken (minutes)</label>
            <input type="number" value={timeTaken} onChange={(e) => setTimeTaken(e.target.value)} className="input" placeholder="0" />
          </div>
          <div>
            <label className="label">Wrong Submissions</label>
            <input type="number" value={wrongSubs} onChange={(e) => setWrongSubs(e.target.value)} className="input" placeholder="0" />
          </div>
          <div>
            <label className="label">Rating (optional)</label>
            <input type="number" value={rating} onChange={(e) => setRating(e.target.value)} className="input" placeholder="e.g., 1200" />
          </div>
        </div>
        <div className="flex gap-2">
          <button type="submit" className="btn-primary btn-sm">Save</button>
          <button type="button" onClick={onDone} className="btn-secondary btn-sm">Cancel</button>
        </div>
      </form>
    </Card>
  );
}
