import { useState, type FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { Spinner } from '@/components/ui';
import { Sparkles, ArrowRight, ArrowLeft, Check, GraduationCap, Target, Code2, BookOpen, Clock, Palette } from 'lucide-react';
import type { SkillLevel, LearningPreference, StudyTimePerDay } from '@/types';

const careerGoals = [
  'Backend Engineer',
  'Frontend Engineer',
  'Full Stack Developer',
  'AI Engineer',
  'ML Engineer',
  'Data Scientist',
  'Data Analyst',
  'DevOps Engineer',
  'Cloud Engineer',
  'Cybersecurity Engineer',
  'Android Developer',
];

const availableSkills = [
  'Python', 'Java', 'C++', 'JavaScript', 'TypeScript', 'HTML', 'CSS',
  'React', 'Node.js', 'SQL', 'Git', 'DSA', 'Machine Learning',
  'Deep Learning', 'Docker', 'AWS', 'Linux', 'MongoDB', 'Spring Boot',
];

const skillLevels: SkillLevel[] = ['Beginner', 'Intermediate', 'Advanced'];

const studyTimes: StudyTimePerDay[] = ['1 hour/day', '2 hours/day', '3 hours/day', '4+ hours/day'];

const learningPrefs: LearningPreference[] = ['Video', 'Reading', 'Practice', 'Projects', 'Mixed'];

export default function OnboardingPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Step 1 — Student Info
  const [education, setEducation] = useState('');
  const [college, setCollege] = useState('');
  const [year, setYear] = useState('');
  const [experience, setExperience] = useState('');

  // Step 2 — Career Goal
  const [careerGoal, setCareerGoal] = useState('');
  const [customCareerGoal, setCustomCareerGoal] = useState('');

  // Step 3 — Skills
  const [selectedSkills, setSelectedSkills] = useState<Record<string, SkillLevel>>({});

  // Step 4 — Academic Background
  const [academicBackground, setAcademicBackground] = useState('');

  // Step 5 — Study Time
  const [studyTime, setStudyTime] = useState<StudyTimePerDay | ''>('');

  // Step 6 — Learning Preference
  const [learningPref, setLearningPref] = useState<LearningPreference | ''>('');

  const totalSteps = 6;

  const canProceed = () => {
    switch (step) {
      case 1: return education.trim() && college.trim() && year && experience;
      case 2: return careerGoal === 'Custom' ? customCareerGoal.trim() : careerGoal;
      case 3: return Object.keys(selectedSkills).length > 0;
      case 4: return true; // Optional
      case 5: return studyTime;
      case 6: return learningPref;
      default: return false;
    }
  };

  const handleNext = () => {
    if (step < totalSteps) setStep(step + 1);
  };

  const handleBack = () => {
    if (step > 1) setStep(step - 1);
  };

  const toggleSkill = (skill: string) => {
    setSelectedSkills((prev) => {
      const next = { ...prev };
      if (next[skill]) {
        delete next[skill];
      } else {
        next[skill] = 'Beginner';
      }
      return next;
    });
  };

  const setSkillLevel = (skill: string, level: SkillLevel) => {
    setSelectedSkills((prev) => ({ ...prev, [skill]: level }));
  };

  const handleComplete = async (ev: FormEvent) => {
    ev.preventDefault();
    if (!user) return;
    setLoading(true);
    setError(null);

    const finalCareerGoal = careerGoal === 'Custom' ? 'Custom' : careerGoal;
    const finalCustomGoal = careerGoal === 'Custom' ? customCareerGoal.trim() : null;

    const { error: updateError } = await supabase
      .from('student_profiles')
      .update({
        education,
        college,
        year,
        experience,
        career_goal: finalCareerGoal,
        custom_career_goal: finalCustomGoal,
        academic_background: academicBackground || null,
        study_time_per_day: studyTime || null,
        learning_preference: learningPref || null,
        onboarding_completed: true,
        updated_at: new Date().toISOString(),
      })
      .eq('user_id', user.id);

    if (updateError) {
      setError('Failed to save your profile. Please try again.');
      setLoading(false);
      return;
    }

    // Save skills
    const skills = Object.entries(selectedSkills).map(([skill_name, level]) => ({
      user_id: user.id,
      skill_name,
      level,
    }));

    if (skills.length > 0) {
      const { error: skillsError } = await supabase.from('student_skills').insert(skills);
      if (skillsError) {
        setError('Profile saved but skills could not be stored. Please try again.');
        setLoading(false);
        return;
      }
    }

    setLoading(false);
    navigate('/diagnostic');
  };

  const stepIcons = [GraduationCap, Target, Code2, BookOpen, Clock, Palette];
  const CurrentIcon = stepIcons[step - 1];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      {/* Header */}
      <div className="border-b border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
        <div className="mx-auto flex max-w-3xl items-center justify-between px-4 py-4 sm:px-6">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-primary-600 to-secondary-600">
              <Sparkles size={18} className="text-white" />
            </div>
            <span className="font-bold tracking-tight">SkillPath AI</span>
          </div>
          <span className="text-sm text-gray-500 dark:text-gray-400">Step {step} of {totalSteps}</span>
        </div>
        {/* Progress bar */}
        <div className="h-1 bg-gray-100 dark:bg-gray-800">
          <div
            className="h-full bg-gradient-to-r from-primary-600 to-secondary-600 transition-all duration-500"
            style={{ width: `${(step / totalSteps) * 100}%` }}
          />
        </div>
      </div>

      <div className="mx-auto max-w-3xl px-4 py-8 sm:px-6">
        <div className="card p-8 animate-slide-up">
          {/* Step header */}
          <div className="mb-8 flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary-50 dark:bg-primary-950/40">
              <CurrentIcon size={24} className="text-primary-600 dark:text-primary-400" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900 dark:text-gray-50">
                {step === 1 && 'Tell us about yourself'}
                {step === 2 && 'What is your career goal?'}
                {step === 3 && 'What skills do you have?'}
                {step === 4 && 'Academic background'}
                {step === 5 && 'How much time do you have?'}
                {step === 6 && 'How do you prefer to learn?'}
              </h1>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                {step === 1 && 'This helps us personalize your roadmap.'}
                {step === 2 && 'Choose the career you are working towards.'}
                {step === 3 && 'Select your current skills and rate your level. Self-reported levels are just a starting point — the diagnostic will verify them.'}
                {step === 4 && 'Share your academic marks or grades (optional).'}
                {step === 5 && 'We will plan your study schedule around your availability.'}
                {step === 6 && 'We will tailor your learning resources accordingly.'}
              </p>
            </div>
          </div>

          {error && (
            <div className="mb-6 rounded-lg border border-error-200 bg-error-50 px-4 py-3 text-sm text-error-700 dark:border-error-800 dark:bg-error-950/30 dark:text-error-300">
              {error}
            </div>
          )}

          {/* Step 1 — Student Info */}
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <label className="label">Education Level</label>
                <select value={education} onChange={(e) => setEducation(e.target.value)} className="input">
                  <option value="">Select your education level</option>
                  <option value="High School">High School</option>
                  <option value="Diploma">Diploma</option>
                  <option value="Undergraduate">Undergraduate</option>
                  <option value="Postgraduate">Postgraduate</option>
                  <option value="Self-taught">Self-taught</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              <div>
                <label className="label">College / Institution</label>
                <input type="text" value={college} onChange={(e) => setCollege(e.target.value)} className="input" placeholder="e.g., IIT Delhi" />
              </div>
              <div>
                <label className="label">Year of Study</label>
                <select value={year} onChange={(e) => setYear(e.target.value)} className="input">
                  <option value="">Select year</option>
                  <option value="1st Year">1st Year</option>
                  <option value="2nd Year">2nd Year</option>
                  <option value="3rd Year">3rd Year</option>
                  <option value="4th Year">4th Year</option>
                  <option value="5th Year">5th Year</option>
                  <option value="Graduated">Graduated</option>
                  <option value="Not Applicable">Not Applicable</option>
                </select>
              </div>
              <div>
                <label className="label">Programming Experience</label>
                <select value={experience} onChange={(e) => setExperience(e.target.value)} className="input">
                  <option value="">Select your experience</option>
                  <option value="No experience">No experience</option>
                  <option value="Less than 6 months">Less than 6 months</option>
                  <option value="6 months - 1 year">6 months - 1 year</option>
                  <option value="1-2 years">1-2 years</option>
                  <option value="2-3 years">2-3 years</option>
                  <option value="3+ years">3+ years</option>
                </select>
              </div>
            </div>
          )}

          {/* Step 2 — Career Goal */}
          {step === 2 && (
            <div className="space-y-4">
              <div className="grid gap-3 sm:grid-cols-2">
                {careerGoals.map((goal) => (
                  <button
                    key={goal}
                    type="button"
                    onClick={() => setCareerGoal(goal)}
                    className={`flex items-center justify-between rounded-lg border px-4 py-3 text-left text-sm font-medium transition-all ${
                      careerGoal === goal
                        ? 'border-primary-500 bg-primary-50 text-primary-700 dark:border-primary-500 dark:bg-primary-950/40 dark:text-primary-300'
                        : 'border-gray-200 text-gray-700 hover:border-gray-300 dark:border-gray-700 dark:text-gray-300 dark:hover:border-gray-600'
                    }`}
                  >
                    {goal}
                    {careerGoal === goal && <Check size={16} />}
                  </button>
                ))}
              </div>
              <button
                type="button"
                onClick={() => setCareerGoal('Custom')}
                className={`flex items-center justify-between rounded-lg border px-4 py-3 text-left text-sm font-medium transition-all w-full ${
                  careerGoal === 'Custom'
                    ? 'border-primary-500 bg-primary-50 text-primary-700 dark:border-primary-500 dark:bg-primary-950/40 dark:text-primary-300'
                    : 'border-gray-200 text-gray-700 hover:border-gray-300 dark:border-gray-700 dark:text-gray-300 dark:hover:border-gray-600'
                }`}
              >
                Custom goal
                {careerGoal === 'Custom' && <Check size={16} />}
              </button>
              {careerGoal === 'Custom' && (
                <input
                  type="text"
                  value={customCareerGoal}
                  onChange={(e) => setCustomCareerGoal(e.target.value)}
                  className="input"
                  placeholder="e.g., Game Developer, Blockchain Engineer..."
                />
              )}
            </div>
          )}

          {/* Step 3 — Skills */}
          {step === 3 && (
            <div className="space-y-4">
              <p className="text-sm text-gray-500 dark:text-gray-400">Select all skills you have some experience with. Rate each one honestly — the diagnostic will verify your actual level.</p>
              <div className="space-y-2">
                {availableSkills.map((skill) => {
                  const selected = selectedSkills[skill];
                  return (
                    <div key={skill} className={`rounded-lg border p-3 transition-all ${selected ? 'border-primary-300 bg-primary-50/50 dark:border-primary-700 dark:bg-primary-950/20' : 'border-gray-200 dark:border-gray-700'}`}>
                      <div className="flex items-center justify-between">
                        <button type="button" onClick={() => toggleSkill(skill)} className="flex items-center gap-2 text-sm font-medium">
                          <div className={`flex h-5 w-5 items-center justify-center rounded border ${selected ? 'border-primary-600 bg-primary-600' : 'border-gray-300 dark:border-gray-600'}`}>
                            {selected && <Check size={14} className="text-white" />}
                          </div>
                          {skill}
                        </button>
                        {selected && (
                          <div className="flex gap-1">
                            {skillLevels.map((level) => (
                              <button
                                key={level}
                                type="button"
                                onClick={() => setSkillLevel(skill, level)}
                                className={`rounded-md px-2.5 py-1 text-xs font-medium transition-colors ${
                                  selectedSkills[skill] === level
                                    ? 'bg-primary-600 text-white'
                                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-gray-700'
                                }`}
                              >
                                {level}
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
              <p className="text-xs text-gray-400 dark:text-gray-500">{Object.keys(selectedSkills).length} skills selected</p>
            </div>
          )}

          {/* Step 4 — Academic Background */}
          {step === 4 && (
            <div className="space-y-4">
              <label className="label">Academic marks / grades (optional)</label>
              <textarea
                value={academicBackground}
                onChange={(e) => setAcademicBackground(e.target.value)}
                className="input min-h-[120px] resize-y"
                placeholder="e.g., CGPA: 8.5/10, 12th: 92%, 10th: 89%..."
              />
              <p className="text-xs text-gray-400 dark:text-gray-500">This is optional and helps us understand your academic background.</p>
            </div>
          )}

          {/* Step 5 — Study Time */}
          {step === 5 && (
            <div className="grid gap-3 sm:grid-cols-2">
              {studyTimes.map((time) => (
                <button
                  key={time}
                  type="button"
                  onClick={() => setStudyTime(time)}
                  className={`flex items-center justify-between rounded-lg border px-4 py-3 text-left text-sm font-medium transition-all ${
                    studyTime === time
                      ? 'border-primary-500 bg-primary-50 text-primary-700 dark:border-primary-500 dark:bg-primary-950/40 dark:text-primary-300'
                      : 'border-gray-200 text-gray-700 hover:border-gray-300 dark:border-gray-700 dark:text-gray-300 dark:hover:border-gray-600'
                  }`}
                >
                  <span className="flex items-center gap-2">
                    <Clock size={16} />
                    {time}
                  </span>
                  {studyTime === time && <Check size={16} />}
                </button>
              ))}
            </div>
          )}

          {/* Step 6 — Learning Preference */}
          {step === 6 && (
            <div className="grid gap-3 sm:grid-cols-2">
              {learningPrefs.map((pref) => (
                <button
                  key={pref}
                  type="button"
                  onClick={() => setLearningPref(pref)}
                  className={`flex items-center justify-between rounded-lg border px-4 py-3 text-left text-sm font-medium transition-all ${
                    learningPref === pref
                      ? 'border-primary-500 bg-primary-50 text-primary-700 dark:border-primary-500 dark:bg-primary-950/40 dark:text-primary-300'
                      : 'border-gray-200 text-gray-700 hover:border-gray-300 dark:border-gray-700 dark:text-gray-300 dark:hover:border-gray-600'
                  }`}
                >
                  <span className="flex items-center gap-2">
                    <Palette size={16} />
                    {pref}
                  </span>
                  {learningPref === pref && <Check size={16} />}
                </button>
              ))}
            </div>
          )}

          {/* Navigation */}
          <div className="mt-8 flex items-center justify-between">
            <button
              type="button"
              onClick={handleBack}
              className="btn-secondary"
              disabled={step === 1}
            >
              <ArrowLeft size={18} /> Back
            </button>

            {step < totalSteps ? (
              <button
                type="button"
                onClick={handleNext}
                className="btn-primary"
                disabled={!canProceed()}
              >
                Next <ArrowRight size={18} />
              </button>
            ) : (
              <button
                type="submit"
                onClick={handleComplete}
                className="btn-primary"
                disabled={loading || !canProceed()}
              >
                {loading ? <Spinner size={18} /> : <>Generate My Diagnostic Assessment <ArrowRight size={18} /></>}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
