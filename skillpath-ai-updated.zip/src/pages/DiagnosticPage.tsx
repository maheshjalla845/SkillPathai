import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { generateAssessment, generateWeaknessAnalysis, type AIQuestion } from '@/lib/api/ai';
import { Spinner, ErrorBanner, ProgressBar } from '@/components/ui';
import type { StudentProfile, StudentSkill } from '@/types';
import {
  Sparkles,
  AlertCircle,
  Check,
  X,
  Clock,
  ArrowRight,
  ArrowLeft,
  Brain,
  Trophy,
} from 'lucide-react';

type Phase = 'loading-profile' | 'generating' | 'taking' | 'submitting' | 'results';

interface QuestionState extends AIQuestion {
  selectedAnswer: string | null;
  timeStarted: number;
}

export default function DiagnosticPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [phase, setPhase] = useState<Phase>('loading-profile');
  const [profile, setProfile] = useState<StudentProfile | null>(null);
  const [skills, setSkills] = useState<StudentSkill[]>([]);
  const [questions, setQuestions] = useState<QuestionState[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [score, setScore] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [totalCount, setTotalCount] = useState(0);

  useEffect(() => {
    const init = async () => {
      if (!user) return;

      const { data: prof } = await supabase
        .from('student_profiles')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (!prof || !prof.onboarding_completed) {
        navigate('/onboarding');
        return;
      }

      if (prof.diagnostic_completed) {
        navigate('/dashboard');
        return;
      }

      setProfile(prof as StudentProfile);

      const { data: sk } = await supabase
        .from('student_skills')
        .select('*')
        .eq('user_id', user.id);

      setSkills((sk ?? []) as StudentSkill[]);
      setPhase('generating');
      await generateQuestions(prof as StudentProfile, (sk ?? []) as StudentSkill[]);
    };
    init();
  }, [user, navigate]);

  const generateQuestions = async (prof: StudentProfile, sk: StudentSkill[]) => {
    try {
      setError(null);
      const careerGoal = prof.custom_career_goal || prof.career_goal || 'Software Engineer';
      const result = await generateAssessment({
        assessment_type: 'diagnostic',
        career_goal: careerGoal,
        skills: sk.map((s) => ({ skill_name: s.skill_name, level: s.level })),
      });

      const qs: QuestionState[] = result.questions.map((q) => ({
        ...q,
        selectedAnswer: null,
        timeStarted: Date.now(),
      }));

      setQuestions(qs);
      setPhase('taking');
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to generate assessment';
      setError(msg);
      setPhase('generating');
    }
  };

  const selectAnswer = (answer: string) => {
    setQuestions((prev) =>
      prev.map((q, i) => (i === currentIndex ? { ...q, selectedAnswer: answer } : q))
    );
  };

  const handleNext = useCallback(async () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(currentIndex + 1);
      return;
    }

    // Submit assessment
    setPhase('submitting');
    if (!user || !profile) return;

    let correct = 0;
    const questionRecords = questions.map((q) => {
      const isCorrect = q.selectedAnswer === q.correct_answer;
      if (isCorrect) correct++;
      return {
        question_text: q.question_text,
        question_type: q.question_type,
        topic: q.topic,
        subtopic: q.subtopic,
        difficulty: q.difficulty,
        options: q.options,
        correct_answer: q.correct_answer,
        selected_answer: q.selectedAnswer,
        is_correct: isCorrect,
        time_taken_seconds: Math.round((Date.now() - q.timeStarted) / 1000),
      };
    });

    const totalQuestions = questions.length;
    const scorePct = Math.round((correct / totalQuestions) * 100);

    // Insert assessment
    const { data: assessment, error: assessError } = await supabase
      .from('assessments')
      .insert({
        user_id: user.id,
        type: 'diagnostic',
        topic_name: null,
        total_questions: totalQuestions,
        score: scorePct,
      })
      .select()
      .single();

    if (assessError) {
      setError('Failed to save assessment results.');
      setPhase('taking');
      return;
    }

    // Insert questions
    const { error: qError } = await supabase.from('assessment_questions').insert(
      questionRecords.map((qr) => ({ ...qr, assessment_id: assessment.id }))
    );

    if (qError) {
      setError('Failed to save question details.');
      setPhase('taking');
      return;
    }

    // Update verified proficiency on skills
    const topicScores: Record<string, { correct: number; total: number }> = {};
    questions.forEach((q) => {
      if (!topicScores[q.topic]) topicScores[q.topic] = { correct: 0, total: 0 };
      topicScores[q.topic].total++;
      if (q.selectedAnswer === q.correct_answer) topicScores[q.topic].correct++;
    });

    const skillUpdates = Object.entries(topicScores).map(async ([topic, scores]) => {
      const proficiency = Math.round((scores.correct / scores.total) * 100);
      await supabase
        .from('student_skills')
        .update({ verified_proficiency: proficiency })
        .eq('user_id', user.id)
        .eq('skill_name', topic);
    });

    await Promise.all(skillUpdates);

    // Mark diagnostic completed
    await supabase
      .from('student_profiles')
      .update({ diagnostic_completed: true })
      .eq('user_id', user.id);

    // Analyze weaknesses in the background (don't block the results screen)
    generateWeaknessAnalysis({
      assessment_id: assessment.id,
      questions: questionRecords.map((qr) => ({
        topic: qr.topic,
        subtopic: qr.subtopic || '',
        is_correct: qr.is_correct || false,
        difficulty: qr.difficulty,
        question_text: qr.question_text,
        selected_answer: qr.selected_answer || '',
        correct_answer: qr.correct_answer,
      })),
    }).catch(() => {
      // Weakness analysis failure should not block the user
    });

    setScore(scorePct);
    setCorrectCount(correct);
    setTotalCount(totalQuestions);
    setPhase('results');
  }, [currentIndex, questions, user, profile]);

  const handleProceedToRoadmap = () => {
    navigate('/roadmap?generate=true');
  };

  // --- RENDER PHASES ---

  if (phase === 'loading-profile') {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-gray-50 dark:bg-gray-950">
        <Spinner size={32} className="text-primary-600" />
        <p className="text-sm text-gray-500 dark:text-gray-400">Loading your profile...</p>
      </div>
    );
  }

  if (phase === 'generating') {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-6 bg-gray-50 dark:bg-gray-950">
        <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-primary-600 to-secondary-600">
          <Brain size={32} className="text-white animate-pulse" />
        </div>
        <div className="text-center">
          <h2 className="text-xl font-bold text-gray-900 dark:text-gray-50">Generating Your Diagnostic Assessment</h2>
          <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
            AI is creating personalized questions based on your skills and career goal...
          </p>
        </div>
        <Spinner size={24} className="text-primary-600" />
        {error && (
          <div className="max-w-md">
            <ErrorBanner message={error} />
            <button onClick={() => profile && generateQuestions(profile, skills)} className="btn-primary mt-4 w-full">
              Try Again
            </button>
          </div>
        )}
      </div>
    );
  }

  if (phase === 'submitting') {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-gray-50 dark:bg-gray-950">
        <Spinner size={32} className="text-primary-600" />
        <p className="text-sm text-gray-500 dark:text-gray-400">Submitting your assessment...</p>
      </div>
    );
  }

  if (phase === 'results') {
    const passed = score >= 40;
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
        <div className="mx-auto max-w-2xl px-4 py-12 sm:px-6">
          <div className="card p-8 text-center animate-slide-up">
            <div className={`mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-full ${passed ? 'bg-success-100 dark:bg-success-900/30' : 'bg-warning-100 dark:bg-warning-900/30'}`}>
              <Trophy size={40} className={passed ? 'text-success-600 dark:text-success-400' : 'text-warning-600 dark:text-warning-400'} />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-50">Diagnostic Complete!</h1>
            <p className="mt-2 text-gray-500 dark:text-gray-400">
              You answered {correctCount} out of {totalCount} questions correctly.
            </p>

            <div className="my-8">
              <div className="text-5xl font-bold text-primary-600 dark:text-primary-400">{score}%</div>
              <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">Overall Score</p>
            </div>

            <div className="rounded-lg border border-gray-200 bg-gray-50 p-4 dark:border-gray-800 dark:bg-gray-900/50">
              <p className="text-sm text-gray-600 dark:text-gray-400">
                {passed
                  ? 'Great job! Your AI-personalized roadmap is ready to be generated based on your actual skill level.'
                  : 'Your roadmap will focus on building fundamentals first. Everyone starts somewhere!'}
              </p>
            </div>

            <button onClick={handleProceedToRoadmap} className="btn-primary btn-lg mt-8 w-full">
              Generate My Roadmap <ArrowRight size={18} />
            </button>
          </div>
        </div>
      </div>
    );
  }

  // --- TAKING PHASE ---
  const q = questions[currentIndex];
  if (!q) return null;
  const progress = ((currentIndex + 1) / questions.length) * 100;

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      {/* Header */}
      <div className="border-b border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
        <div className="mx-auto flex max-w-3xl items-center justify-between px-4 py-4 sm:px-6">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-primary-600 to-secondary-600">
              <Sparkles size={16} className="text-white" />
            </div>
            <span className="font-bold tracking-tight">Diagnostic Assessment</span>
          </div>
          <span className="flex items-center gap-1.5 text-sm text-gray-500 dark:text-gray-400">
            <Clock size={16} />
            Question {currentIndex + 1} of {questions.length}
          </span>
        </div>
        <div className="h-1 bg-gray-100 dark:bg-gray-800">
          <div className="h-full bg-gradient-to-r from-primary-600 to-secondary-600 transition-all duration-500" style={{ width: `${progress}%` }} />
        </div>
      </div>

      <div className="mx-auto max-w-3xl px-4 py-8 sm:px-6">
        {error && <div className="mb-6"><ErrorBanner message={error} /></div>}

        <div className="card p-8 animate-slide-up">
          {/* Question meta */}
          <div className="mb-4 flex flex-wrap items-center gap-2">
            <span className="badge-primary">{q.topic}</span>
            {q.subtopic && <span className="badge-neutral">{q.subtopic}</span>}
            <span className={
              q.difficulty === 'easy' ? 'badge-success' :
              q.difficulty === 'medium' ? 'badge-warning' : 'badge-error'
            }>{q.difficulty}</span>
            <span className="badge-neutral capitalize">{q.question_type.replace(/_/g, ' ')}</span>
          </div>

          {/* Question text */}
          <h2 className="mb-6 text-lg font-semibold leading-relaxed text-gray-900 dark:text-gray-50">
            {q.question_text}
          </h2>

          {/* Options */}
          {q.options && q.options.length > 0 ? (
            <div className="space-y-3">
              {q.options.map((opt, i) => (
                <button
                  key={i}
                  onClick={() => selectAnswer(opt)}
                  className={`flex w-full items-center gap-3 rounded-lg border px-4 py-3 text-left text-sm font-medium transition-all ${
                    q.selectedAnswer === opt
                      ? 'border-primary-500 bg-primary-50 text-primary-700 dark:border-primary-500 dark:bg-primary-950/40 dark:text-primary-300'
                      : 'border-gray-200 text-gray-700 hover:border-gray-300 dark:border-gray-700 dark:text-gray-300 dark:hover:border-gray-600'
                  }`}
                >
                  <div className={`flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full border-2 ${
                    q.selectedAnswer === opt
                      ? 'border-primary-600 bg-primary-600'
                      : 'border-gray-300 dark:border-gray-600'
                  }`}>
                    {q.selectedAnswer === opt && <Check size={14} className="text-white" />}
                  </div>
                  <span className="font-mono text-xs text-gray-400">{String.fromCharCode(65 + i)}</span>
                  <span className="flex-1">{opt}</span>
                </button>
              ))}
            </div>
          ) : (
            <div>
              <textarea
                value={q.selectedAnswer ?? ''}
                onChange={(e) => selectAnswer(e.target.value)}
                className="input min-h-[150px] resize-y font-mono text-sm"
                placeholder="Type your answer here..."
              />
            </div>
          )}

          {/* Navigation */}
          <div className="mt-8 flex items-center justify-between">
            <button
              onClick={() => setCurrentIndex(Math.max(0, currentIndex - 1))}
              className="btn-secondary"
              disabled={currentIndex === 0}
            >
              <ArrowLeft size={18} /> Previous
            </button>
            <span className="text-sm text-gray-400 dark:text-gray-500">
              {currentIndex + 1} / {questions.length}
            </span>
            <button
              onClick={handleNext}
              className="btn-primary"
              disabled={!q.selectedAnswer}
            >
              {currentIndex === questions.length - 1 ? 'Submit Assessment' : 'Next'}
              {currentIndex < questions.length - 1 ? <ArrowRight size={18} /> : <Check size={18} />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
