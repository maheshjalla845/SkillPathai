import { useEffect, useState, useCallback } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { generateRoadmap } from '@/lib/api/ai';
import { Card, EmptyState, ProgressBar, Spinner, ErrorBanner, Skeleton } from '@/components/ui';
import type { Roadmap, RoadmapPhase, RoadmapTopic, StudentProfile, StudentSkill, TopicStatus } from '@/types';
import {
  Route as RouteIcon,
  Sparkles,
  ArrowRight,
  Clock,
  Target,
  BookOpen,
  Check,
  Circle,
  Play,
  RefreshCw,
  ChevronDown,
  ChevronRight,
  Lightbulb,
  Code2,
  FileQuestion,
  TrendingUp,
} from 'lucide-react';

interface PhaseWithTopics extends RoadmapPhase {
  topics: RoadmapTopic[];
}

export default function RoadmapPage() {
  const { user } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const [profile, setProfile] = useState<StudentProfile | null>(null);
  const [roadmap, setRoadmap] = useState<Roadmap | null>(null);
  const [phases, setPhases] = useState<PhaseWithTopics[]>([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [expandedPhase, setExpandedPhase] = useState<number | null>(0);
  const [updatingTopicId, setUpdatingTopicId] = useState<string | null>(null);

  const loadRoadmap = useCallback(async (userId: string) => {
    const { data: prof } = await supabase
      .from('student_profiles')
      .select('*')
      .eq('user_id', userId)
      .maybeSingle();

    if (!prof) {
      navigate('/onboarding');
      return;
    }

    setProfile(prof as StudentProfile);

    if (!prof.diagnostic_completed) {
      navigate('/diagnostic');
      return;
    }

    const { data: rm } = await supabase
      .from('roadmaps')
      .select('*')
      .eq('user_id', userId)
      .maybeSingle();

    if (rm) {
      setRoadmap(rm as Roadmap);
      const { data: ph } = await supabase
        .from('roadmap_phases')
        .select('*')
        .eq('roadmap_id', rm.id)
        .order('phase_number', { ascending: true });

      const { data: topics } = await supabase
        .from('roadmap_topics')
        .select('*')
        .eq('roadmap_id', rm.id)
        .order('order_index', { ascending: true });

      const phWithTopics: PhaseWithTopics[] = (ph ?? []).map((p) => ({
        ...p,
        topics: (topics ?? []).filter((t) => t.phase_id === p.id),
      }));
      setPhases(phWithTopics);
    }

    setLoading(false);
  }, [navigate]);

  useEffect(() => {
    if (!user) return;
    loadRoadmap(user.id);
  }, [user, loadRoadmap]);

  const handleGenerate = async () => {
    if (!user || !profile) return;
    setGenerating(true);
    setError(null);

    try {
      const { data: skills } = await supabase
        .from('student_skills')
        .select('*')
        .eq('user_id', user.id);

      // Get diagnostic results
      const { data: diagAssessment } = await supabase
        .from('assessments')
        .select('id')
        .eq('user_id', user.id)
        .eq('type', 'diagnostic')
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      let diagnosticResults: { topic: string; subtopic: string; is_correct: boolean; difficulty: string }[] = [];

      if (diagAssessment) {
        const { data: questions } = await supabase
          .from('assessment_questions')
          .select('topic, subtopic, is_correct, difficulty')
          .eq('assessment_id', diagAssessment.id);

        diagnosticResults = (questions ?? []).map((q) => ({
          topic: q.topic,
          subtopic: q.subtopic || '',
          is_correct: q.is_correct || false,
          difficulty: q.difficulty,
        }));
      }

      const careerGoal = profile.custom_career_goal || profile.career_goal || 'Software Engineer';

      await generateRoadmap({
        career_goal: careerGoal,
        skills: (skills ?? []).map((s: StudentSkill) => ({ skill_name: s.skill_name, level: s.level })),
        diagnostic_results: diagnosticResults,
        study_time_per_day: profile.study_time_per_day || '2 hours/day',
        learning_preference: profile.learning_preference || 'Mixed',
      });

      // Reload roadmap
      setLoading(true);
      await loadRoadmap(user.id);
      setSearchParams({});
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to generate roadmap';
      setError(msg);
    } finally {
      setGenerating(false);
    }
  };

  // Auto-generate if ?generate=true is in the URL
  useEffect(() => {
    if (searchParams.get('generate') === 'true' && !generating && !loading && !roadmap && profile) {
      handleGenerate();
    }
  }, [searchParams, generating, loading, roadmap, profile]);

  const updateTopicStatus = async (topicId: string, status: TopicStatus) => {
    setUpdatingTopicId(topicId);
    const updates: Record<string, unknown> = { status };
    if (status === 'IN_PROGRESS') updates.started_at = new Date().toISOString();
    if (status === 'COMPLETED') updates.completed_at = new Date().toISOString();

    // Also update proficiency when completing
    if (status === 'COMPLETED') {
      const topic = phases.flatMap((p) => p.topics).find((t) => t.id === topicId);
      if (topic) updates.current_proficiency = topic.target_proficiency;
    }

    await supabase.from('roadmap_topics').update(updates).eq('id', topicId);

    // Update local state
    setPhases((prev) =>
      prev.map((p) => ({
        ...p,
        topics: p.topics.map((t) =>
          t.id === topicId
            ? { ...t, status, current_proficiency: status === 'COMPLETED' ? t.target_proficiency : t.current_proficiency, started_at: status === 'IN_PROGRESS' ? new Date().toISOString() : t.started_at, completed_at: status === 'COMPLETED' ? new Date().toISOString() : t.completed_at }
            : t
        ),
      }))
    );
    setUpdatingTopicId(null);
  };

  const totalTopics = phases.reduce((sum, p) => sum + p.topics.length, 0);
  const completedTopics = phases.reduce((sum, p) => sum + p.topics.filter((t) => t.status === 'COMPLETED').length, 0);
  const inProgressTopics = phases.reduce((sum, p) => sum + p.topics.filter((t) => t.status === 'IN_PROGRESS').length, 0);
  const overallProgress = totalTopics > 0 ? Math.round((completedTopics / totalTopics) * 100) : 0;

  if (loading) {
    return (
      <div className="mx-auto max-w-5xl space-y-6">
        <Skeleton className="h-16 w-full" />
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (generating) {
    return (
      <div className="mx-auto flex max-w-2xl flex-col items-center justify-center py-20">
        <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-primary-600 to-secondary-600">
          <Sparkles size={32} className="animate-pulse text-white" />
        </div>
        <h2 className="mt-6 text-xl font-bold text-gray-900 dark:text-gray-50">Generating Your Personalized Roadmap</h2>
        <p className="mt-2 text-center text-sm text-gray-500 dark:text-gray-400">
          AI is analyzing your diagnostic results, skills, and career goal to create a step-by-step learning plan...
        </p>
        <Spinner size={24} className="mt-6 text-primary-600" />
        {error && (
          <div className="mt-6 w-full max-w-md">
            <ErrorBanner message={error} />
            <button onClick={handleGenerate} className="btn-primary mt-4 w-full">Try Again</button>
          </div>
        )}
      </div>
    );
  }

  if (!roadmap) {
    return (
      <div className="mx-auto max-w-7xl">
        <h1 className="mb-6 text-2xl font-bold text-gray-900 dark:text-gray-50">My Roadmap</h1>
        <Card className="p-8">
          <EmptyState
            icon={RouteIcon}
            title="No roadmap yet"
            description="Generate your personalized AI roadmap based on your diagnostic results and career goals."
            action={
              <button onClick={handleGenerate} className="btn-primary">
                <Sparkles size={18} /> Generate Roadmap
              </button>
            }
          />
          {error && <div className="mt-4"><ErrorBanner message={error} /></div>}
        </Card>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-50">My Roadmap</h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            Target: {profile?.custom_career_goal || profile?.career_goal}
          </p>
        </div>
        <button onClick={handleGenerate} className="btn-secondary btn-sm" disabled={generating}>
          <RefreshCw size={16} /> Regenerate
        </button>
      </div>

      {/* Progress overview */}
      <Card className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">Overall Progress</h2>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              {completedTopics} of {totalTopics} topics completed · {inProgressTopics} in progress
            </p>
          </div>
          <span className="text-3xl font-bold text-primary-600 dark:text-primary-400">{overallProgress}%</span>
        </div>
        <ProgressBar value={overallProgress} className="mt-4 h-3" />
      </Card>

      {/* Phases */}
      <div className="space-y-4">
        {phases.map((phase, phaseIdx) => {
          const phaseCompleted = phase.topics.filter((t) => t.status === 'COMPLETED').length;
          const phaseTotal = phase.topics.length;
          const phaseProgress = phaseTotal > 0 ? Math.round((phaseCompleted / phaseTotal) * 100) : 0;
          const isExpanded = expandedPhase === phaseIdx;

          return (
            <Card key={phase.id} className="overflow-hidden">
              {/* Phase header */}
              <button
                onClick={() => setExpandedPhase(isExpanded ? null : phaseIdx)}
                className="flex w-full items-center justify-between p-5 text-left transition-colors hover:bg-gray-50 dark:hover:bg-gray-900/50"
              >
                <div className="flex items-center gap-4">
                  <div className={`flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-lg font-bold ${
                    phaseProgress === 100
                      ? 'bg-success-100 text-success-700 dark:bg-success-900/30 dark:text-success-400'
                      : phaseProgress > 0
                      ? 'bg-primary-100 text-primary-700 dark:bg-primary-900/30 dark:text-primary-400'
                      : 'bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400'
                  }`}>
                    {phaseProgress === 100 ? <Check size={20} /> : phase.phase_number}
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 dark:text-gray-100">{phase.title}</h3>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {phaseCompleted}/{phaseTotal} topics · {phaseProgress}% complete
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="hidden w-24 sm:block">
                    <ProgressBar value={phaseProgress} className="h-1.5" color={phaseProgress === 100 ? 'success' : 'primary'} />
                  </div>
                  {isExpanded ? <ChevronDown size={20} className="text-gray-400" /> : <ChevronRight size={20} className="text-gray-400" />}
                </div>
              </button>

              {/* Phase topics */}
              {isExpanded && (
                <div className="border-t border-gray-200 dark:border-gray-800">
                  {phase.description && (
                    <p className="px-5 py-3 text-sm text-gray-600 dark:text-gray-400 bg-gray-50/50 dark:bg-gray-900/30">
                      {phase.description}
                    </p>
                  )}
                  <div className="divide-y divide-gray-100 dark:divide-gray-800">
                    {phase.topics.map((topic, topicIdx) => {
                      // Check if prerequisites are met
                      const prereqsMet = topic.prerequisites.length === 0 ||
                        topic.prerequisites.every((prereq) => {
                          const prereqTopic = phases.flatMap((p) => p.topics).find((t) => t.topic_name === prereq);
                          return prereqTopic?.status === 'COMPLETED';
                        });

                      return (
                        <TopicRow
                          key={topic.id}
                          topic={topic}
                          topicIdx={topicIdx}
                          prereqsMet={prereqsMet}
                          updating={updatingTopicId === topic.id}
                          onUpdateStatus={(status) => updateTopicStatus(topic.id, status)}
                          onLearn={() => navigate(`/learning?topic=${encodeURIComponent(topic.topic_name)}`)}
                        />
                      );
                    })}
                  </div>
                </div>
              )}
            </Card>
          );
        })}
      </div>
    </div>
  );
}

function TopicRow({
  topic,
  topicIdx,
  prereqsMet,
  updating,
  onUpdateStatus,
  onLearn,
}: {
  topic: RoadmapTopic;
  topicIdx: number;
  prereqsMet: boolean;
  updating: boolean;
  onUpdateStatus: (status: TopicStatus) => void;
  onLearn: () => void;
}) {
  const [showDetails, setShowDetails] = useState(false);

  const statusConfig = {
    NOT_STARTED: { icon: Circle, label: 'Not Started', color: 'text-gray-400', badge: 'badge-neutral' },
    IN_PROGRESS: { icon: Play, label: 'In Progress', color: 'text-primary-600', badge: 'badge-primary' },
    COMPLETED: { icon: Check, label: 'Completed', color: 'text-success-600', badge: 'badge-success' },
    NEEDS_REVISION: { icon: RefreshCw, label: 'Needs Revision', color: 'text-warning-600', badge: 'badge-warning' },
  };

  const config = statusConfig[topic.status];
  const StatusIcon = config.icon;

  return (
    <div className="px-5 py-4">
      <div className="flex items-start gap-3">
        <StatusIcon size={20} className={`mt-0.5 flex-shrink-0 ${config.color}`} />

        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div className="flex-1 min-w-0">
              <h4 className="font-medium text-gray-900 dark:text-gray-100">{topic.topic_name}</h4>
              {topic.description && (
                <p className="mt-0.5 text-sm text-gray-500 dark:text-gray-400 line-clamp-2">{topic.description}</p>
              )}
            </div>
            <span className={config.badge + ' flex-shrink-0'}>{config.label}</span>
          </div>

          {/* Meta info */}
          <div className="mt-2 flex flex-wrap items-center gap-3 text-xs text-gray-400 dark:text-gray-500">
            <span className="flex items-center gap-1">
              <Clock size={12} /> {topic.estimated_hours}h
            </span>
            <span className="flex items-center gap-1">
              <Target size={12} /> {topic.current_proficiency}/{topic.target_proficiency}%
            </span>
            {topic.priority === 'high' && <span className="badge-error text-xs">High Priority</span>}
            {topic.priority === 'medium' && <span className="badge-warning text-xs">Medium</span>}
            {!prereqsMet && <span className="text-warning-600 dark:text-warning-400">Prerequisites not met</span>}
          </div>

          {/* Toggle details */}
          <button
            onClick={() => setShowDetails(!showDetails)}
            className="mt-2 flex items-center gap-1 text-xs font-medium text-primary-600 hover:text-primary-700 dark:text-primary-400"
          >
            {showDetails ? 'Hide details' : 'Show details'}
            {showDetails ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
          </button>

          {/* Details panel */}
          {showDetails && (
            <div className="mt-3 space-y-3 rounded-lg border border-gray-200 bg-gray-50 p-4 dark:border-gray-800 dark:bg-gray-900/50">
              {topic.subtopics.length > 0 && (
                <div>
                  <p className="mb-1 flex items-center gap-1 text-xs font-semibold text-gray-700 dark:text-gray-300">
                    <BookOpen size={12} /> Subtopics
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {topic.subtopics.map((s, i) => (
                      <span key={i} className="rounded-md bg-gray-100 px-2 py-0.5 text-xs text-gray-600 dark:bg-gray-800 dark:text-gray-400">{s}</span>
                    ))}
                  </div>
                </div>
              )}
              {topic.resources.length > 0 && (
                <div>
                  <p className="mb-1 flex items-center gap-1 text-xs font-semibold text-gray-700 dark:text-gray-300">
                    <Lightbulb size={12} /> Resources
                  </p>
                  <ul className="space-y-1 text-xs text-gray-600 dark:text-gray-400">
                    {topic.resources.map((r, i) => <li key={i}>· {r}</li>)}
                  </ul>
                </div>
              )}
              {topic.practice.length > 0 && (
                <div>
                  <p className="mb-1 flex items-center gap-1 text-xs font-semibold text-gray-700 dark:text-gray-300">
                    <Code2 size={12} /> Practice
                  </p>
                  <ul className="space-y-1 text-xs text-gray-600 dark:text-gray-400">
                    {topic.practice.map((p, i) => <li key={i}>· {p}</li>)}
                  </ul>
                </div>
              )}
              {topic.prerequisites.length > 0 && (
                <div>
                  <p className="mb-1 flex items-center gap-1 text-xs font-semibold text-gray-700 dark:text-gray-300">
                    <Target size={12} /> Prerequisites
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {topic.prerequisites.map((p, i) => (
                      <span key={i} className="rounded-md bg-gray-100 px-2 py-0.5 text-xs text-gray-600 dark:bg-gray-800 dark:text-gray-400">{p}</span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Action buttons */}
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <button onClick={onLearn} className="btn-secondary btn-sm">
              <BookOpen size={14} /> Learn
            </button>
            {topic.status === 'NOT_STARTED' && (
              <button onClick={() => onUpdateStatus('IN_PROGRESS')} className="btn-primary btn-sm" disabled={updating}>
                {updating ? <Spinner size={14} /> : <Play size={14} />} Start
              </button>
            )}
            {topic.status === 'IN_PROGRESS' && (
              <>
                <button onClick={() => onUpdateStatus('COMPLETED')} className="btn-primary btn-sm" disabled={updating}>
                  {updating ? <Spinner size={14} /> : <Check size={14} />} Mark Complete
                </button>
                <button onClick={() => onUpdateStatus('NEEDS_REVISION')} className="btn-secondary btn-sm">
                  <RefreshCw size={14} /> Needs Revision
                </button>
              </>
            )}
            {topic.status === 'NEEDS_REVISION' && (
              <button onClick={() => onUpdateStatus('IN_PROGRESS')} className="btn-primary btn-sm" disabled={updating}>
                {updating ? <Spinner size={14} /> : <Play size={14} />} Revise Again
              </button>
            )}
            {topic.status === 'COMPLETED' && (
              <button onClick={() => onUpdateStatus('IN_PROGRESS')} className="btn-secondary btn-sm">
                <RefreshCw size={14} /> Revisit
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
