import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useTheme } from '@/context/ThemeContext';
import { Card } from '@/components/ui';
import {
  Settings as SettingsIcon,
  Moon,
  Sun,
  LogOut,
  Bell,
  Shield,
  Palette,
  User,
} from 'lucide-react';

export default function SettingsPage() {
  const { user } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    navigate('/');
  };

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-50">Settings</h1>
        <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">Manage your account and preferences.</p>
      </div>

      {/* Appearance */}
      <Card className="p-6">
        <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold text-gray-900 dark:text-gray-100">
          <Palette size={20} className="text-primary-600 dark:text-primary-400" /> Appearance
        </h2>
        <div className="flex items-center justify-between rounded-lg border border-gray-200 px-4 py-3 dark:border-gray-800">
          <div className="flex items-center gap-3">
            {theme === 'light' ? <Sun size={20} className="text-gray-500" /> : <Moon size={20} className="text-gray-400" />}
            <div>
              <p className="font-medium text-gray-900 dark:text-gray-100">Theme</p>
              <p className="text-xs text-gray-500 dark:text-gray-400">
                Currently using {theme} mode
              </p>
            </div>
          </div>
          <button onClick={toggleTheme} className="btn-secondary btn-sm">
            Switch to {theme === 'light' ? 'dark' : 'light'}
          </button>
        </div>
      </Card>

      {/* Account */}
      <Card className="p-6">
        <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold text-gray-900 dark:text-gray-100">
          <User size={20} className="text-primary-600 dark:text-primary-400" /> Account
        </h2>
        <div className="space-y-3">
          <div className="flex items-center justify-between rounded-lg border border-gray-200 px-4 py-3 dark:border-gray-800">
            <div>
              <p className="font-medium text-gray-900 dark:text-gray-100">Email</p>
              <p className="text-xs text-gray-500 dark:text-gray-400">{user?.email}</p>
            </div>
          </div>
          <div className="flex items-center justify-between rounded-lg border border-gray-200 px-4 py-3 dark:border-gray-800">
            <div>
              <p className="font-medium text-gray-900 dark:text-gray-100">User ID</p>
              <p className="text-xs text-gray-400 dark:text-gray-500">{user?.id}</p>
            </div>
          </div>
        </div>
      </Card>

      {/* Danger zone */}
      <Card className="border-error-200 p-6 dark:border-error-800">
        <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold text-gray-900 dark:text-gray-100">
          <LogOut size={20} className="text-error-600" /> Session
        </h2>
        <button onClick={handleSignOut} className="btn-secondary btn-sm text-error-600 hover:bg-error-50 dark:text-error-400 dark:hover:bg-error-950/30">
          <LogOut size={16} /> Sign Out
        </button>
      </Card>
    </div>
  );
}
