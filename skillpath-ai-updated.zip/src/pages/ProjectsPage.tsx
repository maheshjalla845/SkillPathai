import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { Card, EmptyState, Skeleton, Spinner, ErrorBanner } from '@/components/ui';
import { generateProjects } from '@/lib/api/ai';
import type { Project, ProjectStatus, ProblemDifficulty } from '@/types';
import {
  FolderKanban,
  Plus,
  Sparkles,
  Check,
  Play,
  Trash2,
  Clock,
  Target,
  ChevronDown,
  ChevronRight,
  Code2,
  Lightbulb,
} from 'lucide-react';

export default function ProjectsPage() {
  const { user } = useAuth();
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;
    loadProjects(user.id);
  }, [user]);

  const loadProjects = async (userId: string) => {
    const { data } = await supabase
      .from('projects')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
    setProjects((data ?? []) as Project[]);
    setLoading(false);
  };

  const handleGenerate = async () => {
    if (!user) return;
    setGenerating(true);
    setError(null);

    try {
      const { data: profile } = await supabase
        .from('student_profiles')
        .select('career_goal, custom_career_goal')
        .eq('user_id', user.id)
        .maybeSingle();

      const { data: roadmap } = await supabase
        .from('roadmaps')
        .select('id')
        .eq('user_id', user.id)
        .maybeSingle();

      let completedSkills: string[] = [];
      let activeWeaknesses: string[] = [];

      if (roadmap) {
        const { data: topics } = await supabase
          .from('roadmap_topics')
          .select('topic_name, status')
          .eq('roadmap_id', roadmap.id)
          .eq('status', 'COMPLETED');
        completedSkills = (topics ?? []).map((t) => t.topic_name);
      }

      const { data: weaknesses } = await supabase
        .from('weaknesses')
        .select('topic')
        .eq('user_id', user.id)
        .in('status', ['active', 'recurring']);
      activeWeaknesses = (weaknesses ?? []).map((w) => w.topic);

      await generateProjects({
        career_goal: profile?.custom_career_goal || profile?.career_goal || 'Software Engineer',
        completed_skills: completedSkills,
        active_weaknesses: activeWeaknesses,
        existing_projects: projects.map((p) => p.title),
      });

      await loadProjects(user.id);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to generate projects';
      setError(msg);
    } finally {
      setGenerating(false);
    }
  };

  const updateStatus = async (id: string, status: ProjectStatus) => {
    const updates: Record<string, unknown> = { status };
    if (status === 'STARTED' || status === 'IN_PROGRESS') updates.started_at = new Date().toISOString();
    if (status === 'COMPLETED') updates.completed_at = new Date().toISOString();
    await supabase.from('projects').update(updates).eq('id', id);
    setProjects((prev) => prev.map((p) => p.id === id ? { ...p, status, started_at: status === 'STARTED' || status === 'IN_PROGRESS' ? new Date().toISOString() : p.started_at, completed_at: status === 'COMPLETED' ? new Date().toISOString() : p.completed_at } : p));
  };

  const deleteProject = async (id: string) => {
    await supabase.from('projects').delete().eq('id', id);
    setProjects((prev) => prev.filter((p) => p.id !== id));
  };

  if (loading) {
    return (
      <div className="mx-auto max-w-5xl space-y-6">
        <Skeleton className="h-16 w-full" />
        <Skeleton className="h-48 w-full" />
        <Skeleton className="h-48 w-full" />
      </div>
    );
  }

  const recommended = projects.filter((p) => p.status === 'RECOMMENDED');
  const inProgress = projects.filter((p) => p.status === 'STARTED' || p.status === 'IN_PROGRESS');
  const completed = projects.filter((p) => p.status === 'COMPLETED');

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-50">Projects</h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">AI-recommended projects matched to your skills and goals.</p>
        </div>
        <button onClick={handleGenerate} className="btn-primary btn-sm" disabled={generating}>
          {generating ? <Spinner size={16} /> : <Sparkles size={16} />} Get Recommendations
        </button>
      </div>

      {error && <ErrorBanner message={error} />}

      {projects.length === 0 && !generating ? (
        <Card className="p-8">
          <EmptyState
            icon={FolderKanban}
            title="No projects yet"
            description="Get AI-powered project recommendations based on your completed skills, weaknesses, and career goal."
            action={<button onClick={handleGenerate} className="btn-primary btn-sm"><Sparkles size={16} /> Get Recommendations</button>}
          />
        </Card>
      ) : (
        <>
          {inProgress.length > 0 && (
            <ProjectSection title="In Progress" projects={inProgress} expandedId={expandedId} onExpand={setExpandedId} onUpdateStatus={updateStatus} onDelete={deleteProject} />
          )}
          {recommended.length > 0 && (
            <ProjectSection title="Recommended" projects={recommended} expandedId={expandedId} onExpand={setExpandedId} onUpdateStatus={updateStatus} onDelete={deleteProject} />
          )}
          {completed.length > 0 && (
            <ProjectSection title="Completed" projects={completed} expandedId={expandedId} onExpand={setExpandedId} onUpdateStatus={updateStatus} onDelete={deleteProject} />
          )}
        </>
      )}
    </div>
  );
}

function ProjectSection({
  title,
  projects,
  expandedId,
  onExpand,
  onUpdateStatus,
  onDelete,
}: {
  title: string;
  projects: Project[];
  expandedId: string | null;
  onExpand: (id: string | null) => void;
  onUpdateStatus: (id: string, status: ProjectStatus) => void;
  onDelete: (id: string) => void;
}) {
  return (
    <div>
      <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">{title}</h2>
      <div className="space-y-3">
        {projects.map((p) => (
          <ProjectCard key={p.id} project={p} expanded={expandedId === p.id} onExpand={() => onExpand(expandedId === p.id ? null : p.id)} onUpdateStatus={onUpdateStatus} onDelete={onDelete} />
        ))}
      </div>
    </div>
  );
}

function ProjectCard({
  project,
  expanded,
  onExpand,
  onUpdateStatus,
  onDelete,
}: {
  project: Project;
  expanded: boolean;
  onExpand: () => void;
  onUpdateStatus: (id: string, status: ProjectStatus) => void;
  onDelete: (id: string) => void;
}) {
  const statusBadge = {
    RECOMMENDED: { label: 'Recommended', class: 'badge-neutral' },
    STARTED: { label: 'Started', class: 'badge-primary' },
    IN_PROGRESS: { label: 'In Progress', class: 'badge-primary' },
    COMPLETED: { label: 'Completed', class: 'badge-success' },
  };
  const diffClass = project.difficulty === 'Easy' ? 'badge-success' : project.difficulty === 'Medium' ? 'badge-warning' : 'badge-error';
  const sb = statusBadge[project.status];

  return (
    <Card className="overflow-hidden">
      <div className="p-5">
        <div className="flex items-start justify-between gap-4">
          <button onClick={onExpand} className="flex-1 text-left">
            <div className="flex items-center gap-2">
              {expanded ? <ChevronDown size={18} className="text-gray-400" /> : <ChevronRight size={18} className="text-gray-400" />}
              <h3 className="font-semibold text-gray-900 dark:text-gray-100">{project.title}</h3>
            </div>
            <p className="mt-1 ml-7 text-sm text-gray-500 dark:text-gray-400 line-clamp-2">{project.description}</p>
            <div className="mt-2 ml-7 flex flex-wrap items-center gap-2 text-xs">
              <span className={diffClass}>{project.difficulty}</span>
              <span className="badge-neutral">{project.estimated_duration}</span>
              <span className={sb.class}>{sb.label}</span>
            </div>
          </button>
          <button onClick={() => onDelete(project.id)} className="text-gray-400 hover:text-error-500">
            <Trash2 size={16} />
          </button>
        </div>
      </div>

      {expanded && (
        <div className="border-t border-gray-200 dark:border-gray-800">
          <div className="space-y-4 p-5">
            {project.required_skills.length > 0 && (
              <div>
                <p className="mb-1.5 flex items-center gap-1 text-xs font-semibold text-gray-700 dark:text-gray-300"><Target size={12} /> Required Skills</p>
                <div className="flex flex-wrap gap-1.5">
                  {project.required_skills.map((s, i) => <span key={i} className="rounded-md bg-gray-100 px-2 py-0.5 text-xs text-gray-600 dark:bg-gray-800 dark:text-gray-400">{s}</span>)}
                </div>
              </div>
            )}
            {project.features.length > 0 && (
              <div>
                <p className="mb-1.5 flex items-center gap-1 text-xs font-semibold text-gray-700 dark:text-gray-300"><Code2 size={12} /> Features to Build</p>
                <ul className="space-y-1 text-sm text-gray-600 dark:text-gray-400">
                  {project.features.map((f, i) => <li key={i} className="flex items-start gap-2"><ChevronRight size={14} className="mt-0.5 text-primary-600" /> {f}</li>)}
                </ul>
              </div>
            )}
            {project.learning_outcomes.length > 0 && (
              <div>
                <p className="mb-1.5 flex items-center gap-1 text-xs font-semibold text-gray-700 dark:text-gray-300"><Lightbulb size={12} /> Learning Outcomes</p>
                <ul className="space-y-1 text-sm text-gray-600 dark:text-gray-400">
                  {project.learning_outcomes.map((l, i) => <li key={i} className="flex items-start gap-2"><Check size={14} className="mt-0.5 text-success-600" /> {l}</li>)}
                </ul>
              </div>
            )}
            {project.completion_checklist.length > 0 && (
              <div>
                <p className="mb-1.5 flex items-center gap-1 text-xs font-semibold text-gray-700 dark:text-gray-300"><Check size={12} /> Completion Checklist</p>
                <ul className="space-y-1 text-sm text-gray-600 dark:text-gray-400">
                  {project.completion_checklist.map((c, i) => <li key={i} className="flex items-start gap-2"><div className="mt-0.5 h-3 w-3 rounded border border-gray-300 dark:border-gray-600" /> {c}</li>)}
                </ul>
              </div>
            )}
            <div className="flex gap-2 pt-2">
              {project.status === 'RECOMMENDED' && (
                <button onClick={() => onUpdateStatus(project.id, 'STARTED')} className="btn-primary btn-sm">
                  <Play size={14} /> Start Project
                </button>
              )}
              {(project.status === 'STARTED' || project.status === 'IN_PROGRESS') && (
                <>
                  <button onClick={() => onUpdateStatus(project.id, 'COMPLETED')} className="btn-primary btn-sm">
                    <Check size={14} /> Mark Complete
                  </button>
                </>
              )}
              {project.status === 'COMPLETED' && (
                <button onClick={() => onUpdateStatus(project.id, 'IN_PROGRESS')} className="btn-secondary btn-sm">
                  Reopen
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </Card>
  );
}
