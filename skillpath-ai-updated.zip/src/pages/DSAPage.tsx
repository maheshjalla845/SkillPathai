import { useEffect, useState, type FormEvent } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { Card, EmptyState, Skeleton, StatCard, ErrorBanner } from '@/components/ui';
import type { DSAProblem, ProblemDifficulty } from '@/types';
import {
  Code2,
  Plus,
  Trash2,
  Check,
  X,
  TrendingUp,
  Target,
  Clock,
  Flame,
} from 'lucide-react';

const dsaTopics = [
  'Arrays', 'Strings', 'Linked Lists', 'Stacks', 'Queues', 'Trees',
  'Binary Search', 'Hashing', 'Heaps', 'Graphs', 'Greedy', 'Dynamic Programming',
  'Backtracking', 'Bit Manipulation', 'Two Pointers', 'Sliding Window',
  'Recursion', 'Sorting', 'Math', 'Trie',
];

const platforms = ['LeetCode', 'HackerRank', 'Codeforces', 'CodeChef', 'AtCoder', 'GeeksforGeeks', 'Other'];
const difficulties: ProblemDifficulty[] = ['Easy', 'Medium', 'Hard'];

export default function DSAPage() {
  const { user } = useAuth();
  const [problems, setProblems] = useState<DSAProblem[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [filterTopic, setFilterTopic] = useState<string>('all');

  // Form state
  const [name, setName] = useState('');
  const [topic, setTopic] = useState('');
  const [difficulty, setDifficulty] = useState<ProblemDifficulty>('Easy');
  const [platform, setPlatform] = useState('LeetCode');
  const [solved, setSolved] = useState(false);
  const [timeSpent, setTimeSpent] = useState('');
  const [attempts, setAttempts] = useState('1');

  useEffect(() => {
    if (!user) return;
    loadProblems(user.id);
  }, [user]);

  const loadProblems = async (userId: string) => {
    const { data } = await supabase
      .from('dsa_problems')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
    setProblems((data ?? []) as DSAProblem[]);
    setLoading(false);
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!user || !name.trim() || !topic) return;
    setError(null);

    const { error: insertError } = await supabase.from('dsa_problems').insert({
      user_id: user.id,
      problem_name: name.trim(),
      topic,
      difficulty,
      platform,
      solved,
      time_spent_minutes: parseInt(timeSpent) || 0,
      attempts: parseInt(attempts) || 1,
    });

    if (insertError) {
      setError('Failed to save problem.');
      return;
    }

    setShowForm(false);
    setName(''); setTopic(''); setTimeSpent(''); setAttempts('1'); setSolved(false);
    await loadProblems(user.id);
  };

  const deleteProblem = async (id: string) => {
    await supabase.from('dsa_problems').delete().eq('id', id);
    setProblems((prev) => prev.filter((p) => p.id !== id));
  };

  const toggleSolved = async (problem: DSAProblem) => {
    const newSolved = !problem.solved;
    await supabase.from('dsa_problems').update({ solved: newSolved }).eq('id', problem.id);
    setProblems((prev) => prev.map((p) => p.id === problem.id ? { ...p, solved: newSolved } : p));
  };

  if (loading) {
    return (
      <div className="mx-auto max-w-5xl space-y-6">
        <Skeleton className="h-16 w-full" />
        <div className="grid gap-4 sm:grid-cols-4">
          {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-28 w-full" />)}
        </div>
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  const solvedCount = problems.filter((p) => p.solved).length;
  const attemptedCount = problems.length;
  const totalTime = problems.reduce((sum, p) => sum + p.time_spent_minutes, 0);
  const topicCounts = dsaTopics.map((t) => ({ topic: t, count: problems.filter((p) => p.topic === t && p.solved).length }))
    .filter((t) => t.count > 0).sort((a, b) => b.count - a.count);

  const filtered = filterTopic === 'all' ? problems : problems.filter((p) => p.topic === filterTopic);

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-50">DSA Practice</h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">Track your problem-solving progress.</p>
        </div>
        <button onClick={() => setShowForm(!showForm)} className="btn-primary btn-sm">
          <Plus size={16} /> Log Problem
        </button>
      </div>

      {/* Stats */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Solved" value={solvedCount} icon={Check} sublabel={`of ${attemptedCount} attempted`} />
        <StatCard label="Success Rate" value={attemptedCount > 0 ? `${Math.round((solvedCount / attemptedCount) * 100)}%` : '0%'} icon={Target} />
        <StatCard label="Time Spent" value={`${Math.round(totalTime / 60)}h`} icon={Clock} sublabel={`${totalTime} min total`} />
        <StatCard label="Topics Covered" value={topicCounts.length} icon={TrendingUp} />
      </div>

      {/* Form */}
      {showForm && (
        <Card className="p-6">
          <h2 className="mb-4 text-lg font-semibold text-gray-900 dark:text-gray-100">Log a Problem</h2>
          {error && <div className="mb-4"><ErrorBanner message={error} /></div>}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="label">Problem Name</label>
                <input value={name} onChange={(e) => setName(e.target.value)} className="input" placeholder="e.g., Two Sum" required />
              </div>
              <div>
                <label className="label">Topic</label>
                <select value={topic} onChange={(e) => setTopic(e.target.value)} className="input" required>
                  <option value="">Select topic</option>
                  {dsaTopics.map((t) => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
              <div>
                <label className="label">Difficulty</label>
                <select value={difficulty} onChange={(e) => setDifficulty(e.target.value as ProblemDifficulty)} className="input">
                  {difficulties.map((d) => <option key={d} value={d}>{d}</option>)}
                </select>
              </div>
              <div>
                <label className="label">Platform</label>
                <select value={platform} onChange={(e) => setPlatform(e.target.value)} className="input">
                  {platforms.map((p) => <option key={p} value={p}>{p}</option>)}
                </select>
              </div>
              <div>
                <label className="label">Time Spent (minutes)</label>
                <input type="number" value={timeSpent} onChange={(e) => setTimeSpent(e.target.value)} className="input" placeholder="0" />
              </div>
              <div>
                <label className="label">Attempts</label>
                <input type="number" value={attempts} onChange={(e) => setAttempts(e.target.value)} className="input" placeholder="1" />
              </div>
            </div>
            <label className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300">
              <input type="checkbox" checked={solved} onChange={(e) => setSolved(e.target.checked)} className="h-4 w-4 rounded border-gray-300 text-primary-600" />
              Solved
            </label>
            <div className="flex gap-2">
              <button type="submit" className="btn-primary btn-sm">Save Problem</button>
              <button type="button" onClick={() => setShowForm(false)} className="btn-secondary btn-sm">Cancel</button>
            </div>
          </form>
        </Card>
      )}

      {/* Topic filter */}
      {problems.length > 0 && (
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setFilterTopic('all')}
            className={`rounded-lg px-3 py-1.5 text-xs font-medium ${filterTopic === 'all' ? 'bg-primary-600 text-white' : 'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400'}`}
          >
            All Topics
          </button>
          {dsaTopics.filter((t) => problems.some((p) => p.topic === t)).map((t) => (
            <button
              key={t}
              onClick={() => setFilterTopic(t)}
              className={`rounded-lg px-3 py-1.5 text-xs font-medium ${filterTopic === t ? 'bg-primary-600 text-white' : 'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400'}`}
            >
              {t}
            </button>
          ))}
        </div>
      )}

      {/* Problem list */}
      {problems.length === 0 ? (
        <Card className="p-8">
          <EmptyState
            icon={Code2}
            title="No problems logged yet"
            description="Start tracking your DSA practice by logging problems you solve."
            action={<button onClick={() => setShowForm(true)} className="btn-primary btn-sm"><Plus size={16} /> Log First Problem</button>}
          />
        </Card>
      ) : (
        <div className="space-y-2">
          {filtered.map((p) => (
            <Card key={p.id} className="p-4">
              <div className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-3 flex-1 min-w-0">
                  <button
                    onClick={() => toggleSolved(p)}
                    className={`flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full border-2 transition-colors ${
                      p.solved ? 'border-success-500 bg-success-500' : 'border-gray-300 dark:border-gray-600 hover:border-success-400'
                    }`}
                  >
                    {p.solved && <Check size={14} className="text-white" />}
                  </button>
                  <div className="flex-1 min-w-0">
                    <h3 className={`font-medium truncate ${p.solved ? 'text-gray-500 line-through dark:text-gray-500' : 'text-gray-900 dark:text-gray-100'}`}>
                      {p.problem_name}
                    </h3>
                    <div className="mt-0.5 flex flex-wrap items-center gap-2 text-xs text-gray-400 dark:text-gray-500">
                      <span className="badge-neutral">{p.topic}</span>
                      <span className={p.difficulty === 'Easy' ? 'badge-success' : p.difficulty === 'Medium' ? 'badge-warning' : 'badge-error'}>{p.difficulty}</span>
                      <span>{p.platform}</span>
                      {p.time_spent_minutes > 0 && <span>· {p.time_spent_minutes}m</span>}
                      {p.attempts > 1 && <span>· {p.attempts} attempts</span>}
                    </div>
                  </div>
                </div>
                <button onClick={() => deleteProblem(p.id)} className="text-gray-400 hover:text-error-500">
                  <Trash2 size={16} />
                </button>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
