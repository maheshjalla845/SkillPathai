import { type ReactNode } from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { FullPageLoader } from '@/components/ui';

export function ProtectedRoute({
  children,
  requireOnboarding = false,
  requireRoadmap = false,
}: {
  children: ReactNode;
  requireOnboarding?: boolean;
  requireRoadmap?: boolean;
}) {
  const { user, loading } = useAuth();

  if (loading) return <FullPageLoader message="Checking your session..." />;
  if (!user) return <Navigate to="/login" replace />;

  return <>{children}</>;
}
