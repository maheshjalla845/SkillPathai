import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import type { StudentProfile } from '@/types';

export function useProfile() {
  const [profile, setProfile] = useState<StudentProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProfile = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        setLoading(false);
        return;
      }

      const { data } = await supabase
        .from('student_profiles')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      setProfile(data as StudentProfile | null);
      setLoading(false);
    };

    fetchProfile();
  }, []);

  return { profile, loading, setProfile };
}
