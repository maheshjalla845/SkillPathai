-- ============================================================
-- SkillPath AI — Full Project Transfer Script
-- ============================================================
-- This file contains EVERYTHING needed to move the project to
-- a new Supabase instance:
--   1. All 15 database tables with constraints
--   2. All RLS policies (50+)
--   3. All 16 indexes
--   4. All 7 Edge Function source codes (as SQL comments —
--      see instructions at the bottom for deploying them)
--
-- HOW TO USE:
--   Step 1: Run this entire SQL script in the Supabase SQL Editor
--           of your NEW project.
--   Step 2: Copy each Edge Function's TypeScript code (from the
--           comments at the bottom of this file) into files under
--           supabase/functions/<slug>/index.ts and deploy them.
--   Step 3: Set the GROQ_API_KEY secret on the new project.
--   Step 4: Update your .env with the new project's URL and keys.
--
-- This script is idempotent — safe to run multiple times.
-- It does NOT copy user data. Users sign up fresh on the new DB.
-- ============================================================

-- Required extension for gen_random_uuid()
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ============================================================
-- TABLES
-- ============================================================

-- Student profiles
CREATE TABLE IF NOT EXISTS student_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL UNIQUE DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text,
  education text,
  college text,
  year text,
  experience text,
  career_goal text,
  custom_career_goal text,
  academic_background text,
  study_time_per_day text,
  learning_preference text,
  onboarding_completed boolean NOT NULL DEFAULT false,
  diagnostic_completed boolean NOT NULL DEFAULT false,
  roadmap_generated boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Student skills
CREATE TABLE IF NOT EXISTS student_skills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  skill_name text NOT NULL,
  level text NOT NULL DEFAULT 'Beginner',
  verified_proficiency integer,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, skill_name)
);

-- Roadmaps
CREATE TABLE IF NOT EXISTS roadmaps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  career_goal text NOT NULL,
  generated_at timestamptz NOT NULL DEFAULT now()
);

-- Roadmap phases
CREATE TABLE IF NOT EXISTS roadmap_phases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  roadmap_id uuid NOT NULL REFERENCES roadmaps(id) ON DELETE CASCADE,
  phase_number integer NOT NULL,
  title text NOT NULL,
  description text
);

-- Roadmap topics
CREATE TABLE IF NOT EXISTS roadmap_topics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  roadmap_id uuid NOT NULL REFERENCES roadmaps(id) ON DELETE CASCADE,
  phase_id uuid NOT NULL REFERENCES roadmap_phases(id) ON DELETE CASCADE,
  topic_name text NOT NULL,
  description text,
  order_index integer NOT NULL DEFAULT 0,
  priority text NOT NULL DEFAULT 'medium',
  estimated_hours numeric NOT NULL DEFAULT 0,
  target_proficiency integer NOT NULL DEFAULT 80,
  prerequisites text[] NOT NULL DEFAULT '{}',
  resources text[] NOT NULL DEFAULT '{}',
  practice text[] NOT NULL DEFAULT '{}',
  subtopics text[] NOT NULL DEFAULT '{}',
  status text NOT NULL DEFAULT 'NOT_STARTED',
  current_proficiency integer NOT NULL DEFAULT 0,
  started_at timestamptz,
  completed_at timestamptz
);

-- Assessments
CREATE TABLE IF NOT EXISTS assessments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  type text NOT NULL DEFAULT 'topic',
  topic_name text,
  total_questions integer NOT NULL DEFAULT 0,
  score integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Assessment questions
CREATE TABLE IF NOT EXISTS assessment_questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  assessment_id uuid NOT NULL REFERENCES assessments(id) ON DELETE CASCADE,
  question_text text NOT NULL,
  question_type text NOT NULL DEFAULT 'mcq',
  topic text NOT NULL,
  subtopic text,
  difficulty text NOT NULL DEFAULT 'medium',
  options text[],
  correct_answer text NOT NULL,
  selected_answer text,
  is_correct boolean,
  time_taken_seconds integer
);

-- Weaknesses
CREATE TABLE IF NOT EXISTS weaknesses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  topic text NOT NULL,
  subtopic text,
  priority text NOT NULL DEFAULT 'MEDIUM',
  status text NOT NULL DEFAULT 'active',
  score integer NOT NULL DEFAULT 0,
  explanation text NOT NULL DEFAULT '',
  recommended_actions text[] NOT NULL DEFAULT '{}',
  detected_at timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz
);

-- Weakness history
CREATE TABLE IF NOT EXISTS weakness_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  weakness_id uuid NOT NULL REFERENCES weaknesses(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  topic text NOT NULL,
  subtopic text,
  score integer NOT NULL DEFAULT 0,
  assessed_at timestamptz NOT NULL DEFAULT now()
);

-- Study sessions
CREATE TABLE IF NOT EXISTS study_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  topic_name text NOT NULL,
  duration_minutes integer NOT NULL DEFAULT 0,
  activity_type text NOT NULL DEFAULT 'learning',
  created_at timestamptz NOT NULL DEFAULT now()
);

-- DSA problems
CREATE TABLE IF NOT EXISTS dsa_problems (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  problem_name text NOT NULL,
  topic text NOT NULL,
  difficulty text NOT NULL DEFAULT 'Easy',
  platform text NOT NULL DEFAULT 'Manual',
  attempts integer NOT NULL DEFAULT 1,
  time_spent_minutes integer NOT NULL DEFAULT 0,
  solved boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Contests (shared public catalog — not user-owned)
CREATE TABLE IF NOT EXISTS contests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  platform text NOT NULL,
  start_time timestamptz NOT NULL,
  duration_seconds integer NOT NULL DEFAULT 7200,
  url text NOT NULL DEFAULT '',
  difficulty text
);

-- Contest participations (user-owned)
CREATE TABLE IF NOT EXISTS contest_participations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  contest_id uuid REFERENCES contests(id) ON DELETE SET NULL,
  contest_name text,
  platform text,
  problems_attempted integer NOT NULL DEFAULT 0,
  problems_solved integer NOT NULL DEFAULT 0,
  time_taken_minutes integer NOT NULL DEFAULT 0,
  wrong_submissions integer NOT NULL DEFAULT 0,
  rating integer,
  participated_at timestamptz NOT NULL DEFAULT now()
);

-- Projects (user-owned — recommendations and progress)
CREATE TABLE IF NOT EXISTS projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text NOT NULL DEFAULT '',
  difficulty text NOT NULL DEFAULT 'Medium',
  estimated_duration text NOT NULL DEFAULT '1-2 weeks',
  required_skills text[] NOT NULL DEFAULT '{}',
  features text[] NOT NULL DEFAULT '{}',
  learning_outcomes text[] NOT NULL DEFAULT '{}',
  completion_checklist text[] NOT NULL DEFAULT '{}',
  status text NOT NULL DEFAULT 'RECOMMENDED',
  started_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Study plans (AI-generated daily plans)
CREATE TABLE IF NOT EXISTS study_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  plan_date date NOT NULL DEFAULT CURRENT_DATE,
  available_minutes integer NOT NULL DEFAULT 120,
  plan_content jsonb NOT NULL DEFAULT '[]',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, plan_date)
);

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================

ALTER TABLE student_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE student_skills ENABLE ROW LEVEL SECURITY;
ALTER TABLE roadmaps ENABLE ROW LEVEL SECURITY;
ALTER TABLE roadmap_phases ENABLE ROW LEVEL SECURITY;
ALTER TABLE roadmap_topics ENABLE ROW LEVEL SECURITY;
ALTER TABLE assessments ENABLE ROW LEVEL SECURITY;
ALTER TABLE assessment_questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE weaknesses ENABLE ROW LEVEL SECURITY;
ALTER TABLE weakness_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE study_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE dsa_problems ENABLE ROW LEVEL SECURITY;
ALTER TABLE contests ENABLE ROW LEVEL SECURITY;
ALTER TABLE contest_participations ENABLE ROW LEVEL SECURITY;
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE study_plans ENABLE ROW LEVEL SECURITY;

-- ============================================================
-- RLS POLICIES
-- ============================================================

-- student_profiles
DROP POLICY IF EXISTS "select_own_profile" ON student_profiles;
CREATE POLICY "select_own_profile" ON student_profiles FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_profile" ON student_profiles;
CREATE POLICY "insert_own_profile" ON student_profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_profile" ON student_profiles;
CREATE POLICY "update_own_profile" ON student_profiles FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- student_skills
DROP POLICY IF EXISTS "select_own_skills" ON student_skills;
CREATE POLICY "select_own_skills" ON student_skills FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_skills" ON student_skills;
CREATE POLICY "insert_own_skills" ON student_skills FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_skills" ON student_skills;
CREATE POLICY "update_own_skills" ON student_skills FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_skills" ON student_skills;
CREATE POLICY "delete_own_skills" ON student_skills FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- roadmaps
DROP POLICY IF EXISTS "select_own_roadmaps" ON roadmaps;
CREATE POLICY "select_own_roadmaps" ON roadmaps FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_roadmaps" ON roadmaps;
CREATE POLICY "insert_own_roadmaps" ON roadmaps FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_roadmaps" ON roadmaps;
CREATE POLICY "delete_own_roadmaps" ON roadmaps FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- roadmap_phases
DROP POLICY IF EXISTS "select_own_phases" ON roadmap_phases;
CREATE POLICY "select_own_phases" ON roadmap_phases FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM roadmaps WHERE roadmaps.id = roadmap_phases.roadmap_id AND roadmaps.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "insert_own_phases" ON roadmap_phases;
CREATE POLICY "insert_own_phases" ON roadmap_phases FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM roadmaps WHERE roadmaps.id = roadmap_phases.roadmap_id AND roadmaps.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "delete_own_phases" ON roadmap_phases;
CREATE POLICY "delete_own_phases" ON roadmap_phases FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM roadmaps WHERE roadmaps.id = roadmap_phases.roadmap_id AND roadmaps.user_id = auth.uid())
  );

-- roadmap_topics
DROP POLICY IF EXISTS "select_own_topics" ON roadmap_topics;
CREATE POLICY "select_own_topics" ON roadmap_topics FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM roadmaps WHERE roadmaps.id = roadmap_topics.roadmap_id AND roadmaps.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "insert_own_topics" ON roadmap_topics;
CREATE POLICY "insert_own_topics" ON roadmap_topics FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM roadmaps WHERE roadmaps.id = roadmap_topics.roadmap_id AND roadmaps.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "update_own_topics" ON roadmap_topics;
CREATE POLICY "update_own_topics" ON roadmap_topics FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM roadmaps WHERE roadmaps.id = roadmap_topics.roadmap_id AND roadmaps.user_id = auth.uid())
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM roadmaps WHERE roadmaps.id = roadmap_topics.roadmap_id AND roadmaps.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "delete_own_topics" ON roadmap_topics;
CREATE POLICY "delete_own_topics" ON roadmap_topics FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM roadmaps WHERE roadmaps.id = roadmap_topics.roadmap_id AND roadmaps.user_id = auth.uid())
  );

-- assessments
DROP POLICY IF EXISTS "select_own_assessments" ON assessments;
CREATE POLICY "select_own_assessments" ON assessments FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_assessments" ON assessments;
CREATE POLICY "insert_own_assessments" ON assessments FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_assessments" ON assessments;
CREATE POLICY "delete_own_assessments" ON assessments FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- assessment_questions
DROP POLICY IF EXISTS "select_own_questions" ON assessment_questions;
CREATE POLICY "select_own_questions" ON assessment_questions FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM assessments WHERE assessments.id = assessment_questions.assessment_id AND assessments.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "insert_own_questions" ON assessment_questions;
CREATE POLICY "insert_own_questions" ON assessment_questions FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM assessments WHERE assessments.id = assessment_questions.assessment_id AND assessments.user_id = auth.uid())
  );

-- weaknesses
DROP POLICY IF EXISTS "select_own_weaknesses" ON weaknesses;
CREATE POLICY "select_own_weaknesses" ON weaknesses FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_weaknesses" ON weaknesses;
CREATE POLICY "insert_own_weaknesses" ON weaknesses FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_weaknesses" ON weaknesses;
CREATE POLICY "update_own_weaknesses" ON weaknesses FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_weaknesses" ON weaknesses;
CREATE POLICY "delete_own_weaknesses" ON weaknesses FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- weakness_history
DROP POLICY IF EXISTS "select_own_weakness_history" ON weakness_history;
CREATE POLICY "select_own_weakness_history" ON weakness_history FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_weakness_history" ON weakness_history;
CREATE POLICY "insert_own_weakness_history" ON weakness_history FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

-- study_sessions
DROP POLICY IF EXISTS "select_own_sessions" ON study_sessions;
CREATE POLICY "select_own_sessions" ON study_sessions FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_sessions" ON study_sessions;
CREATE POLICY "insert_own_sessions" ON study_sessions FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_sessions" ON study_sessions;
CREATE POLICY "delete_own_sessions" ON study_sessions FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- dsa_problems
DROP POLICY IF EXISTS "select_own_dsa" ON dsa_problems;
CREATE POLICY "select_own_dsa" ON dsa_problems FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_dsa" ON dsa_problems;
CREATE POLICY "insert_own_dsa" ON dsa_problems FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_dsa" ON dsa_problems;
CREATE POLICY "update_own_dsa" ON dsa_problems FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_dsa" ON dsa_problems;
CREATE POLICY "delete_own_dsa" ON dsa_problems FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- contests (publicly readable — shared catalog)
DROP POLICY IF EXISTS "select_contests" ON contests;
CREATE POLICY "select_contests" ON contests FOR SELECT
  TO anon, authenticated USING (true);

-- contest_participations
DROP POLICY IF EXISTS "select_own_participations" ON contest_participations;
CREATE POLICY "select_own_participations" ON contest_participations FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_participations" ON contest_participations;
CREATE POLICY "insert_own_participations" ON contest_participations FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_participations" ON contest_participations;
CREATE POLICY "update_own_participations" ON contest_participations FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_participations" ON contest_participations;
CREATE POLICY "delete_own_participations" ON contest_participations FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- projects
DROP POLICY IF EXISTS "select_own_projects" ON projects;
CREATE POLICY "select_own_projects" ON projects FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_projects" ON projects;
CREATE POLICY "insert_own_projects" ON projects FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_projects" ON projects;
CREATE POLICY "update_own_projects" ON projects FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_projects" ON projects;
CREATE POLICY "delete_own_projects" ON projects FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- study_plans
DROP POLICY IF EXISTS "select_own_plans" ON study_plans;
CREATE POLICY "select_own_plans" ON study_plans FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_plans" ON study_plans;
CREATE POLICY "insert_own_plans" ON study_plans FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_plans" ON study_plans;
CREATE POLICY "update_own_plans" ON study_plans FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_plans" ON study_plans;
CREATE POLICY "delete_own_plans" ON study_plans FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ============================================================
-- INDEXES
-- ============================================================

CREATE INDEX IF NOT EXISTS idx_student_profiles_user_id ON student_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_student_skills_user_id ON student_skills(user_id);
CREATE INDEX IF NOT EXISTS idx_roadmaps_user_id ON roadmaps(user_id);
CREATE INDEX IF NOT EXISTS idx_roadmap_topics_roadmap_id ON roadmap_topics(roadmap_id);
CREATE INDEX IF NOT EXISTS idx_roadmap_topics_status ON roadmap_topics(status);
CREATE INDEX IF NOT EXISTS idx_assessments_user_id ON assessments(user_id);
CREATE INDEX IF NOT EXISTS idx_assessment_questions_assessment_id ON assessment_questions(assessment_id);
CREATE INDEX IF NOT EXISTS idx_weaknesses_user_id ON weaknesses(user_id);
CREATE INDEX IF NOT EXISTS idx_weaknesses_status ON weaknesses(status);
CREATE INDEX IF NOT EXISTS idx_weakness_history_user_id ON weakness_history(user_id);
CREATE INDEX IF NOT EXISTS idx_study_sessions_user_id ON study_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_dsa_problems_user_id ON dsa_problems(user_id);
CREATE INDEX IF NOT EXISTS idx_contest_participations_user_id ON contest_participations(user_id);
CREATE INDEX IF NOT EXISTS idx_projects_user_id ON projects(user_id);
CREATE INDEX IF NOT EXISTS idx_study_plans_user_id ON study_plans(user_id);
CREATE INDEX IF NOT EXISTS idx_contests_start_time ON contests(start_time);

-- ============================================================
-- ============================================================
-- EDGE FUNCTIONS (TypeScript source code)
-- ============================================================
-- ============================================================
-- Edge Functions are TypeScript files that run on Supabase's
-- Deno runtime. They CANNOT be created by running SQL.
--
-- To deploy them on your new project, the function source files
-- must already exist under supabase/functions/<slug>/index.ts
-- in your project directory. They are already there — the files
-- are part of this codebase. After running the SQL above, just
-- redeploy using your deployment tool or the Supabase MCP
-- deploy_edge_functions tool.
--
-- You also need to set the GROQ_API_KEY secret on the new project
-- so the functions can call the Groq AI API.
--
-- The 7 Edge Functions are:
--   1. ai-assessment  — generates diagnostic & topic assessment questions
--   2. ai-roadmap     — creates personalized learning roadmap
--   3. ai-weakness    — analyzes assessment results for weaknesses
--   4. ai-study-plan  — generates daily study plan
--   5. ai-mentor      — AI chat mentor for student questions
--   6. ai-projects    — recommends projects based on skill level
--   7. ai-career      — career readiness analysis
--
-- All use the Groq API (openai/gpt-oss-20b model) via the OpenAI SDK
-- with baseURL https://api.groq.com/openai/v1
--
-- The supabase/config.toml entries for all 7 functions:
--   [functions.ai-assessment]
--   verify_jwt = true
--   [functions.ai-roadmap]
--   verify_jwt = true
--   [functions.ai-weakness]
--   verify_jwt = true
--   [functions.ai-study-plan]
--   verify_jwt = true
--   [functions.ai-mentor]
--   verify_jwt = true
--   [functions.ai-projects]
--   verify_jwt = true
--   [functions.ai-career]
--   verify_jwt = true
--
-- ============================================================
-- 1. ai-assessment/index.ts
-- ============================================================
/*
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import OpenAI from "https://esm.sh/openai@4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface QuestionPayload {
  question_text: string;
  question_type: string;
  topic: string;
  subtopic: string;
  difficulty: string;
  options: string[] | null;
  correct_answer: string;
}

interface RequestBody {
  assessment_type: "diagnostic" | "topic";
  career_goal: string;
  skills: { skill_name: string; level: string }[];
  topic_name?: string;
  groq_api_key?: string;
}

function buildPrompt(body: RequestBody): string {
  const skillsList = body.skills.length > 0
    ? body.skills.map((s) => `${s.skill_name} (${s.level})`).join(", ")
    : "No skills reported";

  if (body.assessment_type === "diagnostic") {
    return `You are an expert technical interviewer and educator creating a diagnostic assessment.

STUDENT PROFILE:
- Career goal: ${body.career_goal}
- Self-reported skills: ${skillsList}

TASK: Generate exactly 10 diagnostic questions that span multiple question types and difficulty levels. These questions must:
1. Test the student's ACTUAL knowledge across their reported skills
2. Include a mix of: mcq, code_output, debugging, conceptual, scenario
3. Include a mix of difficulty: easy, medium, hard
4. For each skill the student claims, include at least one question
5. If the student reports no skills, test fundamental CS concepts (data structures, algorithms, programming basics)

Return a JSON array of exactly 10 question objects. Each object MUST have:
- "question_text": string (the question)
- "question_type": one of "mcq", "code_output", "debugging", "conceptual", "scenario"
- "topic": string (the skill/subject being tested, e.g. "Python", "DSA", "SQL")
- "subtopic": string (specific area, e.g. "loops", "binary search", "joins")
- "difficulty": one of "easy", "medium", "hard"
- "options": string[] | null (4 options for mcq, null for others)
- "correct_answer": string (the correct option for mcq, or the correct answer/explanation for others)

IMPORTANT: Return ONLY the JSON array, no markdown, no explanation.`;
  }

  return `You are an expert technical interviewer creating a topic assessment.

TOPIC: ${body.topic_name}
STUDENT CAREER GOAL: ${body.career_goal}
STUDENT SKILLS: ${skillsList}

TASK: Generate exactly 8 questions assessing the student's knowledge of "${body.topic_name}". These questions must:
1. Cover different subtopics within "${body.topic_name}"
2. Include a mix of: mcq, code_output, debugging, conceptual, scenario, practical
3. Include a mix of difficulty: easy, medium, hard
4. Test both conceptual understanding and practical application

Return a JSON array of exactly 8 question objects. Each object MUST have:
- "question_text": string
- "question_type": one of "mcq", "code_output", "debugging", "conceptual", "scenario", "practical"
- "topic": "${body.topic_name}"
- "subtopic": string
- "difficulty": one of "easy", "medium", "hard"
- "options": string[] | null (4 options for mcq, null for others)
- "correct_answer": string

IMPORTANT: Return ONLY the JSON array, no markdown, no explanation.`;
}

async function callGroq(prompt: string, apiKeyFromClient?: string): Promise<QuestionPayload[]> {
  const apiKey = Deno.env.get("GROQ_API_KEY") || apiKeyFromClient;
  if (!apiKey) throw new Error("GROQ_API_KEY not configured");

  const client = new OpenAI({
    apiKey,
    baseURL: "https://api.groq.com/openai/v1",
  });

  const completion = await client.chat.completions.create({
    model: "openai/gpt-oss-20b",
    messages: [{ role: "user", content: prompt }],
    temperature: 0.7,
    max_tokens: 8192,
    response_format: { type: "json_object" },
  });

  const text = completion.choices[0]?.message?.content;
  if (!text) throw new Error("Empty response from Groq");

  let parsed: QuestionPayload[];
  try {
    const obj = JSON.parse(text);
    parsed = Array.isArray(obj) ? obj : obj.questions || obj.data || [];
  } catch {
    const jsonMatch = text.match(/\[[\s\S]*\]/);
    if (!jsonMatch) throw new Error("Could not parse JSON from Groq response");
    parsed = JSON.parse(jsonMatch[0]);
  }

  if (!Array.isArray(parsed) || parsed.length === 0) {
    throw new Error("Groq returned no questions");
  }

  return parsed;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing authorization" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Invalid token" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body: RequestBody = await req.json();
    if (!body.assessment_type || !body.career_goal) {
      return new Response(JSON.stringify({ error: "Missing required fields" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const prompt = buildPrompt(body);
    const questions = await callGroq(prompt, body.groq_api_key);

    return new Response(JSON.stringify({ questions }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
*/

-- ============================================================
-- 2. ai-roadmap/index.ts
-- ============================================================
/*
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import OpenAI from "https://esm.sh/openai@4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface DiagnosticResult {
  topic: string;
  subtopic: string;
  is_correct: boolean;
  difficulty: string;
}

interface RequestBody {
  career_goal: string;
  skills: { skill_name: string; level: string }[];
  diagnostic_results: DiagnosticResult[];
  study_time_per_day: string;
  learning_preference: string;
  groq_api_key?: string;
}

interface RoadmapPhaseAI {
  phase_number: number;
  title: string;
  description: string;
  topics: RoadmapTopicAI[];
}

interface RoadmapTopicAI {
  topic_name: string;
  description: string;
  priority: "high" | "medium" | "low";
  estimated_hours: number;
  target_proficiency: number;
  prerequisites: string[];
  resources: string[];
  practice: string[];
  subtopics: string[];
}

function buildPrompt(body: RequestBody): string {
  const skillsList = body.skills.length > 0
    ? body.skills.map((s) => `${s.skill_name} (${s.level})`).join(", ")
    : "No prior skills";

  const diagnosticSummary = body.diagnostic_results.length > 0
    ? body.diagnostic_results.map((d) => `${d.topic}/${d.subtopic}: ${d.is_correct ? "correct" : "incorrect"} (${d.difficulty})`).join("; ")
    : "No diagnostic data";

  return `You are an expert career mentor and technical educator creating a personalized learning roadmap.

STUDENT PROFILE:
- Career goal: ${body.career_goal}
- Self-reported skills: ${skillsList}
- Diagnostic results: ${diagnosticSummary}
- Available study time: ${body.study_time_per_day}
- Learning preference: ${body.learning_preference}

TASK: Create a comprehensive learning roadmap with 4-6 phases. Each phase builds on the previous one. The roadmap should:
1. Start with fundamentals the student is weak in (based on diagnostic results)
2. Progress to intermediate and advanced topics
3. Be specifically tailored to the career goal: "${body.career_goal}"
4. Include practical projects and DSA practice throughout
5. Account for the student's study time availability

Return a JSON object with this exact structure:
{
  "phases": [
    {
      "phase_number": 1,
      "title": "Phase title",
      "description": "What this phase covers and why",
      "topics": [
        {
          "topic_name": "Topic name",
          "description": "What this topic covers",
          "priority": "high" | "medium" | "low",
          "estimated_hours": 10,
          "target_proficiency": 80,
          "prerequisites": ["prerequisite topic names"],
          "resources": ["resource URL or description"],
          "practice": ["practice problem or exercise description"],
          "subtopics": ["subtopic 1", "subtopic 2"]
        }
      ]
    }
  ]
}

Rules:
- Include 4-6 phases
- Each phase should have 3-6 topics
- Topics within a phase should be ordered by prerequisites
- Include real, specific resource names (e.g., "GeeksforGeeks: Binary Search", "freeCodeCamp: React Tutorial")
- Include specific practice problems (e.g., "LeetCode #704 Binary Search", "Implement a hash map from scratch")
- estimated_hours should be realistic for the topic depth
- target_proficiency is the level the student should reach (usually 70-90)

IMPORTANT: Return ONLY the JSON object, no markdown, no explanation.`;
}

async function callGroq(prompt: string, apiKeyFromClient?: string): Promise<{ phases: RoadmapPhaseAI[] }> {
  const apiKey = Deno.env.get("GROQ_API_KEY") || apiKeyFromClient;
  if (!apiKey) throw new Error("GROQ_API_KEY not configured");

  const client = new OpenAI({
    apiKey,
    baseURL: "https://api.groq.com/openai/v1",
  });

  const completion = await client.chat.completions.create({
    model: "openai/gpt-oss-20b",
    messages: [{ role: "user", content: prompt }],
    temperature: 0.7,
    max_tokens: 8192,
    response_format: { type: "json_object" },
  });

  const text = completion.choices[0]?.message?.content;
  if (!text) throw new Error("Empty response from Groq");

  let parsed: { phases: RoadmapPhaseAI[] };
  try {
    parsed = JSON.parse(text);
  } catch {
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error("Could not parse JSON from Groq response");
    parsed = JSON.parse(jsonMatch[0]);
  }

  if (!parsed.phases || !Array.isArray(parsed.phases) || parsed.phases.length === 0) {
    throw new Error("Groq returned no roadmap phases");
  }

  return parsed;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing authorization" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Invalid token" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body: RequestBody = await req.json();
    if (!body.career_goal) {
      return new Response(JSON.stringify({ error: "Missing career goal" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const prompt = buildPrompt(body);
    const result = await callGroq(prompt, body.groq_api_key);

    // Save roadmap to database
    await supabase.from("roadmaps").delete().eq("user_id", user.id);

    const { data: roadmap, error: roadmapError } = await supabase
      .from("roadmaps")
      .insert({ user_id: user.id, career_goal: body.career_goal })
      .select()
      .single();

    if (roadmapError || !roadmap) {
      throw new Error("Failed to create roadmap record");
    }

    let globalOrder = 0;
    for (const phase of result.phases) {
      const { data: phaseRow, error: phaseError } = await supabase
        .from("roadmap_phases")
        .insert({
          roadmap_id: roadmap.id,
          phase_number: phase.phase_number,
          title: phase.title,
          description: phase.description,
        })
        .select()
        .single();

      if (phaseError || !phaseRow) {
        throw new Error(`Failed to create phase ${phase.phase_number}`);
      }

      const topicInserts = phase.topics.map((t) => ({
        roadmap_id: roadmap.id,
        phase_id: phaseRow.id,
        topic_name: t.topic_name,
        description: t.description,
        order_index: globalOrder++,
        priority: t.priority,
        estimated_hours: t.estimated_hours,
        target_proficiency: t.target_proficiency,
        prerequisites: t.prerequisites || [],
        resources: t.resources || [],
        practice: t.practice || [],
        subtopics: t.subtopics || [],
        status: "NOT_STARTED",
        current_proficiency: 0,
      }));

      const { error: topicError } = await supabase.from("roadmap_topics").insert(topicInserts);
      if (topicError) {
        throw new Error(`Failed to create topics for phase ${phase.phase_number}: ${topicError.message}`);
      }
    }

    await supabase
      .from("student_profiles")
      .update({ roadmap_generated: true })
      .eq("user_id", user.id);

    return new Response(JSON.stringify({ roadmap_id: roadmap.id, phases: result.phases }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
*/

-- ============================================================
-- 3. ai-weakness/index.ts
-- ============================================================
/*
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import OpenAI from "https://esm.sh/openai@4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface QuestionResult {
  topic: string;
  subtopic: string;
  is_correct: boolean;
  difficulty: string;
  question_text: string;
  selected_answer: string;
  correct_answer: string;
}

interface RequestBody {
  assessment_id: string;
  questions: QuestionResult[];
  groq_api_key?: string;
}

interface WeaknessAI {
  topic: string;
  subtopic: string;
  priority: "HIGH" | "MEDIUM" | "LOW";
  explanation: string;
  recommended_actions: string[];
}

function buildPrompt(questions: QuestionResult[]): string {
  const wrongAnswers = questions.filter((q) => !q.is_correct);
  const correctCount = questions.length - wrongAnswers.length;

  const questionDetails = questions.map((q) => ({
    topic: q.topic,
    subtopic: q.subtopic,
    correct: q.is_correct,
    difficulty: q.difficulty,
    question: q.question_text,
    student_answer: q.selected_answer || "(no answer)",
    correct_answer: q.correct_answer,
  }));

  return `You are an expert educator analyzing assessment results to identify learning weaknesses.

ASSESSMENT RESULTS:
- Total questions: ${questions.length}
- Correct answers: ${correctCount}
- Wrong answers: ${wrongAnswers.length}

QUESTION DETAILS (JSON):
${JSON.stringify(questionDetails, null, 2)}

TASK: Analyze the wrong answers and identify specific learning weaknesses. Group related mistakes by topic and subtopic. For each weakness:
1. Determine priority: HIGH (fundamental concept missed, or multiple errors in topic), MEDIUM (important but not critical), LOW (minor or edge case)
2. Write a clear explanation of WHY the student got it wrong and WHAT they don't understand
3. Recommend 2-4 specific actions to improve (e.g., "Review binary search algorithm", "Practice loop conditions on HackerRank")

Return a JSON object:
{
  "weaknesses": [
    {
      "topic": "topic name",
      "subtopic": "specific subtopic or null",
      "priority": "HIGH" | "MEDIUM" | "LOW",
      "explanation": "clear explanation of the weakness",
      "recommended_actions": ["action 1", "action 2"]
    }
  ]
}

If all answers are correct, return an empty weaknesses array.
Only include weaknesses for topics where the student got at least one question wrong.

IMPORTANT: Return ONLY the JSON object, no markdown, no explanation.`;
}

async function callGroq(prompt: string, apiKeyFromClient?: string): Promise<{ weaknesses: WeaknessAI[] }> {
  const apiKey = Deno.env.get("GROQ_API_KEY") || apiKeyFromClient;
  if (!apiKey) throw new Error("GROQ_API_KEY not configured");

  const client = new OpenAI({
    apiKey,
    baseURL: "https://api.groq.com/openai/v1",
  });

  const completion = await client.chat.completions.create({
    model: "openai/gpt-oss-20b",
    messages: [{ role: "user", content: prompt }],
    temperature: 0.5,
    max_tokens: 4096,
    response_format: { type: "json_object" },
  });

  const text = completion.choices[0]?.message?.content;
  if (!text) throw new Error("Empty response from Groq");

  let parsed: { weaknesses: WeaknessAI[] };
  try {
    parsed = JSON.parse(text);
  } catch {
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error("Could not parse JSON from Groq response");
    parsed = JSON.parse(jsonMatch[0]);
  }

  return parsed;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing authorization" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Invalid token" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body: RequestBody = await req.json();
    if (!body.assessment_id || !body.questions) {
      return new Response(JSON.stringify({ error: "Missing required fields" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const prompt = buildPrompt(body.questions);
    const result = await callGroq(prompt, body.groq_api_key);

    // Save weaknesses to database
    const topics = result.weaknesses.map((w) => w.topic);
    if (topics.length > 0) {
      for (const topic of topics) {
        await supabase
          .from("weaknesses")
          .update({ status: "resolved", resolved_at: new Date().toISOString() })
          .eq("user_id", user.id)
          .eq("topic", topic)
          .in("status", ["active", "recurring"]);
      }
    }

    for (const w of result.weaknesses) {
      const score = Math.round(
        (body.questions.filter((q) => q.topic === w.topic && q.is_correct).length /
          Math.max(1, body.questions.filter((q) => q.topic === w.topic).length)) * 100
      );

      const { data: weaknessRow, error: weaknessError } = await supabase
        .from("weaknesses")
        .insert({
          user_id: user.id,
          topic: w.topic,
          subtopic: w.subtopic || null,
          priority: w.priority,
          status: "active",
          score,
          explanation: w.explanation,
          recommended_actions: w.recommended_actions,
        })
        .select()
        .single();

      if (!weaknessError && weaknessRow) {
        await supabase.from("weakness_history").insert({
          weakness_id: weaknessRow.id,
          user_id: user.id,
          topic: w.topic,
          subtopic: w.subtopic || null,
          score,
        });
      }
    }

    return new Response(JSON.stringify({ weaknesses: result.weaknesses }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
*/

-- ============================================================
-- 4. ai-study-plan/index.ts
-- ============================================================
/*
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import OpenAI from "https://esm.sh/openai@4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface RequestBody {
  available_minutes: number;
  roadmap_topics: { topic_name: string; status: string; current_proficiency: number; target_proficiency: number }[];
  active_weaknesses: { topic: string; priority: string }[];
  groq_api_key?: string;
}

function buildPrompt(body: RequestBody): string {
  const inProgress = body.roadmap_topics.filter((t) => t.status === "IN_PROGRESS");
  const notStarted = body.roadmap_topics.filter((t) => t.status === "NOT_STARTED").slice(0, 5);
  const needsRevision = body.roadmap_topics.filter((t) => t.status === "NEEDS_REVISION");

  return `You are a personal AI study planner. Create a focused, actionable study plan for today.

AVAILABLE TIME: ${body.available_minutes} minutes

CURRENTLY LEARNING (in progress):
${inProgress.map((t) => `- ${t.topic_name} (${t.current_proficiency}/${t.target_proficiency}% proficiency)`).join("\n") || "None"}

NEEDS REVISION:
${needsRevision.map((t) => `- ${t.topic_name} (${t.current_proficiency}% proficiency)`).join("\n") || "None"}

ACTIVE WEAKNESSES:
${body.active_weaknesses.map((w) => `- ${w.topic} (${w.priority} priority)`).join("\n") || "None"}

NEXT UP (not started):
${notStarted.map((t) => `- ${t.topic_name}`).join("\n") || "None"}

TASK: Create a study plan that fits within ${body.available_minutes} minutes. Prioritize:
1. Fixing HIGH priority weaknesses (if any)
2. Continuing in-progress topics
3. Revising topics that need revision
4. Starting new topics if time permits

Return JSON:
{
  "plan": [
    {
      "activity": "What to do",
      "topic": "topic name",
      "duration_minutes": 30,
      "type": "learn" | "practice" | "revise" | "assess",
      "details": "Specific instructions on what to study or practice"
    }
  ]
}

Keep the plan realistic for the time available. Each activity should be 15-60 minutes.

IMPORTANT: Return ONLY the JSON object, no markdown, no explanation.`;
}

async function callGroq(prompt: string, apiKeyFromClient?: string) {
  const apiKey = Deno.env.get("GROQ_API_KEY") || apiKeyFromClient;
  if (!apiKey) throw new Error("GROQ_API_KEY not configured");

  const client = new OpenAI({
    apiKey,
    baseURL: "https://api.groq.com/openai/v1",
  });

  const completion = await client.chat.completions.create({
    model: "openai/gpt-oss-20b",
    messages: [{ role: "user", content: prompt }],
    temperature: 0.6,
    max_tokens: 4096,
    response_format: { type: "json_object" },
  });

  const text = completion.choices[0]?.message?.content;
  if (!text) throw new Error("Empty response from Groq");

  try {
    return JSON.parse(text);
  } catch {
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error("Could not parse JSON from Groq response");
    return JSON.parse(jsonMatch[0]);
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing authorization" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Invalid token" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body: RequestBody = await req.json();
    const prompt = buildPrompt(body);
    const result = await callGroq(prompt, body.groq_api_key);

    await supabase.from("study_plans").upsert({
      user_id: user.id,
      plan_date: new Date().toISOString().split("T")[0],
      available_minutes: body.available_minutes,
      plan_content: result.plan || [],
    });

    return new Response(JSON.stringify({ plan: result.plan || [] }), {
      status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return new Response(JSON.stringify({ error: message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
*/

-- ============================================================
-- 5. ai-mentor/index.ts
-- ============================================================
/*
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import OpenAI from "https://esm.sh/openai@4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface RequestBody {
  question: string;
  context: {
    career_goal: string;
    completed_topics: string[];
    active_weaknesses: string[];
    current_topic: string | null;
  };
  groq_api_key?: string;
}

function buildPrompt(body: RequestBody): string {
  return `You are SkillPath AI, a personal mentor for a student learning software engineering.

STUDENT CONTEXT:
- Career goal: ${body.context.career_goal}
- Completed topics: ${body.context.completed_topics.join(", ") || "None yet"}
- Active weaknesses: ${body.context.active_weaknesses.join(", ") || "None"}
- Currently studying: ${body.context.current_topic || "Nothing specific right now"}

STUDENT QUESTION: ${body.question}

Provide a helpful, specific, and encouraging response. Keep it concise (2-4 paragraphs). If the question is about what to study next, reference their actual progress. If it's a technical question, explain clearly. If it's about career advice, be practical and specific to their goal.

Do not use markdown headers. Use plain text with short paragraphs.`;
}

async function callGroq(prompt: string, apiKeyFromClient?: string): Promise<string> {
  const apiKey = Deno.env.get("GROQ_API_KEY") || apiKeyFromClient;
  if (!apiKey) throw new Error("GROQ_API_KEY not configured");

  const client = new OpenAI({
    apiKey,
    baseURL: "https://api.groq.com/openai/v1",
  });

  const completion = await client.chat.completions.create({
    model: "openai/gpt-oss-20b",
    messages: [{ role: "user", content: prompt }],
    temperature: 0.7,
    max_tokens: 2048,
  });

  const text = completion.choices[0]?.message?.content;
  if (!text) throw new Error("Empty response from Groq");
  return text.trim();
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing authorization" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Invalid token" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body: RequestBody = await req.json();
    if (!body.question) {
      return new Response(JSON.stringify({ error: "Missing question" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const prompt = buildPrompt(body);
    const answer = await callGroq(prompt, body.groq_api_key);

    return new Response(JSON.stringify({ answer }), {
      status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return new Response(JSON.stringify({ error: message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
*/

-- ============================================================
-- 6. ai-projects/index.ts
-- ============================================================
/*
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import OpenAI from "https://esm.sh/openai@4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface RequestBody {
  career_goal: string;
  completed_skills: string[];
  active_weaknesses: string[];
  existing_projects: string[];
  groq_api_key?: string;
}

interface ProjectAI {
  title: string;
  description: string;
  difficulty: "Easy" | "Medium" | "Hard";
  estimated_duration: string;
  required_skills: string[];
  features: string[];
  learning_outcomes: string[];
  completion_checklist: string[];
}

function buildPrompt(body: RequestBody): string {
  return `You are an expert project recommender for software engineering students.

STUDENT PROFILE:
- Career goal: ${body.career_goal}
- Completed skills: ${body.completed_skills.join(", ") || "None yet"}
- Active weaknesses: ${body.active_weaknesses.join(", ") || "None"}
- Existing projects: ${body.existing_projects.join(", ") || "None"}

TASK: Recommend 3 projects that:
1. Match the student's current skill level (use completed skills)
2. Help address their weaknesses
3. Are relevant to their career goal
4. Are NOT duplicates of existing projects
5. Progress in difficulty (one easier, one medium, one more challenging)

Return JSON:
{
  "projects": [
    {
      "title": "Project name",
      "description": "2-3 sentence description",
      "difficulty": "Easy" | "Medium" | "Hard",
      "estimated_duration": "e.g., 1-2 weeks",
      "required_skills": ["skill1", "skill2"],
      "features": ["feature 1", "feature 2", "feature 3"],
      "learning_outcomes": ["what they will learn 1", "what they will learn 2"],
      "completion_checklist": ["checklist item 1", "checklist item 2"]
    }
  ]
}

IMPORTANT: Return ONLY the JSON object, no markdown, no explanation.`;
}

async function callGroq(prompt: string, apiKeyFromClient?: string): Promise<{ projects: ProjectAI[] }> {
  const apiKey = Deno.env.get("GROQ_API_KEY") || apiKeyFromClient;
  if (!apiKey) throw new Error("GROQ_API_KEY not configured");

  const client = new OpenAI({
    apiKey,
    baseURL: "https://api.groq.com/openai/v1",
  });

  const completion = await client.chat.completions.create({
    model: "openai/gpt-oss-20b",
    messages: [{ role: "user", content: prompt }],
    temperature: 0.7,
    max_tokens: 8192,
    response_format: { type: "json_object" },
  });

  const text = completion.choices[0]?.message?.content;
  if (!text) throw new Error("Empty response from Groq");

  let parsed: { projects: ProjectAI[] };
  try {
    parsed = JSON.parse(text);
  } catch {
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error("Could not parse JSON from Groq response");
    parsed = JSON.parse(jsonMatch[0]);
  }

  return parsed;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing authorization" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Invalid token" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body: RequestBody = await req.json();
    const prompt = buildPrompt(body);
    const result = await callGroq(prompt, body.groq_api_key);

    if (result.projects && result.projects.length > 0) {
      const inserts = result.projects.map((p) => ({
        user_id: user.id,
        title: p.title,
        description: p.description,
        difficulty: p.difficulty,
        estimated_duration: p.estimated_duration,
        required_skills: p.required_skills || [],
        features: p.features || [],
        learning_outcomes: p.learning_outcomes || [],
        completion_checklist: p.completion_checklist || [],
        status: "RECOMMENDED",
      }));

      await supabase.from("projects").insert(inserts);
    }

    return new Response(JSON.stringify({ projects: result.projects || [] }), {
      status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return new Response(JSON.stringify({ error: message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
*/

-- ============================================================
-- 7. ai-career/index.ts
-- ============================================================
/*
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import OpenAI from "https://esm.sh/openai@4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface RequestBody {
  career_goal: string;
  skill_profile: { skill: string; proficiency: number }[];
  completed_topics: string[];
  total_topics: number;
  groq_api_key?: string;
}

function buildPrompt(body: RequestBody): string {
  const skillsList = body.skill_profile.length > 0
    ? body.skill_profile.map((s) => `${s.skill}: ${s.proficiency}%`).join(", ")
    : "No skills assessed yet";

  const progressPct = body.total_topics > 0
    ? Math.round((body.completed_topics.length / body.total_topics) * 100)
    : 0;

  return `You are an expert career advisor analyzing a student's readiness for their target role.

STUDENT PROFILE:
- Career goal: ${body.career_goal}
- Skill proficiency: ${skillsList}
- Roadmap progress: ${progressPct}% (${body.completed_topics.length}/${body.total_topics} topics completed)
- Completed topics: ${body.completed_topics.join(", ") || "None yet"}

TASK: Provide a comprehensive career analysis. Return JSON:
{
  "analysis": {
    "job_readiness_score": 0-100,
    "readiness_level": "Early Stage" | "Building Foundation" | "Approaching Readiness" | "Job Ready",
    "strengths": ["strength 1", "strength 2"],
    "gaps": ["missing skill 1", "missing skill 2"],
    "recommended_focus": ["what to focus on next 1", "what to focus on next 2"],
    "job_titles": ["job title they can apply for now or soon"],
    "estimated_weeks_to_ready": 12,
    "advice": "2-3 sentences of personalized career advice"
  }
}

IMPORTANT: Return ONLY the JSON object, no markdown, no explanation.`;
}

async function callGroq(prompt: string, apiKeyFromClient?: string) {
  const apiKey = Deno.env.get("GROQ_API_KEY") || apiKeyFromClient;
  if (!apiKey) throw new Error("GROQ_API_KEY not configured");

  const client = new OpenAI({
    apiKey,
    baseURL: "https://api.groq.com/openai/v1",
  });

  const completion = await client.chat.completions.create({
    model: "openai/gpt-oss-20b",
    messages: [{ role: "user", content: prompt }],
    temperature: 0.6,
    max_tokens: 4096,
    response_format: { type: "json_object" },
  });

  const text = completion.choices[0]?.message?.content;
  if (!text) throw new Error("Empty response from Groq");

  try {
    return JSON.parse(text);
  } catch {
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error("Could not parse JSON from Groq response");
    return JSON.parse(jsonMatch[0]);
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing authorization" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Invalid token" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body: RequestBody = await req.json();
    const prompt = buildPrompt(body);
    const result = await callGroq(prompt, body.groq_api_key);

    return new Response(JSON.stringify({ analysis: result.analysis }), {
      status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return new Response(JSON.stringify({ error: message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
*/

-- ============================================================
-- END OF FILE
-- ============================================================
-- After running the SQL above and deploying the 7 Edge Functions:
-- 1. Set the GROQ_API_KEY secret on the new Supabase project
-- 2. Update your .env with the new project URL and anon/service keys
-- 3. The app will work identically to how it works now
-- ============================================================
